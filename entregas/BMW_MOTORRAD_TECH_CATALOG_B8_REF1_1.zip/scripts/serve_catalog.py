"""Start the local catalog. Runtime requires only Python 3 standard library."""
import argparse
import functools
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys
import threading
import webbrowser

APP = Path(__file__).resolve().parents[1] / 'BMW_Motorrad_B8_REGENERADO'

def main():
    parser = argparse.ArgumentParser(description='Abrir el catálogo BMW en este equipo.')
    parser.add_argument('--port',type=int,default=8000,help='Puerto local (por defecto 8000; 0 elige uno temporal).')
    parser.add_argument('--no-browser',action='store_true',help='No abrir automáticamente el navegador.')
    args = parser.parse_args()
    if not 0 <= args.port <= 65535:parser.error('El puerto debe estar entre 0 y 65535.')
    if not (APP/'index.html').is_file():parser.error('Falta el catálogo. Extrae el ZIP completo antes de iniciar.')
    handler=functools.partial(SimpleHTTPRequestHandler,directory=str(APP))
    try:server=ThreadingHTTPServer(('127.0.0.1',args.port),handler)
    except OSError as error:
        print('No se pudo iniciar el catálogo en el puerto '+str(args.port)+'. Cierra otra sesión del catálogo o elige --port. No se ha detenido ningún proceso.',file=sys.stderr)
        print(str(error),file=sys.stderr);return 1
    with server:
        address='http://127.0.0.1:'+str(server.server_port)+'/'
        print('Catálogo listo: '+address,flush=True)
        print('Deja esta ventana abierta. Para cerrar, pulsa Ctrl+C.',flush=True)
        if not args.no_browser:threading.Thread(target=webbrowser.open,args=(address,),daemon=True).start()
        try:server.serve_forever()
        except KeyboardInterrupt:print('\nCatálogo cerrado.')
    return 0

if __name__=='__main__':raise SystemExit(main())
