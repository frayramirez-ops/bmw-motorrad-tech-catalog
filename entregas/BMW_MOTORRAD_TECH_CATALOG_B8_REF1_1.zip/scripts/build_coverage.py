"""Build a reproducible coverage view; --check detects stale generated files."""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'BMW_Motorrad_B8_REGENERADO'
FIELDS = ('year','family','model','platform','system')
DOCUMENTED = {
    'DOCUMENTADO_EN_EDICION_APLICABILIDAD_PENDIENTE',
    'REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE',
    'OPCION_DOCUMENTADA_APLICABILIDAD_PENDIENTE',
    'HOMOLOGACION_DOCUMENTADA_UNIDAD_PENDIENTE',
}
PENDING = 'PENDIENTE_CONTRASTE_DOCUMENTAL'

def record_id(section, record):
    return section + ':' + json.dumps([str(record[k]) for k in FIELDS], ensure_ascii=False, separators=(',',':'))

def build_coverage(catalog, reviews):
    records = {}
    for section in ['transponders','diagnostico']:
        for record in catalog[section]:
            identity = record_id(section, record)
            if identity in records:
                raise ValueError('Duplicate catalog identity: ' + identity)
            records[identity] = (section, record)
    detailed = {}
    for review in reviews:
        for row in review['records']:
            identity = row['recordId']
            if identity not in records or identity in detailed:
                raise ValueError('Unknown or duplicate reviewed identity: ' + identity)
            section, record = records[identity]
            digest = hashlib.sha256(json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(',',':')).encode()).hexdigest()
            if digest != row['b8RecordSha256']:
                raise ValueError('Stale reviewed record: ' + identity)
            claims = row['claims']
            if not claims or len({c['topic'] for c in claims}) != len(claims):
                raise ValueError('Missing or duplicate claim topics: ' + identity)
            for claim in claims:
                if claim['status'] not in DOCUMENTED | {PENDING}:
                    raise ValueError('Unknown claim status: ' + claim['status'])
            detailed[identity] = row
    rows = []
    for identity, (section, record) in records.items():
        review = detailed.get(identity)
        claims = review['claims'] if review else []
        documented = sum(c['status'] in DOCUMENTED for c in claims)
        status = 'not_reviewed'
        if review:
            status = 'hypothesis' if review['status'] == 'HIPOTESIS_NO_ACREDITADA' else 'limited' if documented else 'reviewed_pending'
        rows.append({'recordId':identity,'section':section,**{k:record[k] for k in FIELDS},
            'status':status,'detailed':bool(review),'claims':len(claims) if review else None,'documentedClaims':documented if review else None,
            'pendingClaims':len(claims)-documented if review else None})
    families = []
    for family in sorted({r['family'] for r in rows}):
        subset = [r for r in rows if r['family'] == family]
        families.append({'family':family,'records':len(subset),'detailed':sum(r['detailed'] for r in subset)})
    return {'schema':1,'scope':'Cobertura de conciliación de las fichas existentes en B8; no padrón de producción ni porcentaje de finalización.',
        'summary':{'records':len(rows),'detailed':len(detailed),'notDetailed':len(rows)-len(detailed),
          'claimsReviewed':sum(r['claims'] or 0 for r in rows),'claimsDocumented':sum(r['documentedClaims'] or 0 for r in rows),
          'claimsPending':sum(r['pendingClaims'] or 0 for r in rows),
          'minYear':min(r['year'] for r in rows),'maxYear':max(r['year'] for r in rows)},
        'families':families,'records':rows}

def generated_files():
    html = (APP/'index.html').read_text()
    raw = re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1]
    inputs = ['f800-reconciliation.json','s1000rr-reconciliation.json','r1250gs-reconciliation.json','r1200gs-reconciliation.json','r1250rt-r1300gs-reconciliation.json','ninet-reconciliation.json','r-final-reconciliation.json','f750-f850-reconciliation.json','f650-f700-reconciliation.json','f-final-reconciliation.json','k-reconciliation.json','c-reconciliation.json','s-final-reconciliation.json','gm-reconciliation.json']
    reviews = {f:json.loads((ROOT/'docs'/f).read_text()) for f in inputs}
    data = build_coverage(json.loads(raw),list(reviews.values()))
    data['inputs'] = {'catalogSha256':hashlib.sha256(raw.encode()).hexdigest(),
       'reviewSha256':{f:hashlib.sha256((ROOT/'docs'/f).read_bytes()).hexdigest() for f in inputs}}
    embedded = json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
    page = (ROOT/'scripts/templates/coverage.html').read_text().replace('COVERAGE_PAYLOAD',embedded)
    output = io.StringIO();writer=csv.writer(output)
    writer.writerow(['identidad','seccion','anio','familia','modelo','plataforma','sistema','estado_conciliacion','afirmaciones_revisadas','respaldo_limitado','pendientes'])
    for r in data['records']:
        writer.writerow([r['recordId'],r['section'],r['year'],r['family'],r['model'],r['platform'],r['system'],r['status'],r['claims'],r['documentedClaims'],r['pendingClaims']])
    pending_output = io.StringIO();pending_writer=csv.writer(pending_output)
    pending_writer.writerow(['identidad','registro_revision','seccion','anio','familia','modelo','plataforma','sistema','afirmacion','estado','fuentes','observaciones','limite','siguiente_accion'])
    pending_rows=[]
    for filename,review in reviews.items():
        sources={source['id']:source for source in review['sources']}
        observations={ob['id']:ob for ob in review['observations']}
        def source_info(source_id,origin=None,scope=None):
            source=sources[source_id]
            return {'id':source_id,'url':source['url'],'title':source.get('documentEdition')or source['url'],'status':source['status'],'origin':origin,'scope':scope}
        for row in review['records']:
            for claim in row['claims']:
                if claim['status'] != PENDING:continue
                ident=row['identity']
                pending_rows.append({'recordId':row['recordId'],'review':filename,'section':row['section'],**ident,
                    'recordStatus':row['status'],'topic':claim['topic'],'finding':claim.get('finding',''),
                    'limitation':claim.get('limitation',''),'nextAction':claim.get('nextAction',''),
                    'sourceCodes':row.get('sourceCodes',[]),'contextFindings':row.get('findings',[]),
                    'observations':[{**{k:observations[oid].get(k) for k in ['pdfPage','section','scope']},
                        'source':source_info(observations[oid]['sourceId'])}for oid in claim.get('observations',[])],
                    'references':[source_info(ref['sourceId'],ref.get('origin'),ref.get('scope')) for ref in row['references']]})
                pending_writer.writerow([row['recordId'],filename,row['section'],*[ident[k] for k in FIELDS],claim['topic'],claim['status'],
                    ';'.join(claim.get('sourceIds',[])),';'.join(claim.get('observations',[])),claim.get('limitation',''),claim.get('nextAction','')])
    pending_data={'schema':1,'summary':data['summary'],'inputs':data['inputs'],'records':pending_rows}
    pending_embedded=json.dumps(pending_data,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
    pending_page=(ROOT/'scripts/templates/pending.html').read_text().replace('PENDING_PAYLOAD',pending_embedded)
    return {ROOT/'docs/coverage-data.json':json.dumps(data,ensure_ascii=False,indent=2)+'\n',
      APP/'ESTADO_CATALOGO.html':page,APP/'PADRON_CATALOGO_B8.csv':'\ufeff'+output.getvalue(),
      ROOT/'docs/PENDIENTES_TECNICOS_B8.csv':'\ufeff'+pending_output.getvalue(),
      APP/'PENDIENTES_TECNICOS_B8.csv':'\ufeff'+pending_output.getvalue(),APP/'PENDIENTES_TECNICOS.html':pending_page}

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check',action='store_true');args=parser.parse_args()
    stale=[]
    for path, content in generated_files().items():
        if args.check:
            if not path.exists() or path.read_bytes()!=content.encode('utf8'):stale.append(str(path.relative_to(ROOT)))
        else:path.write_bytes(content.encode('utf8'))
    if stale:parser.exit(1,'Stale generated coverage: '+', '.join(stale)+'\n')

if __name__ == '__main__':main()
