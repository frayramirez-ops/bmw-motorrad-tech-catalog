"""Create or verify a reviewable, self-contained release ZIP without credentials/caches."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]
MEMBERS=['README_CODEX.md','LEEME_PRIMERO.md','VERSION.json','INICIAR_CATALOGO.bat','iniciar_catalogo.sh',
         'BMW_Motorrad_B8_REGENERADO','docs','tests','scripts','originals']

def verify(path):
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:raise ValueError('ZIP con error CRC')
        names=archive.namelist()
        if len(names)!=len(set(names)):raise ValueError('Entradas duplicadas')
        manifest=json.loads(archive.read('RELEASE_MANIFEST.json'))
        expected={entry['path'] for entry in manifest['files']}
        if set(names)!=expected|{'RELEASE_MANIFEST.json'}:raise ValueError('Inventario del ZIP diferente del manifiesto')
        for entry in manifest['files']:
            name=entry['path']
            if Path(name).is_absolute() or '..' in Path(name).parts:raise ValueError('Ruta insegura')
            if hashlib.sha256(archive.read(name)).hexdigest()!=entry['sha256']:raise ValueError('Hash distinto: '+name)
    return manifest

def package(output):
    files=[]
    for member in MEMBERS:
        parent=ROOT/member
        if not parent.exists():raise ValueError('Falta componente: '+member)
        for path in ([parent] if parent.is_file() else parent.rglob('*')):
            if '__pycache__' in path.parts or path.suffix=='.pyc':continue
            if path.is_symlink():raise ValueError('No se empaquetan enlaces simbólicos: '+str(path))
            if path.is_file():files.append(path)
    version=json.loads((ROOT/'VERSION.json').read_text())
    original=(ROOT/'originals/b8/index.html').read_bytes()
    if hashlib.sha256(original).hexdigest()!=version['originalHtmlSha256']:raise ValueError('Original B8 modificado')
    for name, expected in version['originalFilesSha256'].items():
        if hashlib.sha256((ROOT/'originals/b8'/name).read_bytes()).hexdigest()!=expected:
            raise ValueError('Original B8 modificado: '+name)
    output=Path(output)
    if output.exists():raise ValueError('El destino ya existe; usa otro nombre para conservar la entrega anterior.')
    output.parent.mkdir(parents=True,exist_ok=True)
    records=[]
    with zipfile.ZipFile(output,'x',compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(files):
            name=str(path.relative_to(ROOT));data=path.read_bytes();archive.writestr(name,data)
            records.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
        archive.writestr('RELEASE_MANIFEST.json',json.dumps({'schema':1,'version':version,'files':records},ensure_ascii=False,indent=2)+'\n')
    return verify(output)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--output',type=Path);group.add_argument('--verify',type=Path)
    args=parser.parse_args()
    try:manifest=verify(args.verify) if args.verify else package(args.output)
    except (ValueError,OSError,KeyError,zipfile.BadZipFile) as error:parser.exit(1,str(error)+'\n')
    print(manifest['version']['version']+': '+str(len(manifest['files']))+' archivos verificados.')

if __name__=='__main__':main()
