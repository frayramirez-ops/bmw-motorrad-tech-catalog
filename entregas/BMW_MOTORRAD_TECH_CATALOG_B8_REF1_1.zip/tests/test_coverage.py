"""Coverage must be reproducible and must not turn unknown claims into zero pending."""
import copy
import csv
import functools
import importlib.util
import json
import re
import subprocess
import sys
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP, ROOT, QuietHandler

spec=importlib.util.spec_from_file_location('build_coverage',ROOT/'scripts/build_coverage.py')
coverage=importlib.util.module_from_spec(spec);spec.loader.exec_module(coverage)

class CoverageTests(unittest.TestCase):
    def test_generated_padron_is_complete_and_current(self):
        result=subprocess.run([sys.executable,str(ROOT/'scripts/build_coverage.py'),'--check'],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)
        data=json.loads((ROOT/'docs/coverage-data.json').read_text())
        html=(APP/'ESTADO_CATALOGO.html').read_text()
        self.assertEqual(data,json.loads(re.search(r'<script id="coverageData"[^>]*>(.*?)</script>',html,re.S)[1]))
        self.assertEqual(data['summary']['records'],815)
        self.assertEqual(data['summary']['detailed'],815)
        self.assertEqual(data['summary']['notDetailed'],0)
        self.assertEqual(data['summary']['claimsReviewed'],3760)
        self.assertEqual(data['summary']['claimsDocumented'],1317)
        self.assertEqual(data['summary']['claimsPending'],2443)
        summary=data['summary']
        expected_report=(f"En los bloques conciliados hay {summary['claimsReviewed']} afirmaciones inventariadas: "
                         f"{summary['claimsDocumented']} con respaldo limitado y {summary['claimsPending']} pendientes.")
        self.assertIn(expected_report,(ROOT/'docs/COBERTURA_CATALOGO.md').read_text())
        self.assertEqual(len({r['recordId'] for r in data['records']}),815)
        self.assertEqual(sum(r['records'] for r in data['families']),815)
        self.assertEqual(next(r for r in data['families']if r['family']=='R'),{'family':'R','records':279,'detailed':279})
        self.assertEqual(next(r for r in data['families']if r['family']=='F'),{'family':'F','records':182,'detailed':182})
        self.assertEqual(next(r for r in data['families']if r['family']=='K'),{'family':'K','records':128,'detailed':128})
        self.assertEqual(next(r for r in data['families']if r['family']=='C'),{'family':'C','records':87,'detailed':87})
        self.assertEqual(next(r for r in data['families']if r['family']=='S'),{'family':'S','records':115,'detailed':115})
        self.assertEqual(next(r for r in data['families']if r['family']=='G'),{'family':'G','records':18,'detailed':18})
        self.assertEqual(next(r for r in data['families']if r['family']=='M'),{'family':'M','records':6,'detailed':6})
        self.assertTrue(all(r['detailed'] and r['pendingClaims'] is not None for r in data['records']))
        self.assertTrue(all(r['claims']==(5 if r['section']=='transponders'else 4)for r in data['records']))
        with(ROOT/'docs/PENDIENTES_TECNICOS_B8.csv').open(encoding='utf-8-sig',newline='')as f:pending=list(csv.DictReader(f))
        expected_pending=set()
        for filename in data['inputs']['reviewSha256']:
            review=json.loads((ROOT/'docs'/filename).read_text())
            expected_pending.update((row['recordId'],claim['topic'],filename)for row in review['records']for claim in row['claims']if claim['status']==coverage.PENDING)
        self.assertEqual(len(pending),2443)
        self.assertEqual({(row['identidad'],row['afirmacion'],row['registro_revision'])for row in pending},expected_pending)
        self.assertTrue(all(row['estado']==coverage.PENDING and row['siguiente_accion']and row['limite']for row in pending))
        with (APP/'PADRON_CATALOGO_B8.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
        self.assertEqual(len(rows),815)
        self.assertEqual(sum(r['afirmaciones_revisadas']=='' for r in rows),0)

    def test_invalid_or_stale_review_is_rejected(self):
        html=(APP/'index.html').read_text()
        catalog=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        review=json.loads((ROOT/'docs/f800-reconciliation.json').read_text())
        unknown=coverage.build_coverage(catalog,[])
        self.assertEqual(unknown['summary']['notDetailed'],815)
        self.assertTrue(all(r['pendingClaims'] is None and r['claims'] is None for r in unknown['records']))
        bad=copy.deepcopy(review);bad['records'][0]['recordId']='missing'
        with self.assertRaisesRegex(ValueError,'Unknown'):coverage.build_coverage(catalog,[bad])
        bad=copy.deepcopy(review);bad['records'][0]['b8RecordSha256']='bad'
        with self.assertRaisesRegex(ValueError,'Stale'):coverage.build_coverage(catalog,[bad])
        with self.assertRaisesRegex(ValueError,'duplicate reviewed'):coverage.build_coverage(catalog,[review,review])
        bad=copy.deepcopy(review);bad['records'][0]['claims'][0]['status']='CERTIFICADO_POR_SUPOSICION'
        with self.assertRaisesRegex(ValueError,'Unknown claim'):coverage.build_coverage(catalog,[bad])
        bad=copy.deepcopy(catalog);bad['transponders'].append(bad['transponders'][0])
        with self.assertRaisesRegex(ValueError,'Duplicate catalog'):coverage.build_coverage(bad,[])

    def test_browser_filters_pagination_and_download(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright() as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000)
                errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                page.get_by_role('link',name='Consultar cobertura documental del catálogo').click()
                self.assertEqual(page.locator('#coverageRows tr').count(),40)
                self.assertEqual(page.locator('#coverageCount').inner_text(),'1–40 de 815 fichas')
                first=page.locator('#coverageRows tr').first.get_attribute('data-record-id')
                page.click('#coverageNext')
                self.assertNotEqual(first,page.locator('#coverageRows tr').first.get_attribute('data-record-id'))
                self.assertEqual(page.locator('#coverageCount').inner_text(),'41–80 de 815 fichas')
                page.select_option('#coverageStatus','detailed')
                self.assertEqual(page.locator('#coverageCount').inner_text(),'1–40 de 815 fichas')
                page.select_option('#coverageFamily','F')
                self.assertEqual(page.locator('#coverageCount').inner_text(),'1–40 de 182 fichas')
                page.select_option('#coverageFamily','C')
                self.assertEqual(page.locator('#coverageCount').inner_text(),'1–40 de 87 fichas')
                page.select_option('#coverageFamily','S')
                self.assertEqual(page.locator('#coverageCount').inner_text(),'1–40 de 115 fichas')
                page.select_option('#coverageFamily','G')
                self.assertEqual(page.locator('#coverageCount').inner_text(),'1–18 de 18 fichas')
                page.select_option('#coverageFamily','M')
                self.assertEqual(page.locator('#coverageCount').inner_text(),'1–6 de 6 fichas')
                page.get_by_role('button',name='Limpiar filtros').click()
                page.select_option('#coverageStatus','hypothesis')
                self.assertEqual(page.locator('#coverageRows tr').count(),8)
                self.assertIn('Hipótesis no acreditada',page.locator('#coverageRows').inner_text())
                page.get_by_role('button',name='Limpiar filtros').click()
                page.fill('#coverageSearch','R1250GSA')
                self.assertTrue(page.locator('#coverageRows tr').count()>0)
                page.select_option('#coverageYear','2000')
                self.assertTrue(page.locator('#coverageEmpty').is_visible())
                page.get_by_role('button',name='Limpiar filtros').click()
                with page.expect_download() as event:page.get_by_role('link',name='Descargar padrón de fichas B8 (CSV completo)').click()
                with open(event.value.path(),encoding='utf-8-sig',newline='') as exported:
                    self.assertEqual(len(list(csv.DictReader(exported))),815)
                page.set_viewport_size({'width':375,'height':812})
                self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                page.get_by_role('link',name='Volver al catálogo').click()
                self.assertTrue(page.locator('#globalSearch').is_visible())
                self.assertEqual(errors,[])
                browser.close()
        finally:server.shutdown();server.server_close()
