"""Recovered model gallery: integrity, no implied applicability, HTTP and file use."""
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from playwright.sync_api import sync_playwright, Error
from test_recovery import APP, ROOT, QuietHandler

class GalleryTests(unittest.TestCase):
    def test_manifest_limits_and_integrity(self):
        manifest=json.loads((ROOT/'docs/gallery-manifest.json').read_text())
        page=(APP/'GALERIA_FOTOGRAFICA_OEM.html').read_text()
        self.assertEqual(manifest,json.loads(re.search(r'<script id="galleryData"[^>]*>(.*?)</script>',page,re.S)[1]))
        entries=manifest['entries']
        self.assertEqual(len(entries),24)
        self.assertEqual(sum(e['kind']=='recorte' for e in entries),8)
        self.assertEqual(sum(e['kind']=='fotografia' for e in entries),16)
        self.assertEqual(len({e['id'] for e in entries}),24)
        for entry in entries:
            self.assertFalse(entry['approvedForTechnicalUse'])
            self.assertNotIn('year',entry)
            self.assertTrue(entry['path'].startswith(('assets/model_photos/','assets/model_cutouts/')))
            self.assertNotIn('no_aprobado',entry['path'])
            self.assertNotIn('revision',entry['path'])
            self.assertEqual(hashlib.sha256((APP/entry['path']).read_bytes()).hexdigest(),entry['sha256'])

    def test_http_filters_zoom_and_context_links(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright() as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000)
                errors=[];missing=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.on('response',lambda r:missing.append(r.url) if r.status>=400 else None)
                base=f'http://127.0.0.1:{server.server_port}/'
                page.goto(base,wait_until='networkidle')
                page.locator('a[aria-label="Abrir biblioteca visual"]').click()
                self.assertIn('GALERIA_FOTOGRAFICA_OEM.html',page.url)
                self.assertEqual(page.locator('#galleryCount').inner_text(),'24 de 24 recursos')
                data=json.loads((ROOT/'docs/gallery-manifest.json').read_text())
                for entry in data['entries']:
                    response=page.request.get(base+entry['path'])
                    self.assertEqual(response.status,200)
                    self.assertEqual(hashlib.sha256(response.body()).hexdigest(),entry['sha256'])
                page.select_option('#galleryKind','recorte')
                self.assertEqual(page.locator('.card').count(),8)
                page.fill('#gallerySearch','F850GSA')
                self.assertEqual(page.locator('.card').count(),1)
                self.assertEqual(page.locator('.card h2').inner_text(),'F850GS Adventure')
                page.locator('.thumbnail').click()
                self.assertTrue(page.locator('#galleryDialog').is_visible())
                page.wait_for_function("document.getElementById('dialogImage').complete&&document.getElementById('dialogImage').naturalWidth>0")
                page.keyboard.press('Escape')
                self.assertFalse(page.locator('#galleryDialog').is_visible())
                page.get_by_role('button',name='Limpiar filtros').click()
                self.assertEqual(page.locator('.card').count(),24)
                page.fill('#gallerySearch','F800GS (798 cc)')
                self.assertEqual(page.locator('.card').count(),0)
                self.assertTrue(page.locator('#galleryEmpty').is_visible())
                page.goto(base+'GALERIA_FOTOGRAFICA_OEM.html?modelo=R1300GS%20Adventure',wait_until='networkidle')
                self.assertEqual(page.locator('.card').count(),2)
                page.set_viewport_size({'width':375,'height':812})
                self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                page.screenshot(path='/workspace/catalog-recovery/gallery-mobile.png')
                page.get_by_role('link',name='Volver al catálogo').click()
                self.assertTrue(page.locator('#globalSearch').is_visible())
                self.assertEqual(errors,[]);self.assertEqual(missing,[])
                browser.close()
        finally:
            server.shutdown();server.server_close()

    def test_file_gallery_needs_no_network(self):
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
            page=browser.new_page();errors=[];remote=[]
            page.on('pageerror',lambda e:errors.append(str(e)))
            page.on('request',lambda r:remote.append(r.url) if r.url.startswith(('http:','https:')) else None)
            try:
                page.goto((APP/'GALERIA_FOTOGRAFICA_OEM.html').as_uri(),wait_until='networkidle')
            except Error as error:
                browser.close()
                if 'ERR_BLOCKED_BY_ADMINISTRATOR' in str(error):
                    self.skipTest('La política administrada de Chromium bloquea file://; no se altera esa política.')
                raise
            self.assertEqual(page.locator('.card').count(),24)
            page.fill('#gallerySearch','S1000RR')
            self.assertEqual(page.locator('.card').count(),1)
            page.wait_for_function("document.querySelector('.thumbnail img').complete&&document.querySelector('.thumbnail img').naturalWidth>0")
            self.assertEqual(remote,[]);self.assertEqual(errors,[])
            browser.close()
