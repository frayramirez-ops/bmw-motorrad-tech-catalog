"""Finish the F inventory without certifying unknown F450 immobilizer or choosing F900R options."""
import csv
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

PENDING='PENDIENTE_CONTRASTE_DOCUMENTAL'

class FFinalTests(unittest.TestCase):
    def test_provenance_options_and_f450_unknowns(self):
        review=json.loads((ROOT/'docs/f-final-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="fFinalEvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual((len(review['records']),len(sources),len(observations)),(28,12,46))
        self.assertEqual(sum(s.get('retrieval',{}).get('type')=='.pdf'for s in sources.values()),9)
        pending=0;limited=0;homologation=0;options=0;keyless_chip_pending=0
        for row in review['records']:
            ident=row['identity'];original=next(r for r in db[row['section']]if all(r[k]==v for k,v in ident.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            primary=sources[row['references'][0]['sourceId']]
            self.assertEqual(primary['model'],ident['model']);self.assertLessEqual(primary['editionYear'],ident['year'])
            self.assertTrue(primary['discovery']['indexEntries'])
            if ident['model']=='F 450 GS':
                self.assertEqual(ident['platform'],'POR VERIFICAR');self.assertEqual(primary['platform'],'KD1')
                self.assertTrue(any('INMOVILIZADOR_PENDIENTE'in f for f in row['findings']))
                if row['section']=='transponders':self.assertTrue(all(c['status']==PENDING for c in row['claims']))
            if ident['model']=='F900R':
                self.assertEqual(ident['system'],'CONFIRMAR SISTEMA');self.assertEqual(ident['platform'],'POR VERIFICAR')
                self.assertTrue(any('OPCION_SIN_SELECCION'in f for f in row['findings']))
            for c in row['claims']:
                if c['topic']in['conector','ubicacion','mercado_equipamiento']:self.assertEqual(c['status'],PENDING)
                if ident['model']=='F900R'and c['topic']in['antena','chip','modulo']:self.assertEqual(c['status'],PENDING)
                if 'Keyless'in ident['system']and c['topic']in['chip','modulo']:
                    keyless_chip_pending+=1;self.assertEqual(c['status'],PENDING)
                if c['status']==PENDING:pending+=1
                else:
                    limited+=1;self.assertTrue(c['observations']);self.assertEqual(c['sourceIds'],[primary['id']])
                    if c['status']=='HOMOLOGACION_DOCUMENTADA_UNIDAD_PENDIENTE':
                        homologation+=1;self.assertEqual(ident['system'],'Mecánica');self.assertIn(c['topic'],['chip','modulo'])
                    if c['status']=='OPCION_DOCUMENTADA_APLICABILIDAD_PENDIENTE':
                        options+=1;self.assertEqual(ident['model'],'F900R');self.assertEqual(c['topic'],'sistema')
                for oid in c['observations']:
                    o=observations[oid];self.assertIn(o['sourceId'],c['sourceIds'])
                    self.assertEqual(o['documentSha256'],sources[o['sourceId']]['retrieval']['sha256'])
                    if ident['model']=='F 450 GS'and c['topic']=='acceso':self.assertIn('trasero/pasajero',o['scope'])
        self.assertEqual((pending,limited,homologation,options,keyless_chip_pending),(75,57,12,1,24))
        for name,count in [('F_FINAL_AFIRMACIONES.csv',132),('F_FINAL_PENDIENTES.csv',75)]:
            with(ROOT/'docs'/name).open(encoding='utf-8-sig',newline='')as f:self.assertEqual(len(list(csv.DictReader(f))),count)

    def test_browser_all_selectable_records_and_options(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/f-final-reconciliation.json').read_text())
                rows=[r for r in review['records']if r['identity']['system']!='Keyless (Emergencia)'];self.assertEqual(len(rows),22)
                select='''row=>{
                    setTab(row.section,{reset:true});
                    for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                    const declaration=document.getElementById('bmwSystemDeclaration');
                    const name=/keyless/i.test(row.identity.system)?'Keyless':/mecánica|ews/i.test(row.identity.system)?'Mecánica':null;
                    if(row.section==='transponders'&&!declaration.hidden&&name){
                      const b=[...declaration.querySelectorAll('button')].find(b=>b.textContent===name);if(b)b.click();
                    }
                    $('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));
                }'''
                for row in rows:
                    with self.subTest(record=row['recordId']):
                        page.evaluate(select,row)
                        panel=page.locator('#fFinalEvidence');self.assertTrue(panel.is_visible())
                        self.assertEqual(panel.get_attribute('data-record-id'),row['recordId'])
                        for other in ['f800Evidence','s1000rrEvidence','r1250Evidence','r1200Evidence','rTouringEvidence','ninetEvidence','rFinalEvidence','f750f850Evidence','f650f700Evidence']:
                            self.assertFalse(page.locator('#'+other).is_visible())
                        if row['identity']['model']=='F900R':self.assertIn('OPCION_SIN_SELECCION',panel.inner_text())
                        if row['identity']['model']=='F 450 GS':self.assertIn('INMOVILIZADOR_PENDIENTE',panel.inner_text())
                        if row['section']=='transponders':
                            self.assertIn('Chip y programación no validados',page.locator('#status').inner_text());self.assertEqual(page.locator('#gallery img').count(),0)
                page.set_viewport_size({'width':375,'height':812});self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                old=next(r for r in json.loads((ROOT/'docs/f650-f700-reconciliation.json').read_text())['records']if r['section']=='diagnostico')
                page.evaluate(select,old)
                self.assertTrue(page.locator('#f650f700Evidence').is_visible());self.assertFalse(page.locator('#fFinalEvidence').is_visible())
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
