"""GS and Adventure evidence stays model-specific; homologation does not certify Keyless chips."""
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

class R1200GSTests(unittest.TestCase):
    def test_registry_model_and_component_limits(self):
        review=json.loads((ROOT/'docs/r1200gs-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="r1200EvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual(len(review['records']),74)
        self.assertEqual(len(sources),25);self.assertEqual(len(observations),42)
        claims=0;documented=0
        for row in review['records']:
            identity=row['identity'];original=next(r for r in db[row['section']]if all(r[k]==v for k,v in identity.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            for ref in row['references']:
                if sources[ref['sourceId']].get('model'):
                    self.assertEqual('Adventure'in sources[ref['sourceId']]['documentEdition'],'Adventure'in identity['model'])
                else:self.assertIn(identity['model'],sources[ref['sourceId']]['models'])
            for claim in row['claims']:
                claims+=1
                if 'Keyless'in identity['system']and claim['topic']in['chip','modulo']:
                    self.assertEqual(claim['status'],'PENDIENTE_CONTRASTE_DOCUMENTAL')
                if claim['topic']in['mercado_equipamiento','conector','ubicacion']:
                    self.assertEqual(claim['status'],'PENDIENTE_CONTRASTE_DOCUMENTAL')
                if any('CONFLICTO_CRONOLOGICO' in f for f in row['findings'])and not(row['section']=='diagnostico'and claim['topic']=='acceso')and not(row.get('temporalEvidence')and claim['topic']in['sistema','antena']):
                    self.assertEqual(claim['status'],'PENDIENTE_CONTRASTE_DOCUMENTAL')
                if claim['topic'] in ['chip','modulo']:
                    self.assertEqual(claim['status'],'PENDIENTE_CONTRASTE_DOCUMENTAL')
                if claim['status']=='PENDIENTE_CONTRASTE_DOCUMENTAL':continue
                documented+=1;self.assertTrue(claim['observations'])
                for id in claim['observations']:
                    ob=observations[id];self.assertEqual(ob['documentSha256'],sources[ob['sourceId']]['retrieval']['sha256'])
        self.assertEqual(claims,340);self.assertEqual(documented,116)
        transition=[r for r in review['records'] if r['section']=='diagnostico' and (r['identity']['year'],r['identity']['model']) in [(2013,'R1200GS'),(2014,'R1200GS Adventure')]]
        self.assertEqual(len(transition),4)
        self.assertEqual(len({r['references'][0]['sourceId'] for r in transition}),4)
        self.assertEqual(sum(any('CONFLICTO_CRONOLOGICO' in f for f in r['findings']) for r in review['records']),3)
        for row in review['records']:
            for ref in row['references']:
                source=sources[ref['sourceId']]
                if source.get('model'):self.assertEqual(source['model'],row['identity']['model'])
                else:self.assertIn(row['identity']['model'],source['models'])
            if row['section']=='transponders' and row['identity']['year'] in [2004,2005]:
                self.assertEqual(next(c for c in row['claims'] if c['topic']=='antena')['status'],'PENDIENTE_CONTRASTE_DOCUMENTAL')

    def test_browser_model_switch_and_restriction(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/r1200gs-reconciliation.json').read_text())
                visible=[r for r in review['records']if r['identity']['system']!='Keyless (Emergencia)']
                self.assertEqual(len(visible),66)
                for row in visible:
                    with self.subTest(record=row['recordId']):
                        page.evaluate('''row=>{
                         setTab(row.section,{reset:true});
                         for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                         const panel=document.getElementById('bmwSystemDeclaration');
                         if(row.section==='transponders'&&!panel.hidden){
                          const type=row.identity.system.includes('Keyless')?'Keyless':'Mecánica';
                          [...panel.querySelectorAll('button')].find(b=>b.textContent===type).click();
                         }else{$('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));}
                        }''',row)
                        self.assertTrue(page.locator('#r1200Evidence').is_visible())
                        self.assertEqual(page.locator('#r1200Evidence').get_attribute('data-record-id'),row['recordId'])
                        self.assertFalse(page.locator('#f800Evidence').is_visible())
                        self.assertFalse(page.locator('#s1000rrEvidence').is_visible())
                        if row['section']=='transponders':
                            self.assertIn('Chip y programación no validados',page.locator('#status').inner_text())
                            self.assertEqual(page.locator('#gallery img').count(),0)
                            if 'Keyless'in row['identity']['system']:self.assertIn('rueda trasera',page.locator('#r1200Evidence').inner_text())
                page.set_viewport_size({'width':375,'height':812})
                self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
