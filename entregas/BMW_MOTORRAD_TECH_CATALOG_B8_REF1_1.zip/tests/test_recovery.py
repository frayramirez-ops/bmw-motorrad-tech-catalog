"""Run with: python3 -m unittest discover -s tests -v"""
import functools
import hashlib
import json
import re
import subprocess
import threading
import unittest
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'BMW_Motorrad_B8_REGENERADO'

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass

class RecoveryTests(unittest.TestCase):
    def test_preserved_data_and_asset_integrity(self):
        html = (APP / 'index.html').read_text()
        self.assertEqual(hashlib.sha256(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>', html, re.S)[1].encode()).hexdigest(), 'f7112e87df0c59590dba8bea2a3029cfe009f6667eacd0e1806b97979a762770')
        data = json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>', html, re.S)[1])
        self.assertEqual([len(data[k]) for k in ['transponders', 'diagnostico']], [500, 315])
        self.assertEqual(hashlib.sha256((APP / 'BMW_Motorrad_Inventario_B8.csv').read_bytes()).hexdigest(), 'e2139545d4612402e77e171ab22f2a874fd5c2641a97d420f0d6e91aab54f77e')
        manifest = json.loads((ROOT / 'docs/recovered-assets.json').read_text())
        self.assertEqual(len(manifest['assets']), 89)
        for item in manifest['assets']:
            self.assertEqual(hashlib.sha256((APP / item['path']).read_bytes()).hexdigest(), item['sha256'])
        for js in APP.glob('*.js'):
            result = subprocess.run(['node', '--check', str(js)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
        bindings = json.loads((ROOT / 'docs/pending-audit-bindings.json').read_text())['bindings']
        self.assertEqual(len({r['recordId'] for r in bindings}), 500)
        for attrs, js in re.findall(r'<script([^>]*)>(.*?)</script>', html, re.S):
            if 'application/json' not in attrs:
                result = subprocess.run(['node', '--check'], input=js, text=True, capture_output=True)
                self.assertEqual(result.returncode, 0, result.stderr)

    def test_browser_consultation_and_pending_audit(self):
        server = ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(QuietHandler, directory=str(APP)))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
                page = browser.new_page()
                page.set_default_timeout(5000)
                errors = []
                failed = []
                page.on('pageerror', lambda e: errors.append(str(e)))
                page.on('response', lambda r: failed.append(r.url) if r.status >= 400 else None)
                page.goto(f'http://127.0.0.1:{server.server_port}/?qa=1', wait_until='networkidle')
                self.assertGreater(page.locator('#v605a option').count(), 1)
                page.locator('#v605Wrap > summary').click()
                page.fill('#v605qA', 'R1250GS')
                self.assertGreater(page.locator('#v605a option').count(), 1)
                page.select_option('#v605a', index=1)
                self.assertIn('pendiente de revisión', page.locator('#v605pair').inner_text())
                page.fill('#globalSearch', 'R1250GSA')
                self.assertGreater(page.locator('#globalResults button').count(), 0)
                page.locator('#globalResults button').first.click()
                self.assertTrue(page.locator('#result').is_visible())
                page.click('[data-tab="transponders"]')
                for id, value in [('year','2024'),('family','F'),('model','F800GS (895 cc)'),('platform','K80 11')]:
                    page.select_option('#'+id, value)
                self.assertTrue(page.locator('#bmwSystemDeclaration').is_visible())
                page.locator('#bmwSystemDeclaration button').filter(has_text='Keyless').click()
                self.assertEqual(page.evaluate('document.body.dataset.bmwConfirmedSystem'), 'keyless')
                self.assertIn('Chip y programación no validados', page.locator('#status').inner_text())
                self.assertEqual(page.locator('#gallery img').count(), 0)
                page.locator('#bmwSystemDeclaration button').filter(has_text='Mecánica').click()
                self.assertEqual(page.evaluate('document.body.dataset.bmwConfirmedSystem'), 'mechanical')
                page.locator('#bmwSystemDeclaration button').filter(has_text='No estoy seguro').click()
                self.assertTrue(page.locator('#bmwUnknownVin').is_visible())
                self.assertEqual(page.evaluate('document.body.dataset.bmwConfirmedSystem'), '')
                self.assertFalse(page.locator('#result').is_visible())
                identities = page.evaluate('''()=>{
                  const before=DB.transponders.map(auditRecordId);
                  const after=[...DB.transponders].reverse().map(auditRecordId).reverse();
                  return {unique:new Set(before).size,stable:JSON.stringify(before)===JSON.stringify(after),
                    pending:DB.transponders.filter(r=>auditRuleFor(r).control==='VINCULO_AUDITORIA_PENDIENTE').length};
                }''')
                self.assertEqual(identities, {'unique':500,'stable':True,'pending':500})
                self.assertGreater(int(page.locator('#bmwCovWith').inner_text()), 0)
                page.fill('#bmwAud64Search', 'F 650 GS')
                self.assertEqual(page.locator('#bmwAud64Count').inner_text(), '4 de 64 fichas pendientes')
                page.set_viewport_size({'width':375,'height':812})
                self.assertFalse(page.evaluate('document.documentElement.scrollWidth > innerWidth'))
                self.assertEqual(errors, [])
                self.assertEqual(failed, [])
                browser.close()
        finally:
            server.shutdown()
            server.server_close()
