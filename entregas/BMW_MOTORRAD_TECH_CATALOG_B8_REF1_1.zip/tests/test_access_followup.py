"""Specialist access evidence cannot certify contacts or erase generation/edition conflicts."""
import csv
import functools
import json
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

SPECIALIST='REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE'
PENDING='PENDIENTE_CONTRASTE_DOCUMENTAL'
HEX='src-b5dea25418298f5f'

class AccessFollowUpTests(unittest.TestCase):
    def test_access_only_changes_and_conservative_exclusions(self):
        changed=[]
        for name,expected in [('r1200gs-reconciliation.json',26),('s1000rr-reconciliation.json',7)]:
            data=json.loads((ROOT/'docs'/name).read_text());rows={r['recordId']:r for r in data['records']}
            sources={s['id']:s for s in data['sources']};observations={o['id']:o for o in data['observations']}
            changes=data['followUp']['changes'];self.assertEqual(len(changes),expected)
            self.assertEqual(sources[HEX]['retrieval']['sha256'],'bd94c49240f77c5ddfde18e7a24837b41d01998e3a920b1bbd22ad4cc3009745')
            self.assertTrue(sources[HEX]['retrieval']['snapshot'].startswith('rc14-hex/'))
            for change in changes:
                row=rows[change['recordId']];ident=row['identity'];claim=next(c for c in row['claims']if c['topic']=='acceso')
                self.assertEqual(row['section'],'diagnostico');self.assertEqual(change['previousClaim']['status'],PENDING)
                self.assertEqual(claim['status'],SPECIALIST);self.assertEqual(claim['sourceIds'],[HEX]);self.assertEqual(claim['observations'],[change['observationId']])
                self.assertTrue(all(c['status']==PENDING for c in row['claims']if c['topic']!='acceso'))
                observation=observations[change['observationId']];self.assertEqual(observation['documentSha256'],sources[HEX]['retrieval']['sha256'])
                if name.startswith('r1200'):
                    air=ident['platform'].startswith('K25')
                    self.assertIn('-air-'if air else'-water-',change['observationId'])
                    self.assertIn('-adv'if 'Adventure'in ident['model']else'-gs',change['observationId'])
                    self.assertIn('asiento trasero'if air else'panel triangular',claim['finding'])
                else:self.assertIn('S1000RR',claim['finding'])
                changed.append(row)
        self.assertEqual(len(changed),33)
        self.assertEqual(sum(r['identity']['system']=='Conector CT'for r in changed),6)
        self.assertEqual(sum(any('CONFLICTO_CRONOLOGICO'in f for f in r['findings'])for r in changed),2)
        with(ROOT/'docs/PENDIENTES_TECNICOS_B8.csv').open(encoding='utf-8-sig',newline='')as f:remaining=[r for r in csv.DictReader(f)if r['afirmacion']=='acceso']
        self.assertEqual(sorted((r['modelo'],r['anio'])for r in remaining),sorted([('R nineT /5','2020'),('K1600GTL','2015'),('K1600GTL','2016'),('R 1100 S Light','2001'),('R 1200 C Montana','2001'),('R 1200 C Phoenix','2001')]))

    def test_browser_all_updated_accesses_keep_exact_context(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                for name,panel_id in [('r1200gs-reconciliation.json','r1200Evidence'),('s1000rr-reconciliation.json','s1000rrEvidence')]:
                    data=json.loads((ROOT/'docs'/name).read_text());by_id={r['recordId']:r for r in data['records']}
                    for change in data['followUp']['changes']:
                        row=by_id[change['recordId']]
                        with self.subTest(record=row['recordId']):
                            page.evaluate('''r=>{setTab(r.section,{reset:true});for(let i=0;i<4;i++){$(ids[i]).value=String(r.identity[ids[i]]);cascade(i+1);}$('system').value=r.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));}''',row)
                            panel=page.locator('#'+panel_id);self.assertTrue(panel.is_visible());self.assertEqual(panel.get_attribute('data-record-id'),row['recordId'])
                            self.assertIn('acceso: referencia de especialista',panel.inner_text())
                            self.assertEqual(page.locator('#system').input_value(),row['identity']['system'])
                            if name.startswith('r1200'):self.assertIn('asiento trasero'if row['identity']['platform'].startswith('K25')else'panel triangular',panel.inner_text())
                page.set_viewport_size({'width':375,'height':812});self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
