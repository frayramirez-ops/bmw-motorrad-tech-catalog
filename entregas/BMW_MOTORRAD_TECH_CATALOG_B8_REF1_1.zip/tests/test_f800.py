"""F800 documentary reconciliation: no technical application is released."""
import csv
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright
from test_recovery import APP, ROOT, QuietHandler

class F800Tests(unittest.TestCase):
    def test_registry_integrity_and_scope(self):
        review = json.loads((ROOT / 'docs/f800-reconciliation.json').read_text())
        html = (APP / 'index.html').read_text()
        embedded = json.loads(re.search(r'<script id="f800EvidenceData"[^>]*>(.*?)</script>', html, re.S)[1])
        self.assertEqual(review, embedded)
        db = json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>', html, re.S)[1])
        self.assertEqual(len(review['records']), 46)
        self.assertEqual(len(review['candidates']), 2)
        self.assertEqual(len({r['recordId'] for r in review['records']}), 46)
        sources = {s['id']:s for s in review['sources']}
        for source in sources.values():
            self.assertIn(source['status'], ['CITADA_NO_VERIFICADA','RECUPERADO_REVISION_PENDIENTE','CONTENIDO_CONSULTADO'])
            url = urlparse(source['url'])
            self.assertEqual(url.scheme, 'https')
            self.assertTrue(url.hostname)
            self.assertNotIn("'", source['url'])
        count = 0
        for row in review['records']:
            identity = row['identity']
            record = next(r for r in db[row['section']] if all(r[k] == v for k,v in identity.items()))
            digest = hashlib.sha256(json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(',',':')).encode()).hexdigest()
            self.assertEqual(digest, row['b8RecordSha256'])
            self.assertEqual(row['status'], 'CONCILIADO_SIN_LIBERACION_TECNICA')
            for claim in row['claims']:
                count += 1
                self.assertIn(claim['status'], ['PENDIENTE_CONTRASTE_DOCUMENTAL','DOCUMENTADO_EN_EDICION_APLICABILIDAD_PENDIENTE','OPCION_DOCUMENTADA_APLICABILIDAD_PENDIENTE','HOMOLOGACION_DOCUMENTADA_UNIDAD_PENDIENTE','REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE'])
                self.assertTrue(set(claim['sourceIds']).issubset(sources))
        self.assertEqual(count, 210)
        observations = {o['id']:o for o in review['observations']}
        self.assertEqual(len(observations), 30)
        documented = 0
        for row in review['records']:
            for claim in row['claims']:
                if claim['status'] == 'PENDIENTE_CONTRASTE_DOCUMENTAL':
                    continue
                documented += 1
                self.assertTrue(claim['observations'])
                for id in claim['observations']:
                    observation = observations[id]
                    source = sources[observation['sourceId']]
                    self.assertEqual(source['status'], 'CONTENIDO_CONSULTADO')
                    self.assertEqual(observation['documentSha256'], source['retrieval']['sha256'])
        self.assertEqual(documented, 98)
        self.assertEqual(sum(s['status']=='CONTENIDO_CONSULTADO' for s in sources.values()), 16)
        for row in review['records']:
            for claim in row['claims']:
                if claim['topic']=='conector':
                    self.assertEqual(claim['status'], 'PENDIENTE_CONTRASTE_DOCUMENTAL')
                if row['section']=='transponders' and row['generation']!='F800GS_895' and claim['topic'] in ['antena','sistema']:
                    for id in claim['observations']:
                        edition=sources[observations[id]['sourceId']]['documentEdition']
                        self.assertEqual('Adventure' in edition, row['generation']=='F800GS_ADVENTURE_798')
        with (ROOT / 'docs/F800_AFIRMACIONES.csv').open(encoding='utf-8-sig', newline='') as f:
            exported = list(csv.DictReader(f))
        self.assertEqual(len(exported), count)
        with (ROOT / 'docs/F800_PENDIENTES_RESOLUCION.csv').open(encoding='utf-8-sig', newline='') as f:
            pending = list(csv.DictReader(f))
        self.assertEqual(len(pending), 112)
        self.assertEqual(len({(x['record_id'],x['afirmacion']) for x in pending}), 112)
        self.assertTrue(all(x['via_resolucion'] and x['siguiente_accion'] for x in pending))
        self.assertEqual({(x['record_id'],x['afirmacion']) for x in pending},
          {(row['recordId'],c['topic']) for row in review['records'] for c in row['claims'] if c['status']=='PENDIENTE_CONTRASTE_DOCUMENTAL'})
        self.assertEqual({x['record_id'] for x in exported}, {x['recordId'] for x in review['records']})
        for candidate in review['candidates']:
            self.assertEqual(candidate['identity']['year'], 2027)
            self.assertEqual(candidate['status'], 'INVENTARIO_CANDIDATO_NO_INTEGRADO')

    def test_all_selectable_f800_records(self):
        review = json.loads((ROOT / 'docs/f800-reconciliation.json').read_text())
        rows = [r for r in review['records'] if r['identity']['system'] != 'Keyless (Emergencia)']
        self.assertEqual(len(rows), 43)
        server = ThreadingHTTPServer(('127.0.0.1',0), functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page = browser.new_page()
                page.set_default_timeout(5000)
                errors = []
                page.on('pageerror',lambda e: errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                for row in rows:
                    with self.subTest(record=row['recordId']):
                        page.evaluate('''row=>{
                          setTab(row.section,{reset:true});
                          for(let i=0;i<4;i++) { $(ids[i]).value=String(row.identity[ids[i]]); cascade(i+1); }
                          const declaration=document.getElementById('bmwSystemDeclaration');
                          if(row.section==='transponders'&&!declaration.hidden) {
                            const label=row.identity.system.includes('Keyless')?'Keyless':'Mecánica';
                            [...declaration.querySelectorAll('button')].find(b=>b.textContent===label).click();
                          } else { $('system').value=row.identity.system; $('system').dispatchEvent(new Event('change',{bubbles:true})); }
                        }''',row)
                        self.assertTrue(page.locator('#f800Evidence').is_visible())
                        self.assertEqual(page.locator('#f800Evidence').get_attribute('data-record-id'),row['recordId'])
                        self.assertIn('sin certificación por VIN',page.locator('#f800Evidence').inner_text())
                        if row['section']=='transponders':
                            self.assertEqual(page.locator('#gallery img').count(),0)
                            self.assertIn('Chip y programación no validados',page.locator('#status').inner_text())
                page.emulate_media(media='print')
                self.assertIn('sin certificación por VIN',page.locator('#f800Evidence').inner_text())
                page.emulate_media(media='screen')
                page.set_viewport_size({'width':375,'height':812})
                self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                page.click('[data-tab="diagnostico"]')
                page.select_option('#year','2000')
                self.assertFalse(page.locator('#f800Evidence').is_visible())
                self.assertEqual(errors,[])
                browser.close()
        finally:
            server.shutdown()
            server.server_close()
