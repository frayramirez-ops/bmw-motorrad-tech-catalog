"""RT periods and GS/Adventure reader locations must not leak across identities."""
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

PENDING='PENDIENTE_CONTRASTE_DOCUMENTAL'

class RTouringTests(unittest.TestCase):
    def test_registry_provenance_and_limits(self):
        review=json.loads((ROOT/'docs/r1250rt-r1300gs-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="rTouringEvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual(len(review['records']),45);self.assertEqual(len(sources),14);self.assertEqual(len(observations),41)
        self.assertEqual(sum(s['status']=='CITADA_SIN_VERIFICAR'for s in sources.values()),1)
        claims=0;documented=0
        for row in review['records']:
            identity=row['identity'];original=next(r for r in db[row['section']]if all(r[k]==v for k,v in identity.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            primary=sources[row['references'][0]['sourceId']]
            self.assertEqual(primary['model'],identity['model']);self.assertLessEqual(primary['editionYear'],identity['year'])
            self.assertEqual(row['zipComparisonStatus'],'NO_CONTRASTADO_EN_ESTE_BLOQUE')
            if identity['model']=='R1250RT':
                self.assertTrue(primary['discovery']['indexEntries'])
                self.assertTrue(all(e['file']==primary['discovery']['filename']for e in primary['discovery']['indexEntries']))
                if identity['year']in[2021,2022]:self.assertTrue(any('CONFLICTO_HISTORICO_CRONOLOGICO'in f for f in row['findings']))
                if row['section']=='diagnostico':self.assertTrue(any('SEMANTICA_HEREDADA'in f for f in row['findings']))
            for c in row['claims']:
                claims+=1
                if c['topic']in['chip','modulo','conector','ubicacion','mercado_equipamiento']:
                    self.assertEqual(c['status'],PENDING)
                if identity['model']=='R1250RT'and c['topic']=='antena':
                    if 'Keyless'in identity['system']and identity['year']<2023 or identity['system']=='Mecánica'and identity['year']>2020:
                        self.assertEqual(c['status'],PENDING)
                if c['status']==PENDING:continue
                documented+=1;self.assertTrue(c['observations'])
                self.assertEqual(c['sourceIds'],[primary['id']])
                for oid in c['observations']:
                    o=observations[oid]
                    self.assertEqual(o['sourceId'],primary['id'])
                    self.assertEqual(o['documentSha256'],primary['retrieval']['sha256'])
                    if identity['model'].startswith('R1300')and c['topic']in['sistema','antena']:
                        self.assertIn('asiento del conductor',o['scope']);self.assertNotIn('rueda trasera',o['scope'])
        self.assertEqual(claims,208);self.assertEqual(documented,61)

    def test_browser_all_selections_and_context_switch(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/r1250rt-r1300gs-reconciliation.json').read_text())
                visible=[r for r in review['records']if r['identity']['system']!='Keyless (Emergencia)']
                self.assertEqual(len(visible),34)
                select='''row=>{
                    setTab(row.section,{reset:true});
                    for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                    const declaration=document.getElementById('bmwSystemDeclaration');
                    if(row.section==='transponders'&&!declaration.hidden){
                      const type=row.identity.system.includes('Keyless')?'Keyless':'Mecánica';
                      [...declaration.querySelectorAll('button')].find(b=>b.textContent===type).click();
                    }
                    $('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));
                }'''
                for row in visible:
                    with self.subTest(record=row['recordId']):
                        page.evaluate(select,row)
                        self.assertTrue(page.locator('#rTouringEvidence').is_visible())
                        self.assertEqual(page.locator('#rTouringEvidence').get_attribute('data-record-id'),row['recordId'])
                        for panel in ['f800Evidence','s1000rrEvidence','r1250Evidence','r1200Evidence']:
                            self.assertFalse(page.locator('#'+panel).is_visible())
                        text=page.locator('#rTouringEvidence').inner_text()
                        if row['identity']['model'].startswith('R1300'):
                            self.assertIn('asiento del conductor',text);self.assertNotIn('rueda trasera',text)
                        if row['section']=='transponders':
                            self.assertIn('Chip y programación no validados',page.locator('#status').inner_text());self.assertEqual(page.locator('#gallery img').count(),0)
                page.set_viewport_size({'width':375,'height':812})
                self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                old=json.loads((ROOT/'docs/r1200gs-reconciliation.json').read_text())['records'][0]
                page.evaluate(select,old)
                self.assertTrue(page.locator('#r1200Evidence').is_visible());self.assertFalse(page.locator('#rTouringEvidence').is_visible())
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
