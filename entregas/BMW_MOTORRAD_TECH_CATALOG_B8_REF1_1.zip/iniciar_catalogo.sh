#!/bin/sh
catalog_root=$(CDPATH= cd "$(dirname "$0")" && pwd) || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo 'Necesitas Python 3 para iniciar el catálogo.' >&2
  exit 1
fi
exec python3 "$catalog_root/scripts/serve_catalog.py" "$@"
