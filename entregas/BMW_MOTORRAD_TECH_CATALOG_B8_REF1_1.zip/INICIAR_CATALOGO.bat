@echo off
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 goto python
py -3 scripts\serve_catalog.py
if errorlevel 1 pause
exit /b
:python
where python >nul 2>&1
if errorlevel 1 goto missing
python scripts\serve_catalog.py
if errorlevel 1 pause
exit /b
:missing
echo Instala Python 3 desde https://www.python.org/downloads/ y vuelve a abrir este archivo.
pause
