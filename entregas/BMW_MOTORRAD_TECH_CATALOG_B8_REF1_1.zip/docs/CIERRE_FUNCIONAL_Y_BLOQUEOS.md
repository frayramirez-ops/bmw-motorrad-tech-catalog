# Cierre de verificación funcional local — B8-RC15

La recuperación del software y el inventario documental están preparados para revisión local. Se han preservado las 815 fichas B8 y sus fuentes originales. El estado documental RC16 conserva 3760 afirmaciones: 1306 con respaldo limitado y 2454 pendientes. No se declara certificación técnica ni cierre del proyecto completo.

## Trabajo de cierre realizado

- Impresión corregida: se evita que un panel grande deje casi vacía la primera página y se omiten el botón flotante, inventarios generales y avisos de auditoría ajenos a la ficha seleccionada. Se mantienen identidad, límites y referencias documentales.
- Resumen histórico duplicado desactivado en la consulta y en impresión porque mostraba resultados de transponder fuera del control actual. La ficha principal, los controles de consulta y paneles documentales permanecen; los datos originales no se eliminan.
- Entrega extraída en una carpeta nueva, con espacios y acentos, fuera del checkout. Se ejecutó su propio iniciador Python desde otro directorio, con solicitudes remotas del navegador bloqueadas.
- Se contrastaron por HTTP los 107 archivos de aplicación contra sus hashes: catálogo, CSS/JavaScript, recursos y CSV. Se comprobaron cobertura, consulta de pendientes y las 24 imágenes de biblioteca cargándolas al recorrerlas.
- Se generaron 14 PDF: transponders y diagnóstico para C, F, G, K, M, R y S. Se verificó identidad y texto; las siete muestras de transponder conservan la restricción en su primera página. Se inspeccionaron visualmente muestras F/transponder y C/diagnóstico; no todas las páginas de cada archivo.

Los resultados exactos están en `VALIDACION_RC15.json` y `VALIDACION_ENTREGA_LOCAL_RC15.json`. Los PDF se incluyen en `muestras_impresion/`. La validación de entrega se puede repetir con:

```sh
python3 scripts/verify_local_delivery.py --archive RUTA_AL_ZIP --output-dir CARPETA_NUEVA
```

Este comando de mantenimiento necesita Playwright, Chromium y Poppler. Para usar el catálogo solo hace falta Python 3 y navegador; no instala paquetes ni despliega un servicio público.

## Límites que impiden declarar terminado el proyecto completo

| Pendiente | Evidencia o acción necesaria |
|---|---|
| Datos técnicos y programación | Recuperar diccionario F001–F189, revisiones y relación de reglas/fichas del desarrollador; contrastar componentes, mercado, variantes y contactos con evidencia aplicable. Las 2454 afirmaciones siguen abiertas; las 1306 referencias limitadas tampoco certifican por VIN. |
| Alcance y aceptación original | Recuperar la matriz original y establecer padrón BMW por mercado para el objetivo 2003–2027. B8 contiene 2000–2026. El usuario aceptó posteriormente el alcance de referencia local; véase `ACEPTACION_REFERENCIA_1_0.md`. La matriz original sigue pendiente para cualquier ampliación al objetivo técnico original. |
| Imágenes | Aportar procedencia y permisos/atribuciones. Recuperar un recurso no acredita su licencia. |
| Equipo del usuario | Ejecutar y aceptar Windows/macOS e impresoras físicas en esos sistemas. Esta validación se realizó en Linux; no los emula ni los certifica. |
| Recepción de la entrega | Utilizar un canal que permita al usuario recibir el paquete. No hay herramienta de adjuntar/exportar archivos en esta sesión; la única herramienta de archivos encontrada descarga entradas al entorno. Verificar un ZIP local no demuestra su recepción. |

No hay motocicleta disponible, ni se recuperaron las revisiones posteriores al ZIP original. Estos faltantes no se resuelven repitiendo pruebas de software o sustituyendo datos por suposiciones.

## Solicitud lista para enviar al desarrollador

> Necesito la última entrega completa del BMW Motorrad Tech Catalog y los cambios posteriores al ZIP recuperado; el diccionario F001–F189 con documentos/páginas; la relación entre reglas de auditoría/programación y fichas; la matriz original de aceptación y padrón por mercado; y las evidencias y permisos originales de los recursos. Incluye versión, fecha, inventario y hashes de los archivos, distinguiendo datos confirmados, condicionados y pendientes.

La solicitud ampliada está en `SOLICITUD_AL_DESARROLLADOR_ORIGINAL.md`. No se envió ningún mensaje externo. No se publicó ni desplegó el catálogo.

## Seguimiento documental RC16

La verificación funcional y los PDF aquí descritos corresponden a RC15. RC16 incorpora ocho referencias acotadas sobre sistema/antena y preserva las restricciones. Sus pruebas están en `VALIDACION_RC16.json`; la evidencia temporal está en `TEMPORALIDAD_MANUALES_RC16.md`. Las muestras de la carpeta `muestras_impresion/` siguen identificadas como RC15.
