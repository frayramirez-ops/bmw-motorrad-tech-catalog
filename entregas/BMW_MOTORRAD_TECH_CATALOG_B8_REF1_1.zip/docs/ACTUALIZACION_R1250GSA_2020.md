# R1250GS Adventure 2020 — datos de referencia actualizados

Se atiende la observación del usuario: la conciliación mostraba demasiados «por confirmar» sin dar prioridad a los datos disponibles. B8-REF1.1 corrige presentación y evidencia; no rellena componentes sin fuente.

## Datos visibles de Adventure 2020 K51 11

| Dato | Referencia documental |
|---|---|
| Keyless Ride | Opción de encendido por pulsador; manual español 01.2019, PDF 72–73 (impresas 70–71). No se presume que toda moto lo equipe. |
| Pila del mando | CR2032, positivo hacia arriba; PDF 76 / impresa 74. No identifica el transponder. |
| Alcance de recepción | Aproximadamente 1 m; PDF 73 / impresa 71. |
| Emergencia | Llave auxiliar o mando sin pila en contacto con guardabarros trasero, a la altura de la antena; PDF 75 / impresa 73. |
| Identificación del mando en certificado | HUF5750 / FCC YGOHUF5750; PDF 288. Es una referencia del mando; no identifica módulo ni semiconductor. |
| Cerraduras auxiliares | Asiento, Topcase y maletas accionables manualmente; PDF 72. No implica encendido de giro. |
| Variante mecánica | Cerradura de giro y EWS con antena anular; PDF 70–71. Alternativa de manual multiequipamiento, no oferta universal por mercado. |
| Diagnóstico | Detrás del revestimiento lateral derecho, en la zona de batería; PDF 25 / impresa 23. |
| Acceso al diagnóstico | Tapa de batería y soporte con gancho/bloqueos; PDF 213 y 217. Intervención de personal cualificado. |

Manual: https://manuals.bmw-motorrad.com/manuals/BA-Extern/IN/BA-INTERNET-COM/PDF/R_0J51_RM_0119_03.pdf

SHA-256: `11a383e5d1c14b46a6adf07f57677c461d7c7e27764c2513e583ddd722e7d522`. Portada, colofón (PDF 304) y pasajes contrastados. Ilustraciones de emergencia y acceso inspeccionadas; los PDF BMW no se redistribuyen dentro del paquete.

## Plataforma y fecha

Índice oficial BMW consultado el 6 de noviembre de 2026: K51 11/0J51 EUR desde 03/2019 enlaza la edición 01.2019; K51 MU2/0M11 desde 08/2020 enlaza la obra 06.2020. El año de edición no equivale al año-modelo. No se reasigna la identidad original de las fichas ni se traslada automáticamente evidencia entre subgeneraciones.

## Corrección de once ubicaciones

Las ocho obras originales de GS y Adventure dicen explícitamente que el diagnóstico está detrás del revestimiento lateral derecho. Se añaden ocho observaciones por página y once afirmaciones de ubicación pasan de pendientes a documentadas en su edición. Los estados anteriores quedan en `r1250gs-reconciliation.json`, campo `referenceUpdate11.claimChanges`. Total del bloque: 209 afirmaciones, 102 referencias limitadas y 107 pendientes. Total B8: 1317 limitadas y 2443 pendientes.

## Presentación y límites

Todas las familias separan información documentada de campos sin evidencia. Los datos conocidos ya no repiten «aplicación individual pendiente» como si no existiera referencia de modelo. Las restricciones de chip/programación se mantienen y el aviso deja de afirmar que toda la información técnica es inconfiable. La copia restringida continúa impidiendo exportar como confirmado un resultado histórico.

La ficha detallada nueva corresponde exactamente a Adventure 2020 K51 11. No se copia la pila o el mando Keyless a la variante mecánica ni a otros años. HUF5750 no se convierte en módulo X_SLZ o chip AES128/8A. Siguen pendientes chip, módulo de autorización, contactos y mercado donde falta evidencia específica.

Conservación: `catalogData`, originales B8 y los trece registros de otras familias no cambian. La interfaz y las reglas no habilitan programación. Las cifras de documentos anteriores pertenecen a sus versiones históricas.
