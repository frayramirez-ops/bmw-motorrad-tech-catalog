# Validación de funciones de uso diario

## Cambios

- **Copia de resumen:** el botón anterior leía resultado y notas directamente de la base aunque la ficha estuviera restringida. Ahora exporta identidad y aviso NO VERIFICADO, sin resultado técnico ni notas históricas de esa ficha.
- **Copia de ficha:** consulta el estado de restricción y el aviso de la ficha, no únicamente texto que podía estar fuera del contenedor. Ambas copias conservan el mismo límite de liberación.
- **Impresión:** espera carga/decodificación de imágenes con un límite de 2500 ms por imagen. Los listeners se retiran y el botón se reactiva aunque una imagen no responda. Al agotarse el plazo, una imagen pendiente puede omitirse: no se declara que todas las imágenes se hayan impreso.
- **Favoritos:** separados los identificadores de información del panel y de estado del botón, antes duplicados dinámicamente. Se conserva el límite existente de 30 favoritos y su selección por identidad exacta.
- **Notas:** carga defensiva ante entradas inválidas; una entrada nula no rompe la inicialización. Se mantienen notas en memoria y visibles cuando falla almacenamiento, permitiendo exportarlas durante la sesión. Recargar/cerrar puede perder las notas no persistidas; la interfaz lo indica.
- **Importación de notas:** rechaza esquemas/entradas inválidos, evita duplicados y aplica un límite acumulado de 10000 notas. Si se supera, no incorpora parcialmente el archivo ni elimina las notas existentes. Se mantiene el límite previo de archivo de 5 MB.

No se cambian `catalogData`, los JSON históricos ni el CSV original. Las notas de usuario no modifican estados documentales ni autorizan compatibilidades.

## Pruebas automatizadas

`tests/test_daily_workflow.py` utiliza contextos de Chromium aislados, sin abrir ni modificar almacenamiento real de un usuario. Sus seis pruebas comprueban:

1. Los dos botones de copia de una ficha restringida conservan el aviso y excluyen el resultado y notas técnicas históricas. El mecanismo clipboard se intercepta en el navegador de prueba; no es una prueba de permisos del portapapeles del equipo del usuario.
2. Un favorito sobrevive a recarga y restaura año/modelo/plataforma/sistema exactos, con la restricción intacta; también se puede quitar.
3. Una nota se guarda, sobrevive a recarga, se exporta y restaura sin duplicados. Las entradas nulas y una importación acumulada de más de 10000 notas se rechazan conservando la nota existente. El texto con etiquetas se representa como texto.
4. Entradas locales dañadas no rompen el arranque y permiten añadir una nota válida.
5. Un error de cuota al guardar mantiene la nota visible y exportable en esa sesión.
6. Una imagen HTTP que no responde no bloquea la impresión. Se genera un PDF real y se extrae su texto para comprobar el aviso de ficha no verificable y la ausencia del resultado técnico restringido de prueba.

Se ejecuta junto a las siete pruebas anteriores con:

```sh
python3 -m unittest discover -s tests -v
```

## Límites

La extracción del PDF valida texto y restricciones; no sustituye revisión visual de todos los modelos, páginas y tamaños. No se probaron impresoras físicas, diálogos del sistema, otros navegadores, migración entre orígenes ni restauración de imágenes personales. Almacenamiento y favoritos pertenecen al origen/navegador y no se sincronizan con un servidor. Una copia de recuperación del código no contiene automáticamente las notas del navegador de una persona.

No se publicaron ni desplegaron cambios. Los porcentajes documentales F800GS y S1000RR no aumentan por estas reparaciones de interfaz.
