# Conciliación G / M — RC12

24 fichas B8: 12 transponders y 12 diagnóstico, todas seleccionables. Incluye 16 G650GS (2009–2016), dos G310R y seis M1000R/RR/XR (2026). Registro: `gm-reconciliation.json`; exportaciones `GM_AFIRMACIONES.csv` y `GM_PENDIENTES.csv`. No se modifican identidades, resultados, códigos F ni fuente B8.

## Resultado y límites

108 afirmaciones: cuatro accesos documentados en edición, ocho accesos de especialista y 96 pendientes. Los 60 aspectos de transponder permanecen pendientes, aunque contengan observaciones. Son 15 fuentes: 12 PDF propios y tres documentos web guardados (índice BMW LANGUAGE 01, guía HEX y listado BMW México). Hay 37 observaciones. La consulta del listado comercial usa la instantánea recuperada, sin presentarla como padrón vigente de producción por año/mercado.

- G650GS: las cinco ediciones describen llave y cerradura mecánica. No acreditan presencia ni ausencia de inmovilizador; no se aplica EWS de F650 bicilíndrica. El acceso HEX corresponde a la fila G650GS 2008–2016: bajo panel principal derecho, encima del radiador, sin retirarlo; no se usa la fila de G650 X.
- G310R: edición 02.2022 con acceso diagnóstico retirando asiento. No identifica plataforma/sistema ni disponibilidad de una unidad 2026; esos campos B8 se conservan pendientes. La descripción de llave no demuestra ausencia de transponder.
- M1000R/RR/XR: manuales propios de cada modelo, con edición anterior y 03.2026 (índice desde 08.2026). No se usa una edición para cubrir automáticamente todo 2026. RR describe cerradura mecánica y EWS; R y XR, mando de radio y respaldo en panel tras asiento o depósito, respectivamente. La ficha B8 sin plataforma/sistema identificado no recibe asignación automática: las observaciones no cambian sus cinco estados pendientes.
- Los apéndices EWS4/BECOM/TMS37145/DST80/TMS3705 no identifican semiconductor del mando Keyless ni equipo instalado en una unidad. Ninguna afirmación de chip/módulo se libera.
- Accesos M: R/RR por asiento trasero o tapa de colín según paquete; XR retirando asiento. El acceso descrito no acredita forma/contactos/adaptador: conector y ubicación individual permanecen pendientes en las 12 fichas.
- Desfase: índice y B8 asignan 11/2010 al archivo G_0188_RM_1111, cuyo colofón dice 11.2011. Se registra en cuatro fichas (transponder y diagnóstico de 2011/2012); no se convierte periodo en año certificado de producción.
- G650GS 08.2008: portada PDF 1 y colofón PDF 139 comprobados visualmente por texto nativo dañado. Order No. 01 41 7 714 331, 08.2008, 1st edition. PDF 140–143 contienen suplemento de suspensión fechado 02.2007, separado de la edición base. La metadata de creación PDF no sustituye colofón.

No se compararon resultados ZIP en este bloque, ni se reconstruyó diccionario F. Los PDF externos no se incluyen en la distribución ni se presume autorización de redistribución.

## Páginas de contraste

Son páginas PDF, sin equivalencia automática con numeración impresa. Las observaciones de transponder son referencias pendientes de aplicabilidad, no confirmación del campo B8.

| Modelo | Edición | Llave/encendido PDF | EWS/respaldo PDF | Acceso PDF | Homologación PDF |
|---|---|---:|---:|---|---:|
| G310R | 02.2022, 2nd edition | 40 | — | 108 | — |
| G650GS | 04.2010, 2nd edition | 30 | — | — | — |
| G650GS | 08.2008, 1st edition; colophon PDF 139 visually checked | 30 | — | — | — |
| G650GS | 08.2012, 5th edition | 30 | — | — | — |
| G650GS | 08.2014, 6th edition | 30 | — | — | — |
| G650GS | 11.2011, 3rd edition | 30 | — | — | — |
| M1000R | 03.2026, 2nd edition | 82 | 84 | 213 | 272 |
| M1000R | 08.2024, 1st edition | 82 | 84 | 211 | 272 |
| M1000RR | 03.2026, 2nd edition | 76 | 77 | 207,208 | 266 |
| M1000RR | 08.2024, 1st edition | 76 | 77 | 207 | 268 |
| M1000XR | 03.2026, 4th edition | 82 | 84 | 203,204 | 267 |
| M1000XR | 04.2025, 3rd edition | 84 | 86 | 203,204 | 271 |

URL, hash, alcance y entradas del índice por plataforma/mercado están en el registro. Los hashes se contrastaron con los 12 PDF y tres documentos web locales; no acreditan autenticidad por sí solos.

## Validación

`test_gm.py` comprueba integridad B8/registro embebido, procedencia de observaciones, dos ediciones por M, campos desconocidos, 60 afirmaciones de transponder pendientes, cuatro desfases y CSV. Chromium recorre las 24 selecciones, exclusión de otros paneles y móvil. `test_coverage.py` comprueba inventario 815/815, las 3760 afirmaciones y CSV global de 2495 pendientes; los desconocidos futuros siguen sin recibir conteos ficticios. Resultados: `VALIDACION_RC12.json`.
