# F800GS — conciliación implementada y contraste pendiente

## Resultado de la etapa local

Se conciliaron las 46 fichas F800GS existentes en B8, sin alterar `catalogData` ni el CSV original:

| Generación | IMMO | Diagnóstico | Total |
|---|---:|---:|---:|
| F800GS 798 cc, 2008–2018 | 11 | 11 | 22 |
| F800GS Adventure 798 cc, 2013–2018 | 6 | 6 | 12 |
| F800GS 895 cc, 2024–2026 | 9 | 3 | 12 |
| Total | 26 | 20 | 46 |

El catálogo oculta tres entradas históricas de emergencia Keyless como sistemas independientes. Se conservan en la conciliación, pero las pruebas de selección cubren 43 fichas visibles. La emergencia no constituye una tercera arquitectura.

`f800-reconciliation.json` contiene identidades estables, hashes de las fichas originales, resultados de ambas entregas, referencias con procedencia, conflictos y límites por afirmación. Una copia idéntica se incorpora al HTML como datos de la interfaz para funcionar sin descargar JSON externo.

`F800_AFIRMACIONES.csv` inventaría 210 afirmaciones: 26 de sistema, 26 de chip, 26 de módulo, 26 de antena, 46 de mercado/equipamiento, 20 de conector, 20 de ubicación y 20 de acceso. Todas están pendientes de contraste documental; ese número no mide compatibilidades confirmadas.

Se recuperaron 22 URLs distintas como citas, no como fuentes verificadas ni como traducciones de los códigos F. La interfaz muestra el estado y los enlaces en la ficha exacta y los conserva al imprimir. No muestra automáticamente los resultados del ZIP como datos aprobados.

## Conciliación entre entregas

39 fichas tienen equivalencia exacta en el ZIP. Siete no la tienen:

- Tres entradas Keyless de emergencia de F800GS 895 cc, 2024–2026.
- Cuatro diagnósticos CT de transición: GS estándar y Adventure, 2015 y 2016.

No se reemplazan esos CT por C10/C16 mediante equivalencia aproximada ni se vincula una ficha de emergencia a la principal como si fueran la misma identidad.

Las dos entradas de 2027 del ZIP (IMMO y diagnóstico) quedan en `candidates`, como inventario no integrado. No se añaden a los selectores ni se certifica ese año-modelo.

## Decisiones por generación

- **798 cc:** conservar las referencias heredadas a ID46 y alternativas ID46/DST80 sin resolver por año. La mención EWS o una antena no certifica semiconductor, módulo o aplicación por VIN.
- **Adventure:** mantener identidad y plataforma propias. Las citas de manuales de GS estándar presentes en el ZIP no acreditan Adventure automáticamente.
- **895 cc:** mantener Mecánica y Keyless como alternativas de catálogo sujetas a equipamiento. No adoptar la atribución HUF/8A del ZIP sobre el estado pendiente de B8. No atribuir el chip a un manual que solo describe EWS.
- **Diagnóstico:** conservar separados ubicación, acceso y formato del puerto. Una figura bajo el asiento o un procedimiento de soporte no acredita C16 para todos los años y mercados.
- **Fuentes F:** permanecen sin resolver. Los nuevos enlaces tienen identificadores independientes y no sustituyen esos códigos.

## Bloqueo externo de verificación

El acceso de solo lectura al manual oficial `F_0219_RM_0911_F800GS%20LCI_01.pdf` fue bloqueado por el proxy: `Tunnel connection failed: 403 Forbidden`. No se descargó ni leyó ese PDF en esta etapa. Las citas del ZIP y B8 no sustituyen esa lectura.

Se guardó un borrador de acceso para `manuals.bmw-motorrad.com`, `www.bmw-motorrad.com.mx` y `www.hexgs911.com`, preservando los presets existentes. El guardado no aplica ni publica configuración. Para continuar el contraste, el usuario debe revisar/guardar y publicar la configuración del entorno; alternativamente puede aportar los PDF originales y sus ediciones. Esto no requiere desplegar la aplicación.

Una vez disponible el acceso: comprobar edición, modelo, páginas y afirmación concreta; registrar extracto, hash del documento, mercado y límites. Solo entonces evaluar liberación por afirmación. Las fuentes aftermarket y sus permisos se revisarán separadamente; no son evidencia OEM por defecto.

## Aceptación y pruebas

Implementado: cobertura local de 46 identidades; 210 afirmaciones con estado explícito; procedencia y diferencias; candidatos separados; presentación por ficha; datos originales conservados; restricciones técnicas intactas.

Pendiente: lectura de documentos externos, validación por edición/mercado/VIN cuando proceda y liberación de afirmaciones respaldadas. No se declara terminada la certificación técnica F800GS ni reconstruidos los códigos de fuente.

Ejecutar `python3 -m unittest discover -s tests -v`. La regresión F800 compara el registro incorporado con el documental, sus hashes, fuentes y alcance; representa las 43 fichas seleccionables, comprueba estado pendiente, ausencia de galería técnica liberada, cambio de contexto y un estado móvil. La comprobación de impresión acredita presencia del texto, no una revisión visual de PDF impreso.

## Actualización: acceso recuperado y contraste documental

Esta sección sustituye el bloqueo de acceso y el estado inicial «todas pendientes» descritos arriba. A pesar del error mostrado por la publicación del entorno, la consulta real a BMW respondió HTTP 200. No es necesario seguir reintentando la publicación para estas consultas.

Se recuperaron 14 PDF oficiales y la página vigente de BMW México, con SHA-256 registrado por fuente. HEX respondió HTTP 503: no se marca su contenido como verificado. De las 22 URLs del registro: seis tienen contenido consultado, nueve se recuperaron pero siguen pendientes de revisión sustantiva y siete permanecen como citas no verificadas. Los originales descargados se conservan en `/workspace/catalog-recovery/evidence/`; los hashes y localizadores están en el registro versionable, sin redistribuir los PDF en el repositorio.

Lecturas documentadas:

| Documento | Localizador | Alcance confirmado |
|---|---|---|
| F800GS 09.2011, 5.ª edición | PDF 37 / impresa 35 | EWS y antena anular en cerradura de encendido |
| F800GS Adventure 02.2013, 1.ª edición | PDF 33 / impresa 31 | EWS y antena anular en cerradura de encendido, con manual propio Adventure |
| F800GS 07/2023, 1.ª edición | PDF 87, 201 y 275 | Emergencia Keyless bajo asiento, acceso al diagnóstico y apéndice EWS4 |
| F800GS 03.2024, 2.ª edición | PDF 87, 195 y 274 | Mismos temas, con localizadores propios |
| F800GS abril 2025, 3.ª edición | PDF 87, 200 y 280 | Mismos temas, con localizadores propios |
| BMW Motorrad México, página vigente | Equipamiento opcional | Keyless Ride figura como opción; sin acreditación histórica por MY |

Los nombres de archivo no coinciden necesariamente con la fecha de edición impresa. Se registra esta última y no se deduce el año-modelo por el nombre del PDF.

Corrección de una afirmación histórica: los apéndices de las ediciones modernas sí identifican EWS 4, BECOM Electronics, TMS37145/Type DST80 y TMS3705. No es correcto afirmar que los manuales nunca mencionan esos componentes. Esa homologación tampoco identifica el módulo o chip instalado en un VIN ni el semiconductor interno del mando Keyless. No se adopta la atribución HUF/8A del ZIP como identificación de unidad.

Estado actualizado de las 210 afirmaciones: 46 documentadas en edición con aplicación pendiente, nueve de opción documentada con equipamiento pendiente, seis con homologación documentada y unidad pendiente, 149 aún sin contraste documental. Son 61 asociaciones con evidencia limitada, no 61 aplicaciones certificadas. Las fuentes elegidas por generación se presentan como referencia de edición, no como prueba de todos los años de esa generación. Los 17 códigos F del bloque permanecen sin equivalencia demostrada.

La aplicación muestra los hallazgos, edición y páginas dentro de cada ficha. `auditRuleFor` sigue restringiendo las 500 fichas: ninguna referencia de programación se libera mediante esta capa documental. La regresión comprueba 12 observaciones, sus vínculos y hashes y las 43 consultas F800GS seleccionables.

## Segunda revisión documental: ediciones antiguas y diagnóstico

Se completó la revisión de los localizadores relevantes en los nueve PDF oficiales restantes. El estado vigente pasa a 15 fuentes consultadas (14 manuales y la página de BMW México) y siete citas no verificadas. «Consultada» significa que se revisaron las secciones registradas, no que el manual certifique todas las afirmaciones de la ficha.

Las dos ediciones 05.2009 tienen texto defectuoso en portada/colofón; la fecha y edición se comprobaron en las imágenes de sus últimas páginas. Las páginas EWS sí permiten extracción legible. Se registró el método y hash de la imagen de colofón. No se dedujo la edición por el nombre del archivo.

Ediciones adicionales: F800GS 02.2008, 05.2009 (dos variantes), 06.2010, 06.2012, 08.2015 y 04.2016; Adventure 08.2015 y 01.2017. Las observaciones de EWS se asociaron a los documentos de la generación y modelo correspondientes. Las fichas Adventure no heredan la confirmación de antena de un manual estándar.

El manual estándar 04.2016 sitúa el conector bajo el asiento en PDF 16/impresa 14 y describe acceso en PDF 135–136/impresas 133–134. Adventure 01.2017 lo sitúa en PDF 16/impresa 14 y explica el acceso en PDF 132/impresa 130. Estas observaciones se aplican como referencia de edición a las cinco fichas diagnósticas que ya citaban esos PDF en B8. No se sustituye CT ni se afirma número de pines.

Estado vigente: **71/210 afirmaciones tienen respaldo documental limitado**: 56 de contenido de edición, nueve de opción y seis de homologación. **139/210 siguen pendientes de contraste**. Ninguna está certificada por VIN ni liberada para programación. Hay 26 observaciones con localizador y hash; la prueba automatizada protege que Adventure use su manual propio y que los 20 formatos de conector sigan pendientes.

La búsqueda de «10/16 pin» y variantes en el texto de estos manuales no encontró una afirmación suficiente para confirmar formato. Esto no demuestra que la información no exista en diagramas u otras fuentes; permanece pendiente de inspección específica y de la unidad. Los códigos F siguen sin resolver, al igual que identificación individual de semiconductores y piezas.

## Tercera revisión: guía HEX y clasificación de lo pendiente

La guía HEX de localización volvió a responder HTTP 200 tanto en inglés como en español. Se consultó la fila «F-series 798 cm3 inline twin», que incluye F800GS 2007–2018 y Adventure 2013–2018. Indica retirar el asiento y localizar el conector delante del depósito trasero. Se registró el hash de la página inglesa consultada y el localizador de la fila, sin descargar imágenes de terceros ni atribuir evidencia OEM a HEX.

La columna de interfaces compatibles muestra dispositivos de 10 pines y una indicación «2015+» junto a otra interfaz. Esto constituye contexto de transición, no prueba de que un VIN específico equipe C10/C16. Las cuatro fichas CT siguen intactas. Las referencias a ubicación y acceso ahora incluyen la guía HEX, diferenciada de los manuales BMW.

Se revisó además PDF 89/impresa 83 de las tres ediciones modernas: la sección EWS menciona antena en «ignition lock / R/C ignition lock». Se documenta con su alcance multiequipamiento; no se confunde con la antena de emergencia Keyless bajo asiento de PDF 87.

**Estado vigente: 98/210 afirmaciones (46,7 %) tienen respaldo limitado**, distribuido en 59 referencias de edición, 24 de especialista, nueve de opción y seis de homologación. **112/210 (53,3 %) continúan sin evidencia aplicable suficiente**. Esto no es progreso global ni certificación de compatibilidades. Hay 30 observaciones con localizador y hash, 16 fuentes consultadas y seis citas sin verificar.

Las 112 pendientes se entregan con identidad y acción concreta en `F800_PENDIENTES_RESOLUCION.csv`:

| Tema | Pendientes | Evidencia requerida |
|---|---:|---|
| Mercado y equipamiento | 46 | Fecha/variante/mercado y opciones de fábrica de la unidad; el manual multiequipamiento no las determina |
| Chip | 23 | Lectura e identificación del componente y referencia aplicable; no atribuirlo por antena o cilindrada |
| Módulo | 23 | Pieza instalada, fabricante y número de parte, contrastados con aplicación OEM |
| Conector | 20 | Inspección de forma/contactos o documento OEM específico; respetar transiciones CT |

Estas son vías de resolución, no una afirmación de que toda evidencia pueda obtenerse exclusivamente por inspección física: documentos OEM específicos pueden resolver parte de ellas. Los datos de una unidad no se generalizarán a toda una familia, mercado o año.

La interfaz muestra la siguiente acción dentro de cada afirmación. Los candidatos de 2027 y los códigos F siguen separados/sin resolver; no se liberó programación ni se alteró `catalogData` o el CSV original.
