# Trabajo posterior a la versión de referencia

B8-REF1.0 cierra el software en el alcance local de referencia aceptado. No se necesita otra candidata para recorrer de nuevo las familias ya inventariadas. Las 2454 afirmaciones abiertas constituyen trabajo técnico futuro, con evidencia específica y prioridad elegida; las 1306 referencias limitadas tampoco equivalen a certificación.

| Prioridad | Acción concreta | Criterio de salida |
|---|---|---|
| Recepción y uso | Facilitar un canal de entrega accesible y abrir la versión en el equipo del usuario. | Recepción confirmada, consulta de una ficha, exportación/restauración de notas e impresión probadas en ese equipo. No publicar como alternativa automática. |
| Material original | Solicitar diccionario F001–F189, relación de reglas/fichas, revisiones y matriz original. | Archivos recibidos con procedencia e inventario; asociación verificable antes de liberar una regla. Borrador: `SOLICITUD_AL_DESARROLLADOR_ORIGINAL.md`. |
| Recursos | Completar permisos y atribuciones de imágenes. | Procedencia/licencia documentada o recurso retirado/reemplazado antes de distribuir públicamente. |
| Validación prioritaria | Elegir un modelo y mercado realmente requerido; exportar sus pendientes. | Afirmaciones concretas contrastadas con evidencia aplicable, manteniendo identidad, límites e historial. No extrapolar VIN a todos los años. |
| Ampliación de alcance | Acordar padrón OEM y plataformas de ejecución objetivo. | Fuentes autorizadas y criterios medibles, separados del inventario B8 recibido. |

El usuario no dispone de una motocicleta. No se programa inspección de unidad ni se supone equipamiento. Las discrepancias C400GT, hipótesis S1000RR y contactos no se cierran por analogía. Los detalles documentales y la secuencia histórica están en `PLAN_CONTINUIDAD_RC16.md` y el CSV de pendientes.

No se asigna un porcentaje global ficticio: la versión de referencia tiene un alcance de software cerrado y la validación técnica conserva su estado real. La recepción y pruebas en equipo del usuario siguen siendo pasos externos abiertos.
