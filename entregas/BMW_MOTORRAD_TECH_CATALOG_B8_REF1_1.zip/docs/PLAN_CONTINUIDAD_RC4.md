# Continuidad después de RC4

## Base comprobada

815 fichas originales preservadas. Hay 321 con revisión detallada y 494 sin desglose; las no revisadas no reciben conteos ficticios de afirmaciones. En los seis bloques revisados hay 945 afirmaciones pendientes y 530 con respaldo limitado, sin certificar unidades. La matriz `ACEPTACION_RC4.md` mantiene abiertos los criterios no demostrados.

## Orden de trabajo documental

| Familia | Fichas aún sin desglose |
|---|---:|
| F | 136 |
| K | 128 |
| R | 46 |
| C | 87 |
| S | 73 |
| G | 18 |
| M | 6 |
| Total | 494 |

La familia R conserva 46 fichas sin revisión detallada: 30 de modelos anteriores (R 1100, R 1150 y R 1200 C/CL) y 16 de modelos recientes (R 18 Classic/Roctane, R 12 nineT/G/S/S y R 1300 R/RS/RT). Revisar esos dos grupos por separado y luego priorizar F y K por volumen. R nineT y sus cinco variantes ya tienen desglose en RC4, con sus pendientes intactos. Este orden no convierte volumen revisado en exactitud técnica.

Para cada bloque: localizar primero documentos propios por modelo/generación y edición; comprobar contenido y fecha, no solo nombre del archivo; registrar URL/hash/página y alcance; contrastar cada afirmación; señalar campos heredados incoherentes; conservar identidad y fuente original; actualizar registro, panel, CSV, cobertura y pruebas de cambio de contexto. No aplicar códigos F por semejanza sin el diccionario original.

## Pendientes que requieren otra clase de evidencia

Chips, referencias de módulos, opciones por mercado y contactos de conectores requieren identificación aplicable. Un manual de usuario puede dejar esas afirmaciones abiertas. No hay unidad disponible: continuar con documentos públicos sin prometer una inspección física ni rellenar campos con valores supuestos. No reconstruir automáticamente VIN, fabricante de módulo o compatibilidad de programación mediante fotografías o certificados genéricos.

El diccionario original de fuentes F y las revisiones posteriores al ZIP no se recuperaron. Recuperarlos exige que aparezca un respaldo del desarrollador o una entrega verificable; no se recrean como si fueran originales.

## Entrega y validación

RC4 añade revisión documental; mantiene las restricciones técnicas. La regresión de aplicación no sustituye certificación por VIN, licencias de recursos, pruebas en Windows/macOS ni inspección visual de todas las impresiones. Los resultados vigentes se registran en `VALIDACION_RC4.json`.

La generación/verificación de un ZIP local no acredita que el usuario pueda descargarlo desde este chat. Ese canal de entrega continúa pendiente. No publicar ni desplegar como solución automática a esa limitación.
