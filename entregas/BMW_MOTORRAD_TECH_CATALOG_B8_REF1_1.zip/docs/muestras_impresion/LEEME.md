# Muestras de impresión B8-RC15

14 PDF generados desde una entrega extraída en una carpeta independiente, con solicitudes remotas bloqueadas: una ficha de transponder y una de diagnóstico por familia C/F/G/K/M/R/S. No son guías de programación ni certificaciones por VIN. Las restricciones y referencias pendientes se mantienen impresas.

La identidad, cantidad de páginas y SHA-256 de cada muestra están en `../VALIDACION_ENTREGA_LOCAL_RC15.json`. Se comprobaron texto e identidad en todas; se inspeccionaron visualmente primeras páginas de F/transponder y C/diagnóstico. No se revisaron todas las páginas ni se probó una impresora física.
