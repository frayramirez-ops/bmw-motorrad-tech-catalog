# Biblioteca visual reconstruida

Se creó `BMW_Motorrad_B8_REGENERADO/GALERIA_FOTOGRAFICA_OEM.html` para reparar los enlaces existentes de B8. El nombre se conserva por compatibilidad con esas rutas; no es la galería original ausente ni acredita procedencia OEM, permisos de publicación o autenticidad de cada imagen. El título visible es «Biblioteca visual» y se ajustaron los enlaces del catálogo para evitar presentarla como archivo OEM validado.

## Contenido y alcance

24 recursos: 16 fotografías y ocho recortes originales recuperados, copiados previamente sin transformación. `gallery-manifest.json` conserva identidad, tipo, ruta y hash; la misma información se incorpora al HTML para no necesitar descargar JSON por separado.

Se excluyen referencias técnicas de chips/módulos, ilustraciones, siluetas y recortes no aprobados o pendientes de revisión. La biblioteca no debe convertirse en una vía para presentar referencias técnicas de fichas restringidas como liberadas.

Los nombres de modelo son etiquetas de búsqueda del recurso recuperado; no se verifica una asignación individual ni se deducen años por el nombre del archivo. Las imágenes identificadas en el paquete como fotografías de familia se rotulan como tales. Todas las entradas tienen `approvedForTechnicalUse: false`. Las atribuciones y permisos siguen pendientes y no se sustituyen por el prefijo `official_` del archivo.

## Funciones

- Búsqueda por modelo y alias GSA previstos, filtro de fotografía/recorte y limpieza de filtros.
- Contador y estado vacío: no se suple un modelo sin foto con otra generación.
- Enlace contextual `?modelo=...` desde el catálogo.
- Ampliación con diálogo nativo, cierre por botón o Escape y etiquetas accesibles.
- Vuelta al catálogo y diseño sin desbordamiento horizontal en la vista móvil ensayada de 375 px.
- Recursos, CSS y JavaScript locales. No hay dependencias de servicio, datos de usuario, cuentas ni almacenamiento.

## Validación

`tests/test_gallery.py` comprueba el manifiesto, hashes de los 24 archivos, exclusión de material técnico/no aprobado y ausencia de años inferidos. En Chromium valida el enlace desde B8, carga HTTP de cada imagen, filtros, alias, ampliación/cierre, limpieza, vacío y retorno al catálogo. Se inspeccionó una captura móvil del estado R1300GS Adventure; no es una validación visual de la identidad de todas las imágenes.

La prueba de apertura directa `file://` se intentó y quedó omitida porque la política administrada de Chromium respondió `ERR_BLOCKED_BY_ADMINISTRATOR`. No se altera esa política ni se afirma que ese modo haya sido validado. El modo comprobado es el servidor HTTP local documentado en `README_CODEX.md`.

La galería se desarrolló como componente nuevo sobre recursos recuperados. No cambió `catalogData`, el CSV original ni reglas de liberación. No se publicó ni desplegó; la revisión de licencias y atribuciones continúa pendiente.
