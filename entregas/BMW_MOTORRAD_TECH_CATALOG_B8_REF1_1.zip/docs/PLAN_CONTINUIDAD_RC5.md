# Continuidad después de RC5

## Base comprobada

815 fichas originales preservadas. Hay 367 con revisión detallada y 448 sin desglose; las no revisadas no reciben conteos ficticios de afirmaciones. En los siete bloques revisados hay 1116 afirmaciones pendientes y 566 con respaldo limitado, sin certificar unidades. La matriz `ACEPTACION_RC5.md` mantiene abiertos los criterios no demostrados.

## Orden de trabajo documental

| Familia | Fichas aún sin desglose |
|---|---:|
| F | 136 |
| K | 128 |
| R | 0 |
| C | 87 |
| S | 73 |
| G | 18 |
| M | 6 |
| Total | 448 |

Las 279 fichas R tienen ahora desglose, con sus pendientes técnicos intactos. La siguiente prioridad es F: F750GS (24 fichas), F850GS (24) y F850GS Adventure (20) forman un bloque de 68. Las otras 68 fichas F sin revisión incluyen F650/F700/F900 y F450, y requieren separar generaciones y nombres de catálogo. Después se puede priorizar K (128). Los 112 pendientes individuales del bloque F800GS no desaparecen por ampliar la familia. No se identifica una unidad ni se libera programación a partir del volumen revisado.

Para cada bloque: localizar primero documentos propios por modelo/generación y edición; comprobar contenido y fecha, no solo nombre del archivo; registrar URL/hash/página y alcance; contrastar cada afirmación; señalar campos heredados incoherentes; conservar identidad y fuente original; actualizar registro, panel, CSV, cobertura y pruebas de cambio de contexto. No aplicar códigos F por semejanza sin el diccionario original.

## Pendientes que requieren otra clase de evidencia

Chips, referencias de módulos, opciones por mercado y contactos de conectores requieren identificación aplicable. Un manual de usuario puede dejar esas afirmaciones abiertas. No hay unidad disponible: continuar con documentos públicos sin prometer una inspección física ni rellenar campos con valores supuestos. No reconstruir automáticamente VIN, fabricante de módulo o compatibilidad de programación mediante fotografías o certificados genéricos.

El diccionario original de fuentes F y las revisiones posteriores al ZIP no se recuperaron. Recuperarlos exige que aparezca un respaldo del desarrollador o una entrega verificable; no se recrean como si fueran originales.

## Entrega y validación

RC5 añade revisión documental; mantiene las restricciones técnicas. La regresión de aplicación no sustituye certificación por VIN, licencias de recursos, pruebas en Windows/macOS ni inspección visual de todas las impresiones. Los resultados vigentes se registran en `VALIDACION_RC5.json`.

La generación/verificación de un ZIP local no acredita que el usuario pueda descargarlo desde este chat. Ese canal de entrega continúa pendiente. No publicar ni desplegar como solución automática a esa limitación.
