# Conciliación documental de la familia C — RC13

87 fichas originales: 52 transponders y 35 diagnóstico. Son 70 selecciones de interfaz y 17 emergencias Keyless conservadas como histórico. Los datos B8, sus resultados, códigos F y hashes no se sustituyen. Registro: `c-reconciliation.json`; exportaciones: `C_AFIRMACIONES.csv` y `C_PENDIENTES.csv`.

## Resultado y límites

400 afirmaciones: 97 documentadas en edición, ocho referencias de especialista y 295 pendientes. Ninguna es certificación por VIN. Se consultaron 36 PDF OEM (26 de la base inglesa y diez del seguimiento alemán/español), índice BMW (01.10.2026) y HEX GS-911; 92 observaciones trazables. Los PDF se verificaron por SHA-256 contra la descarga, portada/modelo y contenido de los pasajes. Las páginas siguientes son del archivo PDF, no numeración impresa.

- C600/C650: EWS! documenta autorización de arranque. B8 contiene 13 resultados en conflicto (ID46 frente a Texas Crypto 40/80 bits) y cinco Texas Crypto 40/80 bits condicionados; el manual no resuelve ni confirma esos semiconductores ni identifica módulo/antena. Las 18 antenas mecánicas permanecen pendientes.
- C400X: el respaldo se describe junto a la cubierta de batería, a la altura del lector 3. Es referencia de edición, sin certificar una unidad ni su chip/módulo Keyless.
- C400GT: las cinco ediciones consultadas contienen referencias a “battery cover” y “rear-wheel cover” dentro del mismo procedimiento de respaldo. En 06.2018 la primera frase comienza en PDF 68 y continúa en 69; en 09.2020 el procedimiento abarca PDF 68–69. Se conservan ambos pasajes. Las 16 afirmaciones de antena quedan pendientes; no se selecciona una cubierta como confirmada ni se extrapola desde X.
- Diagnóstico C600/C650 2012–2015: ocho accesos son referencia HEX limitada a sus filas de ese periodo. No se usa la fila posterior basada solo en imágenes.
- C650 moderno: acceso OEM bajo panel lateral delantero derecho; Sport requiere panel delantero/lateral y GT panel lateral según edición. C400: acceso bajo cubierta de batería según edición; las dos ediciones 03.2025 no se usan para deducir posición más precisa de otra obra. 27 accesos son referencias OEM.
- Las diez fichas “Conector C16C” se conservan literalmente. Ningún procedimiento acredita contactos, adaptador ni equivalencia con C16. Conector y ubicación individual permanecen pendientes en las 35 fichas.
- Las fechas son de colofón: archivos 0819 dicen 06.2019; 0622 dicen 02.2022; 0724 dicen 09.2024; 0725 dicen marzo de 2025. El índice de periodo no prueba todo un año ni país; mercado/equipamiento permanece pendiente en las 87 fichas.

No se compararon resultados contra el ZIP en este bloque; una lista vacía no significa ausencia histórica. No se reconstruye diccionario F ni programación. No se incorporan PDF remotos al paquete ni se presume autorización de redistribución.

## Páginas de contraste de la base inglesa RC10

| Modelo | Edición comprobada | EWS PDF | Respaldo PDF | Acceso diagnóstico PDF |
|---|---|---:|---|---|
| C400GT | 02.2022, 3rd edition | 70 | 71 | 178,179 |
| C400GT | 03.2025, 2nd edition | 84 | 85 | 167,168 |
| C400GT | 06.2018, 1st edition | 68 | 68,69 | 174,175 |
| C400GT | 09.2020, 1st edition | 68 | 68,69 | 179,180 |
| C400GT | 09.2024, edition 1.1 | 82 | 83 | 165,166 |
| C400X | 02.2022, 3rd edition | 73 | 74 | 188 |
| C400X | 03.2025, 2nd edition | 81 | 82 | 164,165 |
| C400X | 04.2018, 2nd edition | 69 | 70 | 182,183 |
| C400X | 09.2020, 1st edition | 73 | 74 | 189,190 |
| C400X | 09.2024, edition 1.1 | 81 | 82 | 165 |
| C400X | 11.2017, 1st edition | 65 | 66 | 176,177 |
| C600 Sport | 07.2012, 2nd edition | 31 | — | — |
| C600 Sport | 08.2014, 5th edition | 31 | — | — |
| C600 Sport | 09.2012, 3rd edition | 31 | — | — |
| C600 Sport | 12.2013, 4th edition | 32 | — | — |
| C650 Sport | 04.2016, 2nd edition | 29 | — | 120 |
| C650 Sport | 04.2018, 3rd edition | 33 | — | 124 |
| C650 Sport | 06.2019, 4th edition | 33 | — | 124 |
| C650GT | 04.2018, 4th edition | 33 | — | 129,130 |
| C650GT | 06.2019, 5th edition | 33 | — | 129,130 |
| C650GT | 07.2012, 2nd edition | 31 | — | — |
| C650GT | 07.2017, 3rd edition | 29 | — | 123,124 |
| C650GT | 08.2014, 5th edition | 31 | — | — |
| C650GT | 09.2012, 3rd edition | 31 | — | — |
| C650GT | 09.2015, 2nd edition | 34 | — | 124,125 |
| C650GT | 12.2013, 4th edition | 31 | — | — |

Las URL, identificadores de fuente, hashes, entradas del índice por mercado/plataforma y observaciones están en el registro JSON. El panel usa identidad exacta, nunca posición en un arreglo. Los estados pendientes pueden tener observaciones contradictorias sin pasar a “documentado”.

## Validación

`test_c.py` comprueba identidad/hash original, equivalencia JSON embebido/registro, procedencia de observaciones, límites de chip/módulo, discrepancias GT, C16C y los CSV. El recorrido Chromium verifica las 70 selecciones, cambio de contexto y anchura móvil; no constituye una inspección física. La suite global mantiene las 701 selecciones y restricciones de transponder. Resultados vigentes: `VALIDACION_RC13.json`. El seguimiento de C400GT está detallado en `C400GT_CONTRASTE_MULTILINGUE.md`; sus 16 afirmaciones de antena permanecen pendientes.
