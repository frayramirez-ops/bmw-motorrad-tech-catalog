# Continuidad después de RC12

## Inventario documental cerrado

Las 815 fichas originales tienen revisión detallada en catorce registros. Sus 3760 afirmaciones se distribuyen en 1265 con respaldo limitado y 2495 pendientes; no hay fichas sin desglose. El 100 % corresponde al inventario recibido, sin certificar compatibilidad ni cobertura de producción por mercado.

El trabajo cambia de recorrer familias a resolver afirmaciones. `PENDIENTES_TECNICOS_B8.csv`, generado con `scripts/build_coverage.py`, mantiene cada pendiente ligado a identidad, registro de origen, fuentes/observaciones, límite y acción requerida. Actualizar el JSON de origen y regenerar; no editar el CSV como base maestra. `CIERRE_INVENTARIO_DOCUMENTAL.md` detalla los conteos por tema y la secuencia de trabajo.

## Siguientes trabajos y criterios de salida

1. Usar el borrador `SOLICITUD_AL_DESARROLLADOR_ORIGINAL.md` para solicitar al desarrollador original diccionario F001–F189, revisiones posteriores al ZIP, fuentes y matriz de aceptación original. Conservar procedencia; no reconstruirlos como si fueran originales. Revisar también los vínculos de las 500 reglas de programación antes de liberar cualquier resultado.
2. Contrastar discrepancias documentales con referencias propias de modelo/variante/edición. Priorizar hipótesis Keyless S1000RR, cubiertas contradictorias C400GT, chips C600/C650, cronologías y transiciones CT/C16C. Un nuevo manual puede ayudar sin resolver una unidad.
3. Resolver mercado/equipamiento, chip, módulo y contactos con documento aplicable o evidencia identificada de unidad/pieza. El usuario no dispone de motocicleta: no prometer inspección ni rellenar VIN/partes con valores supuestos. Una homologación genérica no identifica un mando Keyless.
4. Establecer padrón OEM autorizado por mercado 2003–2027 y reglas para alias/modelos/años. No inventar 2027 ni confundir el denominador B8 (2000–2026) con producción BMW completa.
5. Completar aceptación de producto: licencias/atribuciones de recursos, Windows/macOS, muestra de impresiones, canal de entrega accesible y criterios originales pendientes. No publicar ni desplegar como solución automática a la falta de descarga.

Cada cierre exige evidencia trazable en su afirmación y pruebas de no mezclar identidades. Las ocho hipótesis y todos los resultados restringidos se mantienen hasta satisfacer el criterio correspondiente. No se elimina un pendiente por aceptar la interfaz.

## Base funcional y entrega

Resultados vigentes: `VALIDACION_RC12.json`; criterios: `ACEPTACION_RC12.md`. Aplicación estática local con Python estándar para servirla; 701 selecciones y 114 emergencias históricas. Las notas pertenecen al navegador y deben exportarse antes de mover origen/equipo.

El ZIP local con manifiesto verifica integridad de archivos; no acredita descarga desde el chat, licencia, firma digital ni validez técnica. El canal de entrega sigue sin vía comprobada. No se realizó publicación ni despliegue.
