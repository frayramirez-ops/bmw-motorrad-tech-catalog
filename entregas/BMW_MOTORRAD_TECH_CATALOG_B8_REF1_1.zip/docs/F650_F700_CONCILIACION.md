# F650/F700 — generaciones y límites del inmovilizador

## Alcance

40 fichas B8: 20 transponders y 20 diagnóstico, todas seleccionables. Incluye F650GS con nombres antiguos (2000–2002), Dakar 2001, CS 2003, F650GS monocilíndrica (2004–2007), F650GS bicilíndrica de 798 cc (2008–2012) y F700GS (2013–2018). No se rellenan huecos de años ni se normalizan nombres/plataformas pendientes.

`f650-f700-reconciliation.json` conserva identidad y hash de cada ficha, con copia idéntica en HTML y panel contextual. Son 180 afirmaciones: **42 con respaldo limitado** (24 de edición y 18 de especialista) y **138 pendientes**. Los CSV `F650_F700_AFIRMACIONES.csv` y `F650_F700_PENDIENTES.csv` conservan todas y las pendientes. No se compararon resultados del ZIP: listas vacías no demuestran ausencia histórica.

## Fuentes consultadas

Once PDF oficiales (incluido mantenimiento R13), índice BMW y guía HEX; tres citas históricas comerciales/prensa sin verificar porque sus dominios no están incluidos en la política de red actual. Son 16 fuentes y 35 observaciones con alcance/hash. No se certifica autoridad técnica por el título de un enlace sin consultarlo. Página PDF conservada; impresa null cuando no se verificó.

| Modelo de referencia | Edición impresa | Plataforma de documento/índice | Llave, PDF | EWS, PDF | Motor, PDF | Acceso diagnóstico OEM, PDF |
|---|---|---|---|---|---|---|
| F 650 GS/F 650 GS Dakar/F650GS (monocilíndrica) | 10.2003, 1st edition | R13 | 10,11 | — | — | — |
| F 650 GS/F 650 GS Dakar/F650GS (monocilíndrica) | 10.2003, 1st edition; Maintenance Instructions | R13 | — | — | 65 | — |
| F 650 CS | 10.2003, 1st edition | K14 02 | 10,11 | — | — | — |
| F650GS (bicilíndrica 798 cc) | 05.2009, 2nd edition; cover and colophon checked visually | K72 | 42 | 43 | 133 | — |
| F650GS (bicilíndrica 798 cc) | 06.2010, 3rd edition | K72 | 40 | 41 | 129 | — |
| F650GS (bicilíndrica 798 cc) | 09.2011, 4th edition | K72 | 40 | 41 | 127 | — |
| F650GS (bicilíndrica 798 cc) | 10.2007, 1st edition | K72 | 42 | 43 | 131 | — |
| F700GS | 06.2012, 1.1 edition | K70 11 | 42 | 43 | 133 | — |
| F700GS | 08.2013, 2nd edition | K70 11 | 42 | 43 | 133 | — |
| F700GS | 08.2015, 4th edition | K70 11 | 42 | 43 | 147 | — |
| F700GS | 04.2016, 2nd edition | K70 12 | 44 | 45 | 157 | 133,134 |

«—» significa que ese contenido no se utilizó para acreditar una afirmación, sin probar ausencia de función. El índice oficial conserva entradas por archivo/plataforma/periodo. R13 y K72 comparten el nombre F650GS: se contrastaron tablas de motor, sin identificar generación por cilindrada nominal del nombre ni por la fotografía.

## Hallazgos

- El manual de mantenimiento R13 describe motor monocilíndrico de 652 cc (PDF 65). Los manuales K72 describen dos cilindros y 798 cm³; F700GS también describe 798 cm³. No se trasladan datos de EWS/llave de la bicilíndrica a la monocilíndrica.
- Las nueve fichas monocilíndricas/históricas de transponder mantienen todas sus afirmaciones pendientes. Las posiciones mecánicas de llave no acreditan presencia ni ausencia de EWS/transponder. «NO ASIGNAR TRANSPONDER» heredado no se convierte en prueba de que no exista.
- El manual GS/Dakar recuperado es 10.2003, posterior a GS 2000/2001/2002 y Dakar 2001. Se conserva como contexto y se señala el conflicto en ocho filas (ambas secciones), sin acreditar equipamiento anterior por ese documento. La fuente CS es propia de CS, sin trasladarle R13 automáticamente.
- En K72 y F700GS, EWS y antena anular en cerradura están descritos en documentos propios. No identifican chip, fabricante/pieza de módulo ni versión EWS4 de una unidad. Las referencias heredadas ID46/PH/CR2 y los códigos F no se dan por contrastados por leer EWS genérico.
- Las 40 afirmaciones de chip/módulo de este bloque siguen pendientes; no se atribuye TMS37145/EWS4 a F700GS 2017/2018 desde apéndices de otros modelos o ediciones.
- HEX distingue la fila monocilíndrica 652 cc (GS/Dakar/CS): puerto bajo panel derecho, encima del radiador, accesible sin retirar el panel. La fila bicilíndrica 798 cc indica retirar asiento y puerto delante del depósito trasero. Ambas son referencias de especialista sin certificación de unidad o contactos.
- F700GS 2017/2018 tiene procedimiento OEM de retirar asiento y liberar seguros del soporte. Las otras 18 afirmaciones de acceso conservan referencia limitada HEX. Las 20 de conector y 20 de ubicación individual siguen pendientes.
- Las dos filas CT de 2015/2016 mantienen CT. Los iconos de interfaz, el año y una descripción de acceso no certifican C10/C16.
- La portada y el colofón F650GS 05.2009 tienen extracción de texto dañada: se comprobaron visualmente en PDF 1 y 159. El colofón indica 05.2009, 2nd edition, Order No. 01 41 7 726 231; la tabla técnica PDF 133 confirma referencia a 798 cm³.
- El archivo F700GS 1016 indica 04.2016, 2nd edition. Se conserva la fecha impresa; no se deduce 10.2016 por el nombre.

## Aplicación y validación

Dos pruebas comprueban generaciones/plataformas de documento, identidad/hash y copia embebida, observaciones insuficientes, pendientes de todos los chips/módulos, ocho conflictos cronológicos, las filas CT, CSV y 40 consultas en Chromium por HTTP local. Incluyen ocultación de paneles ajenos, cambio a otro bloque y un estado móvil. Regresión vigente: `VALIDACION_RC7.json`.

F tiene 154/182 fichas con desglose; quedan 28 sin él. Los 112 pendientes individuales F800GS siguen abiertos. La cobertura global no es porcentaje de finalización.

No se publicó ni desplegó. El JSON/CSV original y las restricciones técnicas se conservan. Los PDF de consulta quedan fuera del paquete; se guardan enlaces, hashes y observaciones. La descarga del paquete por este chat sigue pendiente de una vía comprobada.
