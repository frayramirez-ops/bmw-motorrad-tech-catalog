# Seguimiento de acceso diagnóstico — RC14

33 afirmaciones pasan de pendiente a **referencia de especialista con aplicabilidad individual pendiente**: 26 R1200GS/Adventure y siete S1000RR. No se certifican contactos, adaptadores, configuración por VIN ni programación. Los datos B8 y todas las otras afirmaciones se conservan.

La fuente es la guía pública HEX GS-911 “Where do I find my bike's diagnostic connector?”. Se volvió a consultar y se guardó una instantánea independiente: HTTP 200, SHA-256 `bd94c49240f77c5ddfde18e7a24837b41d01998e3a920b1bbd22ad4cc3009745`, 249783 bytes. No se sobrescribieron las instantáneas históricas ni se cambió su hash para hacerlas coincidir. Cada registro usa su propia procedencia.

## Alcance aplicado

| Modelo / generación B8 | Fichas | Referencia de acceso |
|---|---:|---|
| R1200GS K25, 2004–2013 | 10 | Retirar asiento trasero; puerto bajo la parte posterior del asiento delantero. |
| R1200GS Adventure K25, 2006–2014 | 9 | Misma fila especialista Hexhead, con periodo propio Adventure. |
| R1200GS K50, 2013–2016 | 4 | Fila Wethead: panel triangular derecho bajo asiento delantero; puerto delante de batería. |
| R1200GS Adventure K51, 2014–2016 | 3 | Fila Wethead, modelo Adventure y plataforma separados de K25. |
| S1000RR K46 / K46 11 / K46 12, 2010–2016 | 7 | Retirar asiento trasero; puerto al frente del compartimento bajo asiento. |
| Total | 33 | Referencias limitadas, no inspecciones de unidad. |

La distinción de refrigeración de la guía se contrasta con la identidad de plataforma y referencias OEM ya registradas. No se elige generación por año cuando coexisten K25/K50 o K25/K51. El rótulo “2015+” de las imágenes de adaptadores no se utiliza para acreditar formato/contactos ni como corte del procedimiento de acceso.

Las citas OEM posteriores a algunas fichas siguen con conflicto. En GS 2012/2013 K25, solo acceso recibe una referencia especialista independiente; el documento de 2014 no se vuelve aplicable por ello. La misma separación se mantiene para S1000RR 2014 frente al manual 07.2015. Las seis fichas CT afectadas conservan CT; no se convierten a C10/C16.

## Seis accesos que siguen pendientes

| Ficha | Motivo para no extrapolar |
|---|---|
| R nineT /5 2020 | B8 K21 e índice de manual propio desde Pure/K22; discrepancia de plataforma sin resolver. |
| K1600GTL 2015 y 2016 | La fila consultada especifica GTL 2010–2014 y Exclusive 2013+; no acredita GTL posterior usando Exclusive. |
| R 1100 S Light 2001 | Variante Light sin respaldo aplicable contrastado; no se usa automáticamente la fila del modelo base. |
| R 1200 C Montana 2001 | Variante Montana sin respaldo aplicable contrastado. |
| R 1200 C Phoenix 2001 | Variante Phoenix sin respaldo aplicable contrastado. |

Estos límites describen la evidencia consultada, no demuestran que no exista otra fuente aplicable. Se requiere documentación específica o identificación de unidad/variante para continuar.

## Resultado y validación

Quedan 2462 afirmaciones pendientes y 1298 con respaldo limitado de las 3760 inventariadas. Acceso pasa de 39 a seis pendientes. Las 315 afirmaciones de conector permanecen pendientes y las ocho hipótesis Keyless siguen sin acreditar. Las 815 fichas conservan desglose; no se declara finalización técnica.

`followUp.changes` de cada registro conserva la afirmación previa y el nuevo vínculo. La comparación con el paquete RC13 confirmó exactamente 33 cambios de afirmación, todos de acceso; los demás contenidos de afirmación, identidades, resultados y hashes B8 coinciden. Se regeneran CSV, cobertura y vista de pendientes desde las fuentes de revisión.

`test_access_followup.py` verifica las 33 correspondencias, separación de plataformas/modelos, seis exclusiones, CT y conflictos cronológicos conservados, y recorre sus 33 selecciones en Chromium. Las pruebas anteriores siguen comprobando originales, hipótesis y restricciones. Resultados: `VALIDACION_RC14.json`. No se publicó ni desplegó.
