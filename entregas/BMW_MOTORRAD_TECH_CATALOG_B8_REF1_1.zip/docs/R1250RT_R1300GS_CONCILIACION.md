# R1250RT y R1300GS/Adventure — revisión por edición

## Alcance y resultados

45 fichas: 30 R1250RT (2019–2024), nueve R1300GS (2024–2026) y seis R1300GS Adventure (2025–2026). Se conservan 28 filas de transponders y 17 de diagnóstico. Las 11 emergencias Keyless siguen fuera de los selectores independientes; hay 34 consultas seleccionables.

El registro `r1250rt-r1300gs-reconciliation.json` contiene 208 afirmaciones: **61 con respaldo limitado por edición y 147 pendientes**. RT aporta 36 respaldadas y 102 pendientes; las R1300GS/Adventure aportan 25 y 45. Se conserva identidad y hash de cada fila B8. No se certifican VIN ni mercado, chip, módulo o conector; todas esas afirmaciones siguen pendientes. No se compararon resultados del ZIP en este bloque; sus listas vacías no significan ausencia histórica.

La copia embebida del registro alimenta el panel contextual. Los CSV `R1250RT_R1300GS_AFIRMACIONES.csv` y `R1250RT_R1300GS_PENDIENTES.csv` permiten revisar cada afirmación.

## Fuentes y localizadores

14 fuentes registradas: 12 PDF oficiales consultados, un índice oficial consultado y una cita histórica ManualsLib sin verificar. Once PDF aportan evidencia primaria; el PDF US histórico adicional se consulta para identificar edición/mercado, sin usarlo para acreditar años anteriores. Hay 41 observaciones con página PDF y hash. No se deduce número de página impresa: permanece null.

El índice público BMW está en `https://manuals.bmw-motorrad.com/manuals/BA-Extern/IN/BA-INTERNET-COM/01/Nav.xml`; se conservan URL/hash y sus entradas RT por archivo, periodo y código de modelo en `sources[].discovery`. Los periodos del índice delimitan documentos, sin certificar que todos los MY del catálogo los usen. La fecha del índice no se atribuye a cada manual.

| Edición primaria | Llave mecánica / EWS | Respaldo Keyless | Acceso diagnóstico |
|---|---:|---:|---:|
| RT 01.2019, 2.ª | 60–61 | 65–66 | 178–179 |
| RT 08.2019, 3.ª | 64, 70 | 68–69 | 207 |
| RT 07.2020, 1.ª | 68 | 72–73 | 236–237 |
| RT 06.2021, 2.ª | 72 | 76–77 | 240 |
| RT 04.2022, 3.ª | 74 | 78–79 | 245–246 |
| RT 04/2023, 4.ª | 92 | 96 | 235 |
| GS 02/2023, 1.ª | No utilizado | 101 | 239 |
| GS 02.2024, 2.ª | No utilizado | 105 | 251–252 |
| GS February 2025, 3.ª | No utilizado | 103 | 252 |
| Adventure 02.2024, 1.ª | No utilizado | 105 | 249 |
| Adventure February 2025, 2.ª | No utilizado | 103 | 249–250 |

Los seis manuales RT se vinculan, en ese orden, a las filas 2019–2024 como referencias de edición. Las GS/Adventure conservan los enlaces de diagnóstico propios que ya tenía B8. El contenido de portada confirma por separado GS y Adventure.

## Hallazgos

- B8 cita `R_0L03_RM_0423_07.pdf` en RT 2021–2024. Su portada dice **US MODEL** y el colofón 04-2023, 4th edition, 07. Usarlo para RT 2021/2022 introduce un conflicto cronológico. Se conserva la cita histórica, pero las fuentes primarias actuales son ediciones anteriores enlazadas por BMW. No se convierte US en equipamiento de México.
- La plataforma RT de B8 agrupa «R1250RT 18 / R1250RT 20». El índice distingue K52 12 para 0J61 y K52 11 para 0L01. Se registra esa diferencia sin cambiar identidades ni identificar una unidad por analogía; todavía se necesita su subgeneración/VIN.
- Las RT iniciales describen emergencia en hueco centrado encima del cuadro y mando sin pila detrás del cuadro, con retirada de cubierta/altavoz según equipamiento. Las ediciones TFT describen izquierda del centro y debajo de la pantalla. No se traslada el procedimiento moderno a 2019/2020.
- Solo la página 96 de RT 04/2023 identifica expresamente la antena anular debajo del cuadro dentro del procedimiento de emergencia utilizado. Las afirmaciones de antena Keyless RT 2019–2022 permanecen pendientes; documentar dónde presentar una llave no identifica automáticamente la pieza. Mecánica conserva respaldo limitado para giro de llave en todas las ediciones RT; antena mecánica solo en los pasajes explícitos de las dos primeras ediciones.
- Las R1300GS/Adventure indican introducir llave de emergencia o mando plegado sin pila en el lector anular bajo el asiento del conductor. No corresponde a la cubierta de rueda trasera documentada en R1200GS/R1250GS. No se agregan filas mecánicas por encontrar menciones genéricas de EWS.
- El acceso diagnóstico RT se describe mediante cubierta de batería y soporte con gancho/seguros. En R1300GS/Adventure se describe retirando asiento del conductor y liberando seguros. Conector y ubicación individual siguen pendientes; no se cuentan contactos a partir de una ilustración.
- En las 12 filas de diagnóstico RT, el campo `system` enumera Mecánica/Keyless y no formato de conector. Se señala la inconsistencia semántica, sin interpretar esas etiquetas como C10/C16 ni deduplicar filas como si fueran unidades.
- Los apéndices que mencionan TMS37145/DST80 no se transfieren al chip del mando Keyless ni prueban pieza instalada. Este bloque conserva todos los chips y módulos pendientes. El diccionario F sigue sin reconstruirse.

## Validación y límites

Dos pruebas comprueban registros/hashes, separación de modelos y periodos, fuente primaria frente a cita histórica, estados pendientes y los 34 recorridos en Chromium por HTTP local. También comprueban cambio a una ficha R1200GS, ocultación de paneles ajenos y un estado móvil de 375 px. La regresión completa y su resultado se registran en `VALIDACION_RC3.json`.

Las fuentes originales B8 y el CSV permanecen intactos. La candidata RC3 mantiene las restricciones de programación; no se publica ni despliega. Los PDF consultados quedan en el entorno de auditoría, fuera del ZIP de aplicación; el paquete conserva enlaces, observaciones y hashes. La descarga por este chat sigue sin vía comprobada.
