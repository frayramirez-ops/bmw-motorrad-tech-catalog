# Continuidad después de RC6

## Base comprobada

815 fichas originales preservadas. Hay 435 con revisión detallada y 380 sin desglose; las no revisadas no reciben conteos ficticios de afirmaciones. En los ocho bloques revisados hay 1290 afirmaciones pendientes y 715 con respaldo limitado, sin certificar unidades. La matriz `ACEPTACION_RC6.md` mantiene abiertos los criterios no demostrados.

## Orden de trabajo documental

| Familia | Fichas aún sin desglose |
|---|---:|
| F | 68 |
| K | 128 |
| R | 0 |
| C | 87 |
| S | 73 |
| G | 18 |
| M | 6 |
| Total | 380 |

R conserva sus 279 fichas con desglose y pendientes técnicos intactos. F750GS/F850GS/Adventure ya aportan 68 fichas revisadas en RC6. Para completar el desglose de F faltan 68: F650/F700 reúnen 40 (separar F650 monocilíndrica y bicilíndrica, nombres antiguos, Dakar y CS); F900GS/Adventure reúnen 24; F450GS y F900R, cuatro. Continuar primero con F650/F700 y después con las restantes F. K (128) queda como siguiente familia por volumen. Los 112 pendientes individuales F800GS siguen abiertos y las nuevas revisiones no certifican unidades.

Para cada bloque: localizar primero documentos propios por modelo/generación y edición; comprobar contenido y fecha, no solo nombre del archivo; registrar URL/hash/página y alcance; contrastar cada afirmación; señalar campos heredados incoherentes; conservar identidad y fuente original; actualizar registro, panel, CSV, cobertura y pruebas de cambio de contexto. No aplicar códigos F por semejanza sin el diccionario original.

## Pendientes que requieren otra clase de evidencia

Chips, referencias de módulos, opciones por mercado y contactos de conectores requieren identificación aplicable. Un manual de usuario puede dejar esas afirmaciones abiertas. No hay unidad disponible: continuar con documentos públicos sin prometer una inspección física ni rellenar campos con valores supuestos. No reconstruir automáticamente VIN, fabricante de módulo o compatibilidad de programación mediante fotografías o certificados genéricos.

El diccionario original de fuentes F y las revisiones posteriores al ZIP no se recuperaron. Recuperarlos exige que aparezca un respaldo del desarrollador o una entrega verificable; no se recrean como si fueran originales.

## Entrega y validación

RC6 añade revisión documental; mantiene las restricciones técnicas. La regresión de aplicación no sustituye certificación por VIN, licencias de recursos, pruebas en Windows/macOS ni inspección visual de todas las impresiones. Los resultados vigentes se registran en `VALIDACION_RC6.json`.

La generación/verificación de un ZIP local no acredita que el usuario pueda descargarlo desde este chat. Ese canal de entrega continúa pendiente. No publicar ni desplegar como solución automática a esa limitación.
