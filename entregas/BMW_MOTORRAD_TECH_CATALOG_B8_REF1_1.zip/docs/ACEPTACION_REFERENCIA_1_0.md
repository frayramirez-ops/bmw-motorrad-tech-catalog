# Aceptación de alcance — B8-REF1.0

El usuario aceptó cerrar la primera versión como catálogo de referencia con pendientes visibles al responder «VAMOS» a esa propuesta. Se cierra ese alcance de software local; no se da por recibido el paquete ni por certificadas las fichas. La matriz original no recuperada sigue siendo un requisito para evaluar el objetivo técnico original, pero no impide fijar este alcance de referencia acordado.

## Incluido

- Consulta de las 815 fichas B8 conservadas: 701 combinaciones seleccionables y 114 registros históricos de emergencia Keyless.
- Búsqueda, comparador, copia restringida, favoritos, notas locales con respaldo/restauración e impresión.
- Biblioteca visual reconstruida con 24 recursos de consulta, dentro de 89 archivos recuperados. Permisos/atribuciones por completar.
- Catorce registros documentales, cobertura y padrón; consulta y exportación de pendientes por identidad, familia, año y tema.
- Iniciador HTTP local con Python 3, originales preservados y paquete verificable por manifiesto.
- Aviso de alcance al abrir la aplicación: 1306 afirmaciones con respaldo limitado y 2454 pendientes, sin habilitar programación ni modificar evidencia.

## Límites aceptados para la referencia

No hay certificación de compatibilidades por VIN, chip, módulo, mercado o contactos; padrón OEM mundial 2003–2027; recuperación del diccionario F y revisiones perdidas; servidor público, cuentas o sincronización. Ninguna imagen constituye acreditación de pieza instalada. Las reglas sin vínculo verificable continúan restringidas.

La prueba funcional se realiza en Linux/Chromium por HTTP local. Los iniciadores Windows/macOS se incluyen sin ejecución en sus sistemas; no se probaron impresoras físicas. Las licencias de imágenes deben resolverse antes de cualquier distribución pública. Las notas se guardan en el navegador y deben exportarse al cambiar de origen/equipo.

La recepción por el usuario sigue sin verificarse: el ZIP local no demuestra descarga. No hubo publicación, despliegue ni envío externo. Historial de comprobaciones y límites de las muestras: `ACEPTACION_RC16.md`; validación vigente: `VALIDACION_REFERENCIA_1_0.json`.
