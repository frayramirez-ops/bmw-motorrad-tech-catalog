# Aceptación de B8-RC16

## Dictamen

**Candidata funcional para revisión local, con base técnica incompleta.** No se declara el proyecto terminado al 100 %, ni cobertura OEM completa, ni compatibilidades certificadas por VIN. La ausencia del documento maestro original de aceptación limita la posibilidad de acreditar todos sus requisitos; los siguientes son criterios explícitos de esta recuperación.

La entrega incluye aplicación, recursos recuperados, documentos, originales B8, iniciadores locales y verificación de integridad. No incluye despliegue, publicación, autenticación OEM, sincronización de notas ni datos inventados para cerrar pendientes.

## Criterios comprobados

| Criterio | Resultado y evidencia |
|---|---|
| Conservar fuente B8 | PASA: HTML, inventario y LEEME originales en `originals/b8`; hashes fijados en `VERSION.json`. `catalogData` y CSV originales no cambian. |
| Ejecutar localmente | PASA en Linux: `scripts/serve_catalog.py`, Python estándar, escucha en 127.0.0.1; sirve catálogo y cobertura. No abre el servicio a la red pública. |
| Representar todas las selecciones existentes | PASA: 701 combinaciones seleccionables (386 transponders y 315 diagnóstico), identidad y título exactos, diagnóstico con contenido, restricciones de transponders intactas, sin excepciones JS; se comprueba reinicio posterior. |
| Conservar Keyless de emergencia | PASA como histórico: 114 filas permanecen en los datos sin constituir un tercer sistema seleccionable. No se borran para mejorar el conteo de pruebas. |
| Búsqueda y comparador | PASA en los recorridos probados, incluidos alias; no significa certificación del resultado técnico. |
| Copia, favoritos y notas | PASA en los recorridos de `test_daily_workflow.py`, incluidos bloqueo de resultado histórico, recarga, duplicados, cuota y exportación de sesión. |
| Impresión | PASA en muestra digital: 14 fichas, una por sección/familia, con identidad y restricciones verificadas. La primera página conserva el aviso de transponders. Se omiten controles/avisos globales. No se inspeccionaron todas las páginas/modelos ni impresoras físicas. |
| Biblioteca visual | PASA funcionalmente: 24 recursos, hashes, filtros, ampliación y móvil. Identificación individual/licencias pendientes. |
| Cobertura y padrón | PASA como inventario de B8: 815 identidades y 815 con conciliación detallada; inventario documental completo, con 3760 afirmaciones y CSV global de pendientes. Los desconocidos futuros se conservan como null/blancos. Generador rechaza datos obsoletos. |
| Consulta de pendientes | PASA en recorridos probados: filtros, identidad exacta, evidencia/límites, paginación y exportación CSV. No modifica estados técnicos. |
| Paquete extraído sin internet | PASA en Linux: iniciador desde carpeta independiente con espacios/acentos, 107 archivos servidos con hash exacto, catálogo/cobertura/pendientes y 24 imágenes de biblioteca, solicitudes remotas bloqueadas. |
| Paquete e integridad | PASA: ZIP autocontenido con manifiesto, CRC y hashes; original B8 comprobado. Prueba detecta alteraciones y evita sobrescribir una entrega existente. No es firma digital. |

La prueba global recorre la lógica y DOM del catálogo en Chromium mediante sus funciones/eventos de selección; no simula 701 veces todos los clics físicos. Se complementa con recorridos reales de controles para los bloques y funciones de uso diario. Las imágenes y fuentes remotas no quedan validadas por el mero renderizado de una ficha.

## Criterios todavía no acreditados

| Pendiente | Situación |
|---|---|
| Certificar las 815 fichas | NO CUMPLIDO: todas tienen conciliación, pero quedan 2454 afirmaciones pendientes y 1306 con respaldo limitado. Ninguna de estas categorías certifica una unidad. |
| Reconstruir controles técnicos | NO CUMPLIDO: 500 reglas no tienen vínculo histórico verificable. Se mantiene restricción; no se reasignan por posición ni por semejanza. |
| Padrón BMW 2003–2027 por mercado | NO CUMPLIDO: no hay padrón maestro autorizado; B8 abarca 2000–2026. Los candidatos 2027 no se convierten en datos confirmados. |
| Resolver referencias F y revisiones perdidas | NO CUMPLIDO: el diccionario y entregas posteriores no fueron recuperados. |
| Homologación/compatibilidad por unidad | NO CUMPLIDO: manual, imagen y certificado no identifican cada VIN, módulo, RF, chip ni equipo de programación. No se dispone de unidades para esas comprobaciones. |
| Atribuciones y permisos de imágenes | PENDIENTE: no se presume autorización por el nombre `official_` ni por recuperar un archivo. |
| Galería original | NO RECUPERADA: se implementó una biblioteca nueva sobre recursos disponibles. |
| Apertura directa file:// | NO VALIDADA: navegador administrado la bloquea con `ERR_BLOCKED_BY_ADMINISTRATOR`; el iniciador HTTP es el modo comprobado. |
| Windows/macOS e impresoras | NO EJECUTADOS en esos sistemas; se proporcionan envoltorios de inicio e instrucciones. |

## Puerta de salida

Esta candidata permite evaluar la aplicación y continuar la auditoría desde una entrega única. **No habilita declarar terminado el catálogo técnico ni publicar compatibilidades como certificadas.** Los pendientes deben resolverse por evidencia trazable o aceptarse explícitamente como parte del alcance de un catálogo de referencia; no desaparecen por aprobar la interfaz.

No se realizó publicación ni despliegue. El ZIP no incorpora notas guardadas en navegadores de usuarios. Exportarlas es una operación separada.

## Cierre funcional local RC15

Se corrigió la impresión: se reducen huecos de paginación, se conservan estados ocultos y se excluyen botones y avisos globales fuera de la ficha. Se desactiva el resumen histórico duplicado que mostraba valores de transponder fuera del control actual de consulta; los datos B8 y paneles documentales se conservan. La entrega extraída funciona en HTTP local con solicitudes remotas bloqueadas y produce 14 PDF de muestra sin errores JavaScript.

Evidencia: `VALIDACION_RC15.json`, `VALIDACION_ENTREGA_LOCAL_RC15.json`, `CIERRE_FUNCIONAL_Y_BLOQUEOS.md` y `muestras_impresion/`. La verificación local queda documentada; no implica aceptación del alcance como referencia, entrega recibida por el usuario, licencias completas ni certificación de los 2462 pendientes. No se declara el proyecto técnico terminado.

## Revisión documental RC16

Ocho afirmaciones de sistema/antena reciben respaldo de edición mediante asignación explícita del índice BMW a plataforma/periodo y contraste con pasajes EWS de la obra y una edición anterior. Se mantiene incertidumbre de unidad, mercado, chip y módulo, y todas las restricciones de programación. No se modifica ni elimina la diferencia entre publicación y periodo de producción. Véase `TEMPORALIDAD_MANUALES_RC16.md` y `VALIDACION_RC16.json`. El cierre funcional de RC15 y sus muestras se conservan como evidencia histórica; la revisión documental no declara terminado el proyecto.

La aplicación RC16 también se verificó extraída fuera del checkout, con solicitudes remotas bloqueadas: 107 archivos por hash, 24 imágenes y 14 PDF generados. Véase `VALIDACION_ENTREGA_LOCAL_RC16.json`; estos PDF se conservan como evidencia de ejecución fuera del paquete, que mantiene las muestras históricas RC15.
