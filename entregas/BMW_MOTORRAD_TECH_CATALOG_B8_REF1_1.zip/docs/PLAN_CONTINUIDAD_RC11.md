# Continuidad después de RC11

## Base comprobada

815 fichas originales preservadas. Hay 791 con revisión detallada y 24 sin desglose; las no revisadas no reciben conteos ficticios de afirmaciones. En los trece bloques revisados hay 2399 afirmaciones pendientes y 1253 con respaldo limitado, sin certificar unidades. La matriz `ACEPTACION_RC11.md` mantiene abiertos los criterios no demostrados.

## Orden de trabajo documental

| Familia | Fichas aún sin desglose |
|---|---:|
| F | 0 |
| K | 0 |
| R | 0 |
| C | 0 |
| S | 0 |
| G | 18 |
| M | 6 |
| Total | 24 |

F (182), R (279), K (128), C (87) y S (115) tienen registro para todas sus fichas, con pendientes técnicos intactos. Restan G (18) y M (seis): 24 fichas para alcanzar 815/815 de desglose documental. Continuar con G y M. S1000RR conserva las ocho hipótesis Keyless no acreditadas; revisar otra parte de S no las libera. El objetivo 815/815 no resuelve afirmaciones pendientes, padrón por mercado, fuentes perdidas, licencias, verificación por unidad o criterios de aceptación; no se denomina 100 % técnico.

Para cada bloque: localizar primero documentos propios por modelo/generación y edición; comprobar contenido y fecha, no solo nombre del archivo; registrar URL/hash/página y alcance; contrastar cada afirmación; señalar campos heredados incoherentes; conservar identidad y fuente original; actualizar registro, panel, CSV, cobertura y pruebas de cambio de contexto. No aplicar códigos F por semejanza sin el diccionario original.

## Pendientes que requieren otra clase de evidencia

Chips, referencias de módulos, opciones por mercado y contactos de conectores requieren identificación aplicable. Un manual de usuario puede dejar esas afirmaciones abiertas. No hay unidad disponible: continuar con documentos públicos sin prometer una inspección física ni rellenar campos con valores supuestos. No reconstruir automáticamente VIN, fabricante de módulo o compatibilidad de programación mediante fotografías o certificados genéricos.

El diccionario original de fuentes F y las revisiones posteriores al ZIP no se recuperaron. Recuperarlos exige que aparezca un respaldo del desarrollador o una entrega verificable; no se recrean como si fueran originales.

## Entrega y validación

RC11 añade revisión documental; mantiene las restricciones técnicas. La regresión de aplicación no sustituye certificación por VIN, licencias de recursos, pruebas en Windows/macOS ni inspección visual de todas las impresiones. Los resultados vigentes se registran en `VALIDACION_RC11.json`.

La generación/verificación de un ZIP local no acredita que el usuario pueda descargarlo desde este chat. Ese canal de entrega continúa pendiente. No publicar ni desplegar como solución automática a esa limitación.
