# Aceptación de B8-RC1

## Dictamen

**Candidata funcional para revisión local, con base técnica incompleta.** No se declara el proyecto terminado al 100 %, ni cobertura OEM completa, ni compatibilidades certificadas por VIN. La ausencia del documento maestro original de aceptación limita la posibilidad de acreditar todos sus requisitos; los siguientes son criterios explícitos de esta recuperación.

La entrega incluye aplicación, recursos recuperados, documentos, originales B8, iniciadores locales y verificación de integridad. No incluye despliegue, publicación, autenticación OEM, sincronización de notas ni datos inventados para cerrar pendientes.

## Criterios comprobados

| Criterio | Resultado y evidencia |
|---|---|
| Conservar fuente B8 | PASA: HTML, inventario y LEEME originales en `originals/b8`; hashes fijados en `VERSION.json`. `catalogData` y CSV originales no cambian. |
| Ejecutar localmente | PASA en Linux: `scripts/serve_catalog.py`, Python estándar, escucha en 127.0.0.1; sirve catálogo y cobertura. No abre el servicio a la red pública. |
| Representar todas las selecciones existentes | PASA: 701 combinaciones seleccionables (386 transponders y 315 diagnóstico), identidad y título exactos, diagnóstico con contenido, restricciones de transponders intactas, sin excepciones JS; se comprueba reinicio posterior. |
| Conservar Keyless de emergencia | PASA como histórico: 114 filas permanecen en los datos sin constituir un tercer sistema seleccionable. No se borran para mejorar el conteo de pruebas. |
| Búsqueda y comparador | PASA en los recorridos probados, incluidos alias; no significa certificación del resultado técnico. |
| Copia, favoritos y notas | PASA en los recorridos de `test_daily_workflow.py`, incluidos bloqueo de resultado histórico, recarga, duplicados, cuota y exportación de sesión. |
| Impresión | PARCIAL: PDF real y texto/restricciones comprobados; espera de imágenes acotada. No se inspeccionaron todas las páginas/modelos ni impresoras físicas. |
| Biblioteca visual | PASA funcionalmente: 24 recursos, hashes, filtros, ampliación y móvil. Identificación individual/licencias pendientes. |
| Cobertura y padrón | PASA como inventario de B8: 815 identidades, 132 con conciliación detallada; unknowns se conservan como null/blancos. Generador rechaza datos obsoletos. |
| Paquete e integridad | PASA: ZIP autocontenido con manifiesto, CRC y hashes; original B8 comprobado. Prueba detecta alteraciones y evita sobrescribir una entrega existente. No es firma digital. |

La prueba global recorre la lógica y DOM del catálogo en Chromium mediante sus funciones/eventos de selección; no simula 701 veces todos los clics físicos. Se complementa con recorridos reales de controles para los bloques y funciones de uso diario. Las imágenes y fuentes remotas no quedan validadas por el mero renderizado de una ficha.

## Criterios todavía no acreditados

| Pendiente | Situación |
|---|---|
| Certificar las 815 fichas | NO CUMPLIDO: 683 sin conciliación detallada; en los tres bloques conciliados quedan 367 afirmaciones pendientes y 245 con respaldo limitado. |
| Reconstruir controles técnicos | NO CUMPLIDO: 500 reglas no tienen vínculo histórico verificable. Se mantiene restricción; no se reasignan por posición ni por semejanza. |
| Padrón BMW 2003–2027 por mercado | NO CUMPLIDO: no hay padrón maestro autorizado; B8 abarca 2000–2026. Los candidatos 2027 no se convierten en datos confirmados. |
| Resolver referencias F y revisiones perdidas | NO CUMPLIDO: el diccionario y entregas posteriores no fueron recuperados. |
| Homologación/compatibilidad por unidad | NO CUMPLIDO: manual, imagen y certificado no identifican cada VIN, módulo, RF, chip ni equipo de programación. No se dispone de unidades para esas comprobaciones. |
| Atribuciones y permisos de imágenes | PENDIENTE: no se presume autorización por el nombre `official_` ni por recuperar un archivo. |
| Galería original | NO RECUPERADA: se implementó una biblioteca nueva sobre recursos disponibles. |
| Apertura directa file:// | NO VALIDADA: navegador administrado la bloquea con `ERR_BLOCKED_BY_ADMINISTRATOR`; el iniciador HTTP es el modo comprobado. |
| Windows/macOS e impresoras | NO EJECUTADOS en esos sistemas; se proporcionan envoltorios de inicio e instrucciones. |

## Puerta de salida

Esta candidata permite evaluar la aplicación y continuar la auditoría desde una entrega única. **No habilita declarar terminado el catálogo técnico ni publicar compatibilidades como certificadas.** Los pendientes deben resolverse por evidencia trazable o aceptarse explícitamente como parte del alcance de un catálogo de referencia; no desaparecen por aprobar la interfaz.

No se realizó publicación ni despliegue. El ZIP no incorpora notas guardadas en navegadores de usuarios. Exportarlas es una operación separada.
