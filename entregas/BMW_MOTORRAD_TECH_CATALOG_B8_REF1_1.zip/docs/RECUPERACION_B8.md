# Recuperación B8 — primera implementación

## Procedencia y conservación

Base HTML original SHA-256: `09c3aa2be251a75b5282d425b362475f2a13155b3dd3cb22935fbb87ec464533`.
La base original también está en el commit `d0a182df7941c68079f9d5e65f6829c97b31bfae`.
En esta máquina hay copias originales en `/workspace/catalog-recovery/originals/`; no depender de esa ruta para restaurar otra máquina.

Archivo recuperado: `BMW_F800GS_798_895_AUDITORIA_CONSOLIDADA.zip`, SHA-256 `844dd4c1e4510ce951c4134cc98f8a3b98911934b4c0a068bc84c7fb70d6ea07`.
No se importó su HTML ni sus fichas. Su fallo `antennaInfo` pertenece a otra implementación y no se trasladó a B8.

`recovered-assets.json` registra los hashes de 89 recursos copiados sin transformación. Se excluyeron cinco ilustraciones, un recorte no aprobado y otro marcado para revisión. La recuperación no acredita licencia, atribución OEM ni correspondencia visual individual. Se conservaron las asociaciones visuales ya existentes en B8; no se ampliaron rangos por nombres de archivo. La galería original no fue entregada; se reconstruyó una biblioteca con ese nombre de archivo para reparar las rutas existentes, sin atribuirle autenticidad OEM. Véase `BIBLIOTECA_VISUAL.md`.

## Reparaciones funcionales

- Funciones de normalización y búsqueda compartidas en `recovery-core.js`, accesibles por buscador, consulta inversa y comparador.
- Variable `internalChange` declarada en el controlador de declaración de sistema.
- Función de recortes disponible para el cálculo de cobertura visual. El contador mide asignaciones en la tabla existente, no certificación ni reconocimiento de la imagen.
- Comparador y consulta inversa respetan el estado pendiente del vínculo de auditoría.

## Vínculos técnicos pendientes

Las 482 reglas históricas y la metadata se conservan en el HTML como evidencia histórica. Ninguna se aplica por posición: 170 sistemas discrepaban y 18 fichas adicionales carecían de entrada. No existe prueba suficiente para declarar confiable siquiera el prefijo donde coincide el sistema.

La identidad estable de una ficha es `transponders:` más el array JSON de cadenas `[year,family,model,platform,system]`. Permanece estable al reordenar datos y diferencia sistemas y plataformas. Un cambio de identidad requiere revisar sus vínculos; no normalizar nombres silenciosamente.

`pending-audit-bindings.json` enumera las 500 identidades y sus referencias originales. Es inventario de revisión, no una tabla de autorizaciones cargada por la aplicación. Actualmente `auditRuleFor` devuelve un estado pendiente para todas ellas; la ficha principal restringe referencias técnicas y el comparador no presenta su resultado como liberado. Declarar Keyless o Mecánica no resuelve el vínculo documental.

El JSON `catalogData`, las otras tablas JSON históricas y el CSV de inventario permanecen intactos. No se reconstruyeron fuentes F001–F189 ni se certificaron chips, antenas o aplicaciones por VIN. Las superficies QA conservan datos históricos para investigación.

## Validación y límites

`tests/test_recovery.py` comprueba integridad de datos y recursos, sintaxis JavaScript, inicialización, búsqueda y alias, comparador, declaración de sistema y revocación, restricciones visuales, estabilidad de las 500 identidades, cobertura visual, filtro QA y un estado móvil. No equivale a probar cada combinación ni a certificar exactitud BMW.

Pendiente: validación documental por afirmación y mercado, reconstrucción de fuentes codificadas, revisión visual y licencias, revisión de la galería reconstruida y regresión completa de todos los recorridos. La validación inicial de impresión y persistencia se documenta en `VALIDACION_USO_DIARIO.md`. No se realizaron publicación ni despliegue.

## Bloque piloto F800GS

La conciliación local está descrita en [F800_CIERRE_CONCILIACION.md](F800_CIERRE_CONCILIACION.md), con registro estructurado en `f800-reconciliation.json` y 210 afirmaciones en `F800_AFIRMACIONES.csv`. La aplicación añade un panel documental mediante `f800-evidence.js`; esa capa no cambia reglas ni libera aplicaciones. El acceso a BMW y HEX ya funciona. El estado actual distingue evidencia documental limitada y verificaciones de unidad pendientes; véase `ESTADO_ACTUAL.md`.
