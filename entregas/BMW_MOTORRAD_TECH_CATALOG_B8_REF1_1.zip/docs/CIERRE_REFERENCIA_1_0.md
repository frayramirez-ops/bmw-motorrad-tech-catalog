# Primera entrega de referencia — B8-REF1.0

El software queda cerrado en el alcance de catálogo de referencia local aceptado por el usuario. No se continúa creando candidatas por cada nueva consulta documental. El trabajo de validación técnica se conserva como una línea posterior con objetivos concretos: `PLAN_POSTERIOR_REFERENCIA.md`.

## Qué recibe esta versión

Aplicación local, buscador, comparador, notas/favoritos con respaldo, copia e impresión restringidas, biblioteca reconstruida, cobertura y consulta/exportación de pendientes. Incluye las 815 fichas originales, 89 recursos recuperados, catorce registros documentales, instrucciones, originales B8 y manifiesto de integridad.

Al abrir, la aplicación muestra «Catálogo de referencia local», las cifras documentales y enlaces directos a cobertura y pendientes. Las 3760 afirmaciones conservan sus estados: 1306 con respaldo limitado y 2454 pendientes. Los 17 bloques JSON del HTML y los 14 registros documentales son idénticos a RC16; solo cambia la presentación del alcance, documentación y metadatos de entrega. Ninguna regla de programación se libera.

## Comprobación de esta versión

El resultado de regresión se registra en `VALIDACION_REFERENCIA_1_0.json`. La verificación de la aplicación extraída está en `VALIDACION_ENTREGA_LOCAL_REFERENCIA_1_0.json`. Se comprueban integridad, HTTP local, recursos, uso sin solicitudes remotas y muestras digitales de impresión. Las muestras PDF incluidas en `muestras_impresion/` siguen identificadas como RC15 y son antecedentes; no se presentan como PDF nuevos de esta versión.

## Uso

Extraer el paquete completo. Con Python 3 instalado, abrir `INICIAR_CATALOGO.bat` en Windows o ejecutar `sh iniciar_catalogo.sh` en macOS/Linux. Mantener la ventana abierta y consultar desde la dirección local que muestra. Véase `LEEME_PRIMERO.md` para puertos y respaldo de notas.

## Pasos externos abiertos

- Confirmar que el usuario recibe y abre el paquete: la descarga previa no funcionó y esta sesión no dispone de una herramienta de adjuntar/exportar archivos. No hay recepción acreditada.
- Comprobar el sistema e impresora del usuario; las pruebas actuales se realizan en Linux/Chromium.
- Completar permisos/atribuciones antes de distribuir públicamente las imágenes.
- Recuperar las fuentes originales y aportar evidencias concretas para convertir referencias en datos técnicos acreditados.

Se completa el alcance del software de referencia, con esas limitaciones explícitas. No se declara 100 % del proyecto técnico original, certificación por VIN, recepción del paquete ni autorización de distribución pública. No se publicaron ni desplegaron cambios.
