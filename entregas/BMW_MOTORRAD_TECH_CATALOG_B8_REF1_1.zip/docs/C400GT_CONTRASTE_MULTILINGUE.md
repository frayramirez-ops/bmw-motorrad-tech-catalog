# C400GT: contraste de lector de respaldo — RC13

Se revisaron diez PDF oficiales adicionales: cinco ediciones alemanas (LANGUAGE 00) y cinco españolas (LANGUAGE 03). El idioma se verificó en la portada, junto con el modelo y el colofón; los códigos de archivo por sí solos no se usan para identificar idioma/mercado. Las URL, hashes y entradas del índice por modelo/plataforma/periodo están en `c-reconciliation.json`.

## Resultado

- En alemán, las cinco ediciones mezclan cubierta de batería (Batterieabdeckung) y cubierta de rueda trasera (Hinterradabdeckung) dentro del procedimiento de respaldo. La discrepancia no es exclusiva del inglés.
- En español, las ediciones 06.2018, 09.2020 y 02.2022 mezclan tapa de batería y guardabarros trasero. Las ediciones 09.2024 y 03.2025 son internamente coherentes: indican tapa de batería a la altura de la antena 3. Esta consistencia es evidencia favorable en esas ediciones, pero difiere de los textos alemán/inglés; no se presenta como una errata oficial ni certifica una unidad.
- En los cinco manuales ingleses, el capítulo de batería describe el soporte con antena 3. PDF 83, 161 y 163 de 09.2024 se comprobaron visualmente: respaldo, soporte/antena y tapa. Las figuras aportan contexto, sin autorizar identificación de frecuencia, semiconductor o compatibilidad por VIN.

Las 16 afirmaciones de antena de C400GT conservan estado pendiente. No se elige una traducción por mayoría ni se traslada la posición de C400X. Se necesitan aclaración OEM aplicable o evidencia identificada de unidad/variante que resuelva el procedimiento. No se liberó programación ni se alteró el dato original B8.

## Páginas y correspondencia

Son páginas PDF. Los periodos/idiomas se vinculan por entrada del índice, sin tratarlos como países ni años completos de producción.

| Edición | Respaldo alemán PDF | Respaldo español PDF | Soporte de batería inglés PDF | Texto español coherente internamente |
|---|---|---:|---|---|
| 06.2018 | 68,69 | 75 | 170,171 | No |
| 09.2020 | 71 | 75 | 175,177 | No |
| 02.2022 | 71 | 77 | 174,175 | No |
| 09.2024 | 87 | 89 | 161,163 | Sí, con discrepancia entre idiomas |
| 03.2025 | 89 | 89 | 163,165 | Sí, con discrepancia entre idiomas |

Se añadieron diez fuentes y 21 observaciones a la base C: ahora contiene 38 fuentes (36 PDF y dos web), 92 observaciones y las mismas 400 afirmaciones (105 con respaldo limitado, 295 pendientes). Los 2.495 pendientes globales no disminuyen por haber abierto documentos adicionales. Las fuentes comparadas permanecen separadas y se conserva la contradicción previa.

## Consulta y validación

La nueva vista `PENDIENTES_TECNICOS.html` permite filtrar C / Antena / C400GT: muestra las 16 afirmaciones, incluidas ocho emergencias históricas, con límites, acciones y enlaces de cada observación. Las pruebas comprueban que continúan pendientes y que la nueva procedencia no libera datos. Resultados: `VALIDACION_RC13.json`.

Los PDF remotos no se redistribuyen dentro del paquete; se conserva su metadata de descarga y se contrastan sus hashes con los archivos locales.
