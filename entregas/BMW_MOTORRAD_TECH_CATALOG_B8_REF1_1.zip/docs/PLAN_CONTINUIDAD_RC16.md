# Continuidad después de RC16

## Inventario documental cerrado

Las 815 fichas originales tienen revisión detallada en catorce registros. Sus 3760 afirmaciones se distribuyen en 1306 con respaldo limitado y 2454 pendientes; no hay fichas sin desglose. El 100 % corresponde al inventario recibido, sin certificar compatibilidad ni cobertura de producción por mercado.

El trabajo cambia de recorrer familias a resolver afirmaciones. La vista de pendientes ya permite consultar y exportar por modelo/tema/año, incluidos los límites y fuentes de cada caso. `PENDIENTES_TECNICOS_B8.csv`, generado con `scripts/build_coverage.py`, mantiene cada pendiente ligado a identidad, registro de origen, fuentes/observaciones, límite y acción requerida. Actualizar el JSON de origen y regenerar; no editar el CSV como base maestra. `CIERRE_INVENTARIO_DOCUMENTAL.md` detalla los conteos por tema y la secuencia de trabajo.

## Siguientes trabajos y criterios de salida

1. Usar el borrador `SOLICITUD_AL_DESARROLLADOR_ORIGINAL.md` para solicitar al desarrollador original diccionario F001–F189, revisiones posteriores al ZIP, fuentes y matriz de aceptación original. Conservar procedencia; no reconstruirlos como si fueran originales. Revisar también los vínculos de las 500 reglas de programación antes de liberar cualquier resultado.
2. Contrastar discrepancias documentales con referencias propias de modelo/variante/edición. Priorizar hipótesis Keyless S1000RR, cubiertas contradictorias C400GT (el contraste alemán/español está en `C400GT_CONTRASTE_MULTILINGUE.md`; siguen abiertas las 16 afirmaciones), chips C600/C650, cronologías y transiciones CT/C16C. Un nuevo manual puede ayudar sin resolver una unidad.
3. Resolver mercado/equipamiento, chip, módulo y contactos con documento aplicable o evidencia identificada de unidad/pieza. El usuario no dispone de motocicleta: no prometer inspección ni rellenar VIN/partes con valores supuestos. Una homologación genérica no identifica un mando Keyless.
4. Establecer padrón OEM autorizado por mercado 2003–2027 y reglas para alias/modelos/años. No inventar 2027 ni confundir el denominador B8 (2000–2026) con producción BMW completa.
5. Completar aceptación de producto: licencias/atribuciones de recursos, Windows/macOS, muestra de impresiones, canal de entrega accesible y criterios originales pendientes. No publicar ni desplegar como solución automática a la falta de descarga.

Cada cierre exige evidencia trazable en su afirmación y pruebas de no mezclar identidades. Las ocho hipótesis y todos los resultados restringidos se mantienen hasta satisfacer el criterio correspondiente. No se elimina un pendiente por aceptar la interfaz.

## Base funcional y entrega

Resultados vigentes: `VALIDACION_RC16.json`; criterios: `ACEPTACION_RC16.md`. Aplicación estática local con Python estándar para servirla; 701 selecciones y 114 emergencias históricas. Las notas pertenecen al navegador y deben exportarse antes de mover origen/equipo.

El ZIP local con manifiesto verifica integridad de archivos; no acredita descarga desde el chat, licencia, firma digital ni validez técnica. El canal de entrega sigue sin vía comprobada. No se realizó publicación ni despliegue.

## Avance de acceso RC14 (conservado)

Se incorporaron 33 referencias especialista de acceso, sin certificar formato/contactos. Restan seis accesos por discrepancia de variante, plataforma o periodo, descritos en `SEGUIMIENTO_ACCESOS_RC14.md`. Mantenerlos pendientes hasta contar con evidencia específica; no completar la cifra por analogía. Continuar con documentos aplicables, fuentes perdidas y criterios de aceptación, usando la consulta para priorizar por afirmación.

## Salida del cierre funcional local

La revisión de impresión y de paquete extraído está en `CIERRE_FUNCIONAL_Y_BLOQUEOS.md`. Para completar el proyecto técnico hacen falta evidencias/criterios de los responsables, licencias y validación en plataformas objetivo, además de un canal de entrega recibido. El software conserva sus restricciones. No se crearán compatibilidades para completar un porcentaje.

## Criterio temporal revisado

No aceptar ni rechazar una obra solo por ser posterior al año de la ficha. Exigir asignación editorial OEM de plataforma/periodo, pasaje aplicable y alcance limitado. La corroboración con otra edición no extiende automáticamente su periodo. RC16 aplica este criterio a cuatro fichas mecánicas; los demás pendientes no reciben aprobación por analogía.
