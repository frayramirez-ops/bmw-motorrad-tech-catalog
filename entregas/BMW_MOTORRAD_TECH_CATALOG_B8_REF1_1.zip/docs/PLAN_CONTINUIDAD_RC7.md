# Continuidad después de RC7

## Base comprobada

815 fichas originales preservadas. Hay 475 con revisión detallada y 340 sin desglose; las no revisadas no reciben conteos ficticios de afirmaciones. En los nueve bloques revisados hay 1428 afirmaciones pendientes y 757 con respaldo limitado, sin certificar unidades. La matriz `ACEPTACION_RC7.md` mantiene abiertos los criterios no demostrados.

## Orden de trabajo documental

| Familia | Fichas aún sin desglose |
|---|---:|
| F | 28 |
| K | 128 |
| R | 0 |
| C | 87 |
| S | 73 |
| G | 18 |
| M | 6 |
| Total | 340 |

R conserva las 279 fichas con revisión y F tiene 154 de 182. Las 40 fichas F650/F700 ya tienen desglose en RC7, con monocilíndricas/bicilíndricas separadas y sus pendientes intactos. Restan 28 fichas F: F900GS/Adventure (24), F900R (dos) y F450GS (dos). Revisar ese bloque antes de pasar a K (128). No completar opciones de mercado ni chips por analogía; los 112 pendientes individuales de F800GS continúan abiertos.

Para cada bloque: localizar primero documentos propios por modelo/generación y edición; comprobar contenido y fecha, no solo nombre del archivo; registrar URL/hash/página y alcance; contrastar cada afirmación; señalar campos heredados incoherentes; conservar identidad y fuente original; actualizar registro, panel, CSV, cobertura y pruebas de cambio de contexto. No aplicar códigos F por semejanza sin el diccionario original.

## Pendientes que requieren otra clase de evidencia

Chips, referencias de módulos, opciones por mercado y contactos de conectores requieren identificación aplicable. Un manual de usuario puede dejar esas afirmaciones abiertas. No hay unidad disponible: continuar con documentos públicos sin prometer una inspección física ni rellenar campos con valores supuestos. No reconstruir automáticamente VIN, fabricante de módulo o compatibilidad de programación mediante fotografías o certificados genéricos.

El diccionario original de fuentes F y las revisiones posteriores al ZIP no se recuperaron. Recuperarlos exige que aparezca un respaldo del desarrollador o una entrega verificable; no se recrean como si fueran originales.

## Entrega y validación

RC7 añade revisión documental; mantiene las restricciones técnicas. La regresión de aplicación no sustituye certificación por VIN, licencias de recursos, pruebas en Windows/macOS ni inspección visual de todas las impresiones. Los resultados vigentes se registran en `VALIDACION_RC7.json`.

La generación/verificación de un ZIP local no acredita que el usuario pueda descargarlo desde este chat. Ese canal de entrega continúa pendiente. No publicar ni desplegar como solución automática a esa limitación.
