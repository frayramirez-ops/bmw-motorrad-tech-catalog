# Solicitud al desarrollador original — respaldo y evidencia pendientes

Texto preparado para que el propietario lo envíe si lo desea. No se ha enviado ningún mensaje externo.

---

Estamos recuperando BMW Motorrad Tech Catalog de RE:MOTO LAB | DUPLIKEY MX. Ya inventariamos las 815 fichas recibidas en B8, sin sustituir datos ni certificar compatibilidades. Para reconstruir lo que falta necesitamos una entrega verificable de estos elementos:

1. La última versión completa y las revisiones posteriores al ZIP rescatado: HTML/código, datos, recursos, dependencias, instrucciones de ejecución y lista de cambios. Indica fecha, versión y commit si existe. Si no hay paquete completo, entrega los cambios parciales con su versión base.
2. El diccionario de fuentes F001–F189: cada código con título, URL/documento, edición/fecha, página y alcance de modelo, mercado y variante. Incluye los archivos originales que se puedan compartir legalmente.
3. La relación entre las reglas históricas de auditoría/programación y las fichas: identidad por sección/año/familia/modelo/plataforma/sistema, evidencia y criterio de autorización. No basta el índice o posición de cada arreglo: actualmente las 500 fichas transponder conservan restricción porque ese vínculo no es verificable.
4. La matriz original de requisitos y aceptación, y el padrón maestro BMW por mercado para el alcance 2003–2027. Indica cómo tratabas nombres alternativos, cambios durante el año, variantes y datos sin confirmar.
5. Los respaldos que justifican chips, módulos, frecuencias, antenas y conectores, con referencia de pieza/variante y alcance. Prioridades: hipótesis Keyless S1000RR, conflicto de chip C600/C650, ubicación del lector C400GT (incluida la discrepancia entre idiomas descrita en `C400GT_CONTRASTE_MULTILINGUE.md`) y transiciones CT/C16C. Distingue documentación OEM, especialista y pruebas reales de unidad.
6. Procedencia, atribuciones y permisos de uso de fotografías/diagramas, y el código original de la galería si aún existe. Los nombres de archivo por sí solos no permiten acreditar licencia o identificación.

Para cada entrega, incluye inventario de archivos, tamaño, hash SHA-256 y notas sobre información faltante o contradictoria. No hace falta dar por confirmado un dato que no tenga evidencia: márcalo como pendiente y conserva su historial. Compararemos la entrega con la base preservada antes de importar nada.

---

Referencias de la recuperación: `CIERRE_INVENTARIO_DOCUMENTAL.md`, `PENDIENTES_TECNICOS_B8.csv` y `ACEPTACION_RC16.md`. La solicitud no sustituye el cierre técnico ni demuestra que los respaldos existan.
