# Familia K — modelos, periodos y variantes

## Alcance

128 fichas B8: 83 transponders y 45 diagnóstico. Incluye K1200 LT/RS/GT con nombres antiguos, K1200GT K41/K44, K1300GT, K1600GT/GTL y K1600B. Se conservan 24 emergencias Keyless fuera del selector independiente; 104 consultas son seleccionables. No se agregan modelos, años o variantes para completar producción.

`k-reconciliation.json` conserva identidad/hash y copia idéntica en HTML con panel contextual. Hay 595 afirmaciones: **205 con respaldo limitado** (170 por edición, ocho de homologación y 27 de especialista) y **390 pendientes**. Los CSV `K_AFIRMACIONES.csv` y `K_PENDIENTES.csv` contienen detalle completo y pendientes. No se compararon resultados ZIP: listas vacías no prueban ausencia histórica. El diccionario F sigue sin reconstruirse.

## Documentos y localizadores

32 PDF oficiales, índice BMW y guía HEX consultados; cuatro enlaces históricos de prensa/portal comercial sin verificar por dominio fuera de la política actual. Son 39 fuentes y 101 observaciones con alcance/hash. Página PDF preservada; impresa null cuando no se verificó. Se comprobaron por contenido 45 pasajes EWS/respaldo, además de modelos y colofones.

| Modelo de documento | Edición impresa | Llave, PDF | EWS, PDF | Respaldo Keyless, PDF | Diagnóstico OEM, PDF | Homologación, PDF |
|---|---|---|---|---|---|---|
| K1300GT | 10.2008, 1st edition; colophon PDF 176 visually checked | 53 | 54 | — | — | — |
| K 1200 LT | 08.2002, 4th edition | 14 | — | — | — | — |
| K 1200 RS | 05.2004, 3rd edition; Maintenance Instructions | — | — | — | — | — |
| K1200GT (K41) | 06.2004, 3rd edition | 12 | — | — | — | — |
| K 1200 GT | 07.2003, 2nd edition | 12 | — | — | — | — |
| K1200GT (K44) | 04.2014, 4th edition | 49 | 50 | — | — | — |
| K1200GT (K44) | 06.2006, 2nd edition | 45 | 46 | — | — | — |
| K1600GT | 08.2011, 2nd edition | 46 | 47 | — | — | — |
| K1600GT | 08.2012, 3rd edition | 46 | 47 | — | — | — |
| K1600GT | 08.2013, 4th edition | 44 | 45 | — | — | — |
| K1600GT | 08.2015, 7th edition | 53 | 54 | 58 | — | — |
| K1600GT | 12.2010, 1st edition | 46 | 47 | — | — | — |
| K1600GTL | 08.2011, 2nd edition | 44 | 45 | — | — | — |
| K1600GTL | 08.2012, 3rd edition | 44 | 45 | — | — | — |
| K1600GTL | 08.2013, 4th edition | 44 | 45 | — | — | — |
| K1600GTL | 08.2015, 7th edition | 51 | 52 | 55 | — | — |
| K1600GTL | 12.2010, 1st edition | 44 | 45 | — | — | — |
| K1600GT | 02.2020, 5th edition | 66 | 70 | 69 | — | 257 |
| K1600GT | 04.2018, 3rd edition | 60 | 61 | 65 | — | — |
| K1600GT | 06.2016, 1st edition | 48 | 49 | 53 | — | — |
| K1600GT | 07.2017, 2nd edition | 52 | 53 | 57 | — | — |
| K1600GTL | 02.2020, 5th edition | 66 | 70 | 69 | 198 | 257 |
| K1600GTL | 04.2018, 3rd edition | 62 | 63 | 67 | 162 | — |
| K1600GTL | 07.2017, 2nd edition | 54 | 55 | 59 | 154,155 | — |
| K1600GTL | 11.2016, 1st edition | 54 | 55 | 59 | 154,155 | — |
| K1600GT | 03.2024, 4th edition | — | 96 | 97 | 208 | 266 |
| K1600GT | 06.2021, 1st edition | — | 72 | 73 | 209 | 259 |
| K1600GT | 08/2023, 3rd edition | — | 75 | 76 | 213,214 | 273 |
| K1600GTL | 03.2024, 4th edition | — | 96 | 97 | 211,212 | 272 |
| K1600GTL | 06.2021, 1st edition | — | 72 | 73 | 213 | 263 |
| K1600GTL | 08/2023, 3rd edition | — | 75 | 76 | 217,218 | 277 |
| K1600B | 03.2024, 4th edition | — | 96 | 97 | 208 | 268 |

«—» significa contenido no utilizado para acreditar esa afirmación, sin probar ausencia de función. Las entradas de índice por archivo/plataforma/periodo no identifican una unidad ni permiten fusionar variantes. La K1300GT tiene portada y colofón comprobados visualmente por texto dañado: PDF 1 y 176, 10.2008, 1st edition, Order No. 01 41 7 714 561. El anexo de seguridad 04.2010 posterior no cambia la fecha de toda la obra.

## Hallazgos

- K1200GT K41 y K44 no comparten automáticamente inmovilizador. En K41 y otras filas antiguas, una llave de giro/mantenimiento no acredita presencia ni ausencia de EWS/transponder; las seis fichas de transponder antiguas/K41 conservan todas sus afirmaciones pendientes.
- K1200GT K44 2007/2008 cita manual 04.2014. Se conserva el conflicto cronológico: el periodo de familia del índice no identifica pieza/equipamiento individual. Ambas fichas de transponder quedan pendientes. El acceso HEX se contrasta de forma independiente, sin usarlo para acreditar inmovilizador.
- También hay conflicto de manual posterior en K1200LT 2001 (08.2002) y K1200RS 2002 (mantenimiento 05.2004). Se señalan ocho filas con conflicto, contando ambas secciones. No se certifican años anteriores desde la edición posterior.
- Las referencias EWS anular se conservan por modelo y edición en K44, K1300 y K1600. No identifican chip, fabricante/pieza o versión de hardware por VIN. K1600GT/GTL 2020/2021 mecánica tienen ocho afirmaciones de chip/módulo con respaldo solo de homologación EWS4/BECOM/TMS37145/DST80/TMS3705 en sus apéndices.
- Las 96 afirmaciones de chip/módulo de variantes Keyless continúan pendientes. El apéndice de EWS no identifica el semiconductor del mando ni convierte HUF/AES128 en compatibilidad individual.
- Varias ediciones 2015–2020 describen respaldo sobre cubierta del depósito; algunas precisan delante del tapón y bajo la cubierta. En las ediciones K1600GT/GTL 2021–2024 utilizadas se describe acercar llave/mando al lector anular 2, sin fijar posición geográfica precisa en el pasaje. No se traslada la ubicación de una edición ni el «bajo asiento» de otra familia.
- K1600B 2026 tiene manual propio recuperado K61 MUE 03.2024. La ficha conserva «POR VERIFICAR/CONFIRMAR SISTEMA»: descripción Keyless y lector sobre cubierta de depósito son referencias de edición, sin identificar sistema instalado, chip, módulo o mercado.
- Los procedimientos OEM de diagnóstico utilizados son propios de GTL desde los documentos 2016, GT desde los documentos 2021 y B. El acceso implica asiento/seguros del soporte; no se certifican contactos C16. Los otros 27 accesos respaldados usan guía HEX, delimitada por modelo/periodo.
- HEX sitúa K1200RS/GT K41 bajo panel trasero izquierdo, LT bajo la parte delantera del asiento delantero y K44/K1300GT en compartimento trasero bajo asiento. La fila K1600 indica asiento delantero, detrás del depósito/delante de batería. Se advierte que el conector adicional de diez contactos bajo asiento trasero puede ser de top case; no se confunde con puerto principal.
- La guía HEX nombra K1600GTL 2010–2014 y GTL Exclusive 2013+. No se extiende Exclusive a GTL 2015/2016. Sin procedimiento propio utilizado para esas dos filas, su acceso queda pendiente.
- Los cuatro CT de GT/GTL 2015/2016 se conservan. Las 45 afirmaciones de conector, 45 de ubicación individual y 128 de mercado/equipamiento permanecen pendientes.

## Validación y cierre de este bloque

Dos pruebas verifican identidad/hash, modelos/plataformas, periodos GTL, conflictos, cuatro CT, límites de homologación, CSV y 104 consultas en Chromium por HTTP local. Incluyen separación de paneles, restricciones de programación, cambio a otra familia y un estado móvil. La cobertura comprueba K 128/128 con desglose. Regresión vigente: `VALIDACION_RC9.json`.

El 100 % de desglose de K no significa certificación técnica. Hay diez filas de este bloque sin afirmaciones suficientemente respaldadas (ocho transponders y dos diagnóstico); se contabilizan como revisadas con pendientes, no como aprobadas. Para llegar a finalización técnica se deben resolver evidencias aplicables y los criterios abiertos de `ACEPTACION_RC9.md`, sin convertir cobertura en certeza.

No se publicó ni desplegó. El JSON/CSV original y las restricciones se conservan. Los PDF quedan fuera del paquete de aplicación; se guardan enlaces, hashes y observaciones. La descarga por este chat sigue pendiente de una vía comprobada.

## Revisión temporal RC16

Para K1200GT K44 2007/2008, el colofón 04.2014 permanece como fecha de publicación. El índice asigna ese manual a EW K44 / tipo 0587 desde 07/2007; PDF 50 describe EWS/antena y se contrasta con 06.2006, PDF 46, sin trasladar el periodo de esa edición anterior. Sistema y antena reciben cuatro referencias limitadas; chip, módulo y mercado siguen pendientes. Las demás diferencias temporales y todas las variantes K41/K44, GT/GTL/Exclusive/B continúan separadas. Véase `TEMPORALIDAD_MANUALES_RC16.md` y `VALIDACION_RC16.json`.
