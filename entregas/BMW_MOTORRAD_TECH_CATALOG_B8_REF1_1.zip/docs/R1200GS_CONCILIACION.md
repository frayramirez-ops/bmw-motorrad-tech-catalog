# R1200GS y Adventure — revisión por plataforma y edición

74 fichas B8: 44 de transponders y 30 de diagnóstico, entre 2004 y 2018. Se conservan sus identidades y hashes sin modificar el JSON original. El registro `r1200gs-reconciliation.json` se incorpora idéntico al panel contextual de la aplicación y al generador de cobertura.

340 afirmaciones: **116 con respaldo limitado (90 de edición y 26 de especialista) y 224 pendientes**. Ninguna constituye certificación por VIN. `R1200GS_AFIRMACIONES.csv` conserva todas; `R1200GS_PENDIENTES.csv` contiene las pendientes. Las listas `zipResults` vacías indican comparación no realizada en este bloque; no acreditan ausencia de datos en el ZIP.

Se consultaron 23 PDF oficiales con respuesta HTTP 200 y hashes de contenido. Se incorpora además la consulta HEX GS-911 de RC14; hay 42 observaciones con página PDF o sección web, alcance y hash del documento. El registro conserva la URL completa de cada fuente. Los PDF descargados permanecen como material de consulta en el entorno; el paquete contiene sus referencias y hashes, no una redistribución de los manuales.

| Manual / edición comprobada | EWS, página PDF | Emergencia Keyless | Acceso diagnóstico |
|---|---:|---:|---:|
| GS 05.2004, 2.ª, con anexos posteriores | 32 | — | — |
| GS 06.2006, 4.ª | 45 | — | — |
| GS 06.2007, 5.ª | 47 | — | — |
| GS 02.2008, 2.ª | 47 | — | — |
| GS 02.2010, 2.ª | 49 | — | — |
| GS 03.2014, 4.1, generación anterior | 43 | — | — |
| GS 02.2013, 3.ª | 48 | — | — |
| GS 02.2014, 5.ª | 47 | — | — |
| GS 09.2014, 7.ª | 47 | 51 | — |
| GS 08.2015, 8.ª | 48 | 52 | — |
| GS 06.2016, 1.ª | 53 | 57 | 167 |
| GS 11.2017, 3.ª | 59 | 63 | 193 |
| Adventure 06.2006, 2.ª | 43 | — | — |
| Adventure 07.2007, 3.ª | 45 | — | — |
| Adventure 09.2007, 1.ª | 47 | — | — |
| Adventure 02.2010, 2.ª | 49 | — | — |
| Adventure 01.2012, 4.ª | 43 | — | — |
| Adventure 08.2012, 5.ª | 43 | — | — |
| Adventure 02.2014, 2.ª | 47 | — | — |
| Adventure 09.2014, «4rd» según colofón | 47 | 51 | — |
| Adventure 08.2015, 5.ª | 47 | 51 | — |
| Adventure 04.2016, 6.ª | 49 | 53 | 152–153 |
| Adventure 11.2017, 8.ª | 59 | 63 | 192–193 |

«—» significa contenido no utilizado como evidencia en esta revisión, sin afirmar ausencia de la función. Numeración impresa no verificada: null. Las ediciones 02.2010 se verificaron visualmente porque la extracción del colofón presenta caracteres dañados.

## Hallazgos

- La asociación usa año, familia, modelo y plataforma exactos. Diagnóstico GS 2013 conserva K25 31 y K50; Adventure 2014 conserva K25 32 y K51. No se mezclan documentos por coincidir año/modelo. No se agregan filas de transponders para cubrir diferencias entre secciones.
- La GS 2012 mecánica y los diagnósticos GS 2012/2013 K25 31 citan la edición 03.2014. Se conserva el conflicto cronológico: la ficha mecánica mantiene todas sus afirmaciones pendientes y el PDF posterior no valida años anteriores. En esos dos diagnósticos, solo acceso recibe una referencia especialista independiente, limitada al modelo/generación y periodo; no se resuelve la cronología del PDF.
- El archivo con nombre 0504 contiene base 05.2004 (colofón PDF 196) y anexos de 07.2005 y 04.2008. No se usa la fecha del último anexo como fecha de toda la obra. La página 32 documenta electrónica EWS e intercambio por la cerradura, pero no nombra expresamente una antena anular: esa afirmación de antena queda pendiente para 2004/2005.
- Los demás pasajes mecánicos revisados nombran antena anular en la cerradura. No identifican semiconductor o módulo por VIN. Las menciones históricas ID46/PCF7936 o DST80 se conservan restringidas y no se acreditan mediante EWS genérico.
- Las ocho ediciones modernas citadas para Keyless describen emergencia en la cubierta de la rueda trasera, a la altura de la antena. No se transfiere una ubicación bajo asiento de otras familias. Emergencia sigue siendo modalidad de Keyless, sin selector independiente.
- Cuatro fichas de diagnóstico tienen respaldo limitado OEM para acceso mediante cubierta de batería y soporte con gancho/seguros. Las otras 26 reciben en RC14 referencia especialista de acceso, separando K25 y K50/K51. Conector, ubicación individual y mercado permanecen pendientes. No se cuentan contactos a partir de una figura o del nombre de la interfaz.
- No se resolvieron los códigos F ni se atribuyó un enlace actual a un código histórico sin su diccionario. No se visitaron enlaces de especialista no permitidos ni se sustituyeron sus afirmaciones por suposiciones.

## Validación y límites

Las dos pruebas del bloque comprueban identidad/hash, modelo de cada fuente, páginas vinculadas por hash, separación de plataformas de transición, las tres fichas con conflicto y los pendientes de chip/módulo/conector/mercado. Recorren las 66 selecciones independientes; ocho emergencias quedan en el registro histórico. La actualización de acceso se comprueba además en `test_access_followup.py`; los resultados vigentes están en `VALIDACION_RC16.json`.

No se publicaron ni desplegaron cambios. La descarga desde este chat continúa sin una vía comprobada; generar o verificar un ZIP local no acredita su recepción por el usuario.

Se comprobó además la integridad local de los 23 PDF descargados y la correspondencia exacta de los 74 enlaces con la fuente de diagnóstico de su modelo, año y plataforma en B8.

## Seguimiento de acceso RC14

La guía HEX GS-911 se volvió a consultar en una instantánea independiente de las anteriores. Se incorporan cuatro observaciones propias por modelo/generación (GS y Adventure, aire y líquido); no se aplican rótulos de adaptador 2015+ al número de contactos. Véase `SEGUIMIENTO_ACCESOS_RC14.md`. Se conserva el estado anterior de cada una de las 26 afirmaciones en `followUp.changes`, sin modificar las demás afirmaciones ni datos B8.

## Revisión temporal RC16

Para la ficha mecánica 2012 K25 31, la diferencia con el colofón 03.2014 se conserva. El índice BMW asigna expresamente ese PDF a la plataforma desde 01/2012 y el pasaje EWS/antena coincide con una edición anterior de la misma plataforma. Solo sistema y antena reciben respaldo de edición acotado; chip, módulo y mercado continúan pendientes. Se añade una instantánea independiente del índice (25 fuentes, 42 observaciones). Véase `TEMPORALIDAD_MANUALES_RC16.md`. El seguimiento de acceso RC14 permanece intacto.
