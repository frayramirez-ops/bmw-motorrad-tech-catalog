# Fecha de edición y periodo asignado por BMW — RC16

Se reevalúa el límite temporal de cuatro fichas mecánicas. La revisión previa dejó pendientes sistema y antena porque el colofón era posterior al año consultado. RC16 distingue esa fecha de publicación del periodo al que BMW asigna expresamente la obra en su índice y contrasta también una edición anterior de la misma plataforma.

No se cambian el año, plataforma, resultado ni cita heredada B8. Tampoco se declara equivocada una fecha de colofón: publicación y producción son conceptos distintos.

## Evidencia contrastada

La nueva consulta del índice oficial BMW, LANGUAGE 01, conserva una instantánea separada: HTTP 200, 2168454 bytes, SHA-256 `450bbd7ae91bf03d9b25753869c96911aa45b95d53897facdccf75db2ea1ccb6`; LABEL-TIME 01.10.2026. Los PDF ya estaban consultados: se volvieron a leer sus pasajes y comprobar sus hashes. No se atribuye información nueva a un PDF solo por descargarlo otra vez.

| Ficha B8 | Manual y EWS/antena PDF | Asignación explícita en índice EUR | Corroboración anterior PDF |
|---|---|---|---|
| R1200GS 2012, K25 31 | 03.2014, PDF 43 | EW K25 31, TYPSCHL 0450, desde 01/2012 | 02.2010, PDF 49 |
| S1000RR 2014, K46 11 | 07.2015, PDF 39 | EW K46 11, TYPSCHL 0524, desde 08/2013 | 08.2012, PDF 37 |
| K1200GT K44 2007/2008 | 04.2014, PDF 50 | EW K44, TYPSCHL 0587, desde 07/2007 | 06.2006, PDF 46 |

Los pasajes describen lectura electrónica de la llave mediante antena anular en la cerradura. La edición anterior aporta coherencia del mecanismo; no se usa para extender su propio periodo. La asignación se conserva con modelo, EW, código de tipo, mercado, periodo y archivo, sin trasladarla a otra plataforma.

## Resultado limitado

Ocho afirmaciones (sistema y antena, dos por ficha) pasan de pendiente a documentado en edición con aplicabilidad individual pendiente. No se deduce que todo el año, otro mercado, un VIN o cada pieza quede cubierto. En particular, los periodos comienzan durante un mes y no se convierten en una certificación de año-modelo completo.

Chip, módulo y mercado/equipamiento de esas cuatro fichas continúan pendientes; no se identifica EWS3/EWS4, semiconductor ni programación a partir del término EWS. No se cambia ninguna hipótesis Keyless ni ninguna afirmación de diagnóstico. Las diferencias de fechas permanecen visibles y los hallazgos/afirmaciones previos se conservan en `temporalEvidence` y `temporalFollowUp`.

Global: 3760 afirmaciones, 1306 con respaldo limitado y 2454 pendientes. Quedan 52 afirmaciones de sistema y 109 de antena pendientes; las restantes categorías no cambian. Los 14 registros conservan 815 fichas. Hay 757 fichas con algún respaldo limitado, 50 sin respaldo suficiente y ocho hipótesis no acreditadas.

## Validación

La comparación con la entrega RC15 confirmó exactamente ocho cambios de afirmación, todos en los dos temas indicados. Las demás afirmaciones, identidades, resultados, hashes B8 y el seguimiento de acceso RC14 se conservan. `test_chronology.py` exige la asignación explícita de periodo/plataforma, tres fuentes por afirmación, los estados pendientes restantes y las restricciones de consulta; recorre las cuatro fichas en Chromium.

Los resultados completos están en `VALIDACION_RC16.json`. La fecha posterior por sí sola no constituye evidencia de aplicabilidad; tampoco basta con que una edición anterior describa un sistema parecido. Se requiere la combinación registrada. No se publicó ni desplegó ni se certificaron unidades.
