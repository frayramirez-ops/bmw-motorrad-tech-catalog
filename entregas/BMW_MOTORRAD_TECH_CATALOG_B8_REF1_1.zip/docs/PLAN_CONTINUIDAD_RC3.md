# Continuidad después de RC3

## Base comprobada

815 fichas originales preservadas. Hay 251 con revisión detallada y 564 sin desglose; las no revisadas no reciben conteos ficticios de afirmaciones. En los cinco bloques revisados hay 766 afirmaciones pendientes y 394 con respaldo limitado, sin certificar unidades. La matriz `ACEPTACION_RC3.md` mantiene abiertos los criterios no demostrados.

## Orden de trabajo documental

| Familia | Fichas aún sin desglose |
|---|---:|
| F | 136 |
| K | 128 |
| R | 116 |
| C | 87 |
| S | 73 |
| G | 18 |
| M | 6 |
| Total | 564 |

Continuación dentro de R: R nineT y variantes reúnen 70 fichas (nineT 20, Pure 14, Scrambler 14, Urban G/S 14, Racer seis, /5 dos). Las otras 46 cubren varios modelos antiguos y recientes; no deben fusionarse bajo una sola edición. Después se puede priorizar F y K por volumen. Este orden no convierte volumen revisado en exactitud técnica.

Para cada bloque: localizar primero documentos propios por modelo/generación y edición; comprobar contenido y fecha, no solo nombre del archivo; registrar URL/hash/página y alcance; contrastar cada afirmación; señalar campos heredados incoherentes; conservar identidad y fuente original; actualizar registro, panel, CSV, cobertura y pruebas de cambio de contexto. No aplicar códigos F por semejanza sin el diccionario original.

## Pendientes que requieren otra clase de evidencia

Chips, referencias de módulos, opciones por mercado y contactos de conectores requieren identificación aplicable. Un manual de usuario puede dejar esas afirmaciones abiertas. No hay unidad disponible: continuar con documentos públicos sin prometer una inspección física ni rellenar campos con valores supuestos. No reconstruir automáticamente VIN, fabricante de módulo o compatibilidad de programación mediante fotografías o certificados genéricos.

El diccionario original de fuentes F y las revisiones posteriores al ZIP no se recuperaron. Recuperarlos exige que aparezca un respaldo del desarrollador o una entrega verificable; no se recrean como si fueran originales.

## Entrega y validación

RC3 añade revisión documental; mantiene las restricciones técnicas. La regresión de aplicación no sustituye certificación por VIN, licencias de recursos, pruebas en Windows/macOS ni inspección visual de todas las impresiones. Los resultados vigentes se registran en `VALIDACION_RC3.json`.

La generación/verificación de un ZIP local no acredita que el usuario pueda descargarlo desde este chat. Ese canal de entrega continúa pendiente. No publicar ni desplegar como solución automática a esa limitación.
