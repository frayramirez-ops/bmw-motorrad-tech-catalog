# Últimas fichas R — modelos antiguos y recientes

## Alcance y dictamen

46 fichas B8: 23 transponders y 23 diagnóstico. Se separan 30 filas antiguas (2001–2003) y 16 recientes (2024–2026). Se conservan sus identidades, campos pendientes, resultados y hashes; no se agregan sistemas ni variantes. `r-final-reconciliation.json` tiene copia idéntica en el HTML y panel contextual propio.

207 afirmaciones: **36 con respaldo limitado (24 por edición y 12 por especialista) y 171 pendientes**. Las 15 fichas antiguas de transponder mantienen todas sus afirmaciones pendientes. Las 279 fichas R existentes en B8 tienen ahora desglose documental, sin certificar la familia ni acreditar cobertura mundial por mercado.

Los CSV `R_FINAL_AFIRMACIONES.csv` y `R_FINAL_PENDIENTES.csv` conservan detalle completo y pendientes. No se compararon resultados del ZIP en este bloque; las listas vacías no demuestran ausencia histórica.

## Fuentes y páginas

25 fuentes registradas: 15 PDF oficiales, índice oficial, guía HEX y dos páginas BMW México consultadas; seis citas de prensa/ManualsLib sin verificar. Los dominios de estas últimas no están en la política de red vigente, y no se atribuye verificación de contenido por el título o URL. Hay 46 observaciones con alcance y hash; en PDF se usa número de página PDF y la impresa queda en null.

| Modelo / edición impresa | Respaldo Keyless, PDF | Acceso diagnóstico, PDF | Alcance |
|---|---:|---|---|
| R18 Classic 04/2023, 6.ª | 60 | 158 | Referencia primaria para ficha 2024; VIN/plataforma pendientes |
| R18 Roctane 09/2022, 1.ª | 64 | 154–155 | Referencia primaria para ficha 2024; no fecha de fabricación |
| R18 Classic 04.2024, 1.ª | 64 | 157–158 | Contraste de subgeneración K34 11 |
| R18 Roctane 04.2024, 1.ª | 60 | 148–149 | Contraste de subgeneración K34 11 |
| R12 nineT 04.2024, 3.ª | 82 | 186–187 | Portada propia; distinta de nineT anterior |
| R12 G/S March 2025, 2.ª | 80 | 188–189 | Portada propia, referencia para ficha 2026 |
| R12 S March 2025, 2.ª | 82 | 186–187 | Portada específica S; no manual genérico nineT |
| R1300 R March 2025, 2.ª | 103 | 233–234 | Modelo/plataforma propios, sin certificar MY completo |
| R1300 RS March 2025, 2.ª | 105 | 239–240 | Modelo/plataforma propios |
| R1300 RT March 2025, 2.ª | 107 | 256–257 | Fuente oficial adicional a cita histórica externa |

El índice conserva entradas por nombre de archivo, plataforma y periodo; no se elige una unidad por analogía. Para R12 S, el periodo la distingue dentro de entradas R12 nineT, y la portada confirma S. En R18 se conserva K34 separado de K34 11, sin reemplazar el campo «POR VERIFICAR» de B8.

| Manual antiguo recuperado | Páginas llave/cerradura | Límite |
|---|---|---|
| R1100 S, colofón 10.00, 5.ª | 10–11 | Marcas de maquetación 2010; no certifica equipamiento 2001/2002 |
| R1150 GS/Adventure 10.2002, 6.ª | 12–13 | Posterior a ficha GS 2001; no prueba transponder en ninguna fila |
| R1150 R 05.2004, 4.ª | 10–11 | Posterior a ficha 2002 |
| R1150 RS 10.2002, 2.ª | 10–11 | Giro de llave no resuelve inmovilizador |
| R1150 RT 04.2003, 3.ª | 10–11 | El archivo dice 0902, pero el colofón es 2003: posterior a ficha 2002 |

## Hallazgos

- Los manuales antiguos describen posiciones mecánicas de llave. No demuestran presencia ni ausencia de EWS, chip o antena. Sus observaciones se conservan como insuficientes; no cambian a estado respaldado por abrir el documento.
- No se recuperó manual técnico propio aplicable para R1100 R/RS/RT, R1100 S Light, R1200 C Montana/Phoenix y R1200 CL desde el índice consultado. No equivale a afirmar que tales manuales no existan. Las notas de prensa siguen sin contraste técnico.
- La guía HEX aporta acceso limitado para 12 filas antiguas de diagnóstico: R1100 R/RS/RT/S, R1150 GS/Adventure/R/RS/RT y R1200 CL dentro de sus rangos declarados. No se extiende una fila R1100S a Light ni R1200C a Montana/Phoenix sin evidencia de equivalencia.
- HEX distingue: asientos delantero/trasero en R1100RS/RT; compartimento bajo asiento trasero en R1100R; parte delantera del asiento en R1100S; zona sobre caja de filtro de aire en R1150; cubierta cromada delantera izquierda en R1200CL. Ninguna de estas referencias certifica contactos ni formato C10/C16.
- Las 16 filas recientes tienen manual propio de consulta. El sistema/lector descrito es referencia de edición; no resuelve automáticamente «CONFIRMAR SISTEMA», mercado o plataforma de la unidad. No se asignan chips o módulos desde certificados EWS4/Keyless.
- El lector de respaldo reciente está bajo el asiento. El acceso diagnóstico R18 usa soporte de carenado izquierdo; R12 usa cubierta específica y pestañas/soporte, conservando cableado; R1300 requiere asiento del conductor. No se fusionan esos desmontajes.
- La página BMW México Roctane incluye Keyless Ride en equipamiento de serie, pero la consulta actual no delimita MY 2024: las dos afirmaciones de mercado/equipamiento Roctane siguen pendientes, con esa observación visible. El listado general de modelos tampoco identifica sistema o conector.
- Las fechas impresas pueden diferir de los nombres: R12 nineT `0724` indica 04.2024; R12 G/S `0825` y R12 S `0725` indican March 2025. Se registra el colofón, sin deducir fecha por nombre del archivo.
- Las etiquetas de sistema heredadas en diagnóstico no identifican puerto: Keyless, «CONFIRMAR SISTEMA» y «SISTEMA NO VERIFICADO» no se convierten en C10/C16.

## Aplicación y validación

El panel muestra nombre y edición del documento y distingue cita histórica de fuente actual. Se conserva la apertura segura de enlaces HTTPS con texto escapado por DOM. Esta presentación se aplica también a los bloques anteriores; no cambia sus estados ni fuentes.

Dos pruebas comprueban límites de inmovilizador antiguo, fuentes/modelos, las seis filas con conflicto cronológico de colofón, CSV, referencias únicas, 46 consultas, cambio de contexto, etiquetas de edición y un estado móvil. La cobertura comprueba que R suma 279 filas con desglose. Regresión vigente: `VALIDACION_RC5.json`.

No se publicó ni desplegó. Las fuentes JSON/CSV originales y las restricciones técnicas permanecen. Los PDF consultados quedan fuera del paquete de aplicación; se conservan sus enlaces, hashes y observaciones. La descarga por este chat sigue pendiente de una vía comprobada.
