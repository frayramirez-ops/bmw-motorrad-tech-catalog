# Continuidad después de RC9

## Base comprobada

815 fichas originales preservadas. Hay 631 con revisión detallada y 184 sin desglose; las no revisadas no reciben conteos ficticios de afirmaciones. En los once bloques revisados hay 1897 afirmaciones pendientes y 1015 con respaldo limitado, sin certificar unidades. La matriz `ACEPTACION_RC9.md` mantiene abiertos los criterios no demostrados.

## Orden de trabajo documental

| Familia | Fichas aún sin desglose |
|---|---:|
| F | 0 |
| K | 0 |
| R | 0 |
| C | 87 |
| S | 73 |
| G | 18 |
| M | 6 |
| Total | 184 |

F (182), R (279) y K (128) tienen registro de revisión para todas sus fichas, con pendientes técnicos intactos. Restan C (87), S sin revisar (73), G (18) y M (seis): 184 fichas para alcanzar 815/815 de desglose documental. Continuar con C, después S y cerrar G/M. S1000RR conserva su revisión e hipótesis no acreditadas. El objetivo 815/815 no resuelve las afirmaciones pendientes, el padrón mundial por mercado, fuentes perdidas, licencias, verificación por unidad o los restantes criterios de aceptación; no se lo denomina 100 % técnico.

Para cada bloque: localizar primero documentos propios por modelo/generación y edición; comprobar contenido y fecha, no solo nombre del archivo; registrar URL/hash/página y alcance; contrastar cada afirmación; señalar campos heredados incoherentes; conservar identidad y fuente original; actualizar registro, panel, CSV, cobertura y pruebas de cambio de contexto. No aplicar códigos F por semejanza sin el diccionario original.

## Pendientes que requieren otra clase de evidencia

Chips, referencias de módulos, opciones por mercado y contactos de conectores requieren identificación aplicable. Un manual de usuario puede dejar esas afirmaciones abiertas. No hay unidad disponible: continuar con documentos públicos sin prometer una inspección física ni rellenar campos con valores supuestos. No reconstruir automáticamente VIN, fabricante de módulo o compatibilidad de programación mediante fotografías o certificados genéricos.

El diccionario original de fuentes F y las revisiones posteriores al ZIP no se recuperaron. Recuperarlos exige que aparezca un respaldo del desarrollador o una entrega verificable; no se recrean como si fueran originales.

## Entrega y validación

RC9 añade revisión documental; mantiene las restricciones técnicas. La regresión de aplicación no sustituye certificación por VIN, licencias de recursos, pruebas en Windows/macOS ni inspección visual de todas las impresiones. Los resultados vigentes se registran en `VALIDACION_RC9.json`.

La generación/verificación de un ZIP local no acredita que el usuario pueda descargarlo desde este chat. Ese canal de entrega continúa pendiente. No publicar ni desplegar como solución automática a esa limitación.
