/* Documentary reconciliation only: this layer cannot release technical rules. */
function mountDocumentaryReview(dataId, panelId, titleText) {
 'use strict';
 const data = JSON.parse(document.getElementById(dataId).textContent);
 const records = new Map(data.records.map(r => [r.recordId, r]));
 const sources = new Map(data.sources.map(s => [s.id, s]));
 const observations = new Map(data.observations.map(o => [o.id, o]));
 const result = document.getElementById('result');
 const panel = document.createElement('section');
 panel.id = panelId; panel.hidden = true;
 panel.setAttribute('aria-label', titleText);
 panel.style.cssText = 'border:1px solid #acbfd4;border-radius:10px;padding:14px;margin:14px 0;overflow-wrap:anywhere';
 result.append(panel);
 function node(tag, text) { const n = document.createElement(tag); n.textContent = text; return n; }
 function refresh() {
  panel.replaceChildren(); panel.hidden = true;
  if (result.hidden) return;
  const selection = selected();
  const record = sourceRows().find(r => ids.every(k => String(r[k]) === String(selection[k])));
  if (!record) return;
  const id = tab + ':' + JSON.stringify(ids.map(k => String(record[k] ?? '')));
  const review = records.get(id);
  if (!review) return;
  panel.hidden = false; panel.dataset.recordId = id;
  panel.append(node('h3', titleText));
  panel.append(node('p', 'Generación: ' + review.generation.replaceAll('_', ' ') + ' · ' + record.year + ' · ' + record.system));
  panel.append(node('p', 'Los datos documentados describen el modelo y la edición citada, sin certificación por VIN. Los campos sin evidencia se indican por separado.'));
  if (review.referenceFacts) {
   const summary = node('section', ''); summary.dataset.referenceFacts = 'true';
   summary.append(node('h4', 'Ficha de referencia actualizada'));
   summary.append(node('p', review.referenceFacts.scope));
   summary.append(node('small', 'Revisión: ' + review.referenceFacts.reviewedOn));
   const facts = document.createElement('dl');
   for (const fact of review.referenceFacts.facts) {
    facts.append(node('dt', fact.label));
    const value = node('dd', fact.value);
    for (const id of fact.observations) {
     const observation = observations.get(id);
     const source = observation && sources.get(observation.sourceId);
     if (!source || !observation.pdfPage) continue;
     let url; try { url = new URL(source.url); } catch (_) { continue; }
     if (url.protocol !== 'https:') continue;
     url.hash = 'page=' + observation.pdfPage;
     const link = node('a', 'Manual BMW · PDF ' + observation.pdfPage + (observation.printedPage == null ? '' : ' / impresa ' + observation.printedPage));
     link.href = url.href; link.target = '_blank'; link.rel = 'noopener noreferrer';
     const paragraph = document.createElement('p'); paragraph.append(link); value.append(paragraph);
    }
    facts.append(value);
   }
   summary.append(facts); panel.append(summary);
  }
  const documented = document.createElement('ul');
  const pending = document.createElement('ul'); pending.dataset.pendingClaims = 'true';
  const labels = {
   PENDIENTE_CONTRASTE_DOCUMENTAL:'pendiente de evidencia aplicable',
   REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE:'referencia de especialista documentada',
   DOCUMENTADO_EN_EDICION_APLICABILIDAD_PENDIENTE:'documentado en el manual citado',
   OPCION_DOCUMENTADA_APLICABILIDAD_PENDIENTE:'opción descrita en el manual',
   HOMOLOGACION_DOCUMENTADA_UNIDAD_PENDIENTE:'documentado en certificado de homologación'
  };
  for (const claim of review.claims) {
   const item = node('li', claim.topic.replaceAll('_', ' ') + ': ' + (labels[claim.status] || 'pendiente'));
   if (claim.finding) item.append(node('p', claim.finding));
   const isPending = claim.status === 'PENDIENTE_CONTRASTE_DOCUMENTAL';
   if (isPending && claim.nextAction) item.append(node('p', 'Para resolver: ' + claim.nextAction));
   for (const id of claim.observations || []) {
    const observation = observations.get(id);
    if (observation) item.append(node('small', observation.pdfPage ? 'Página PDF ' + observation.pdfPage + (observation.printedPage == null ? '' : ', impresa ' + observation.printedPage) + '. ' + observation.scope : observation.section + '. ' + observation.scope));
   }
   (isPending ? pending : documented).append(item);
  }
  if (documented.children.length) {
   const details = document.createElement('details'); details.dataset.documentedClaims = 'true';
   details.open = !review.referenceFacts;
   details.append(node('summary', 'Información documentada (' + documented.children.length + ' temas)'));
   details.append(documented); panel.append(details);
  }
  if (pending.children.length) {
   panel.append(node('h4', 'Campos pendientes de evidencia (' + pending.children.length + ')'));
   panel.append(pending);
  }
  for (const finding of review.findings) panel.append(node('p', finding));
  if (review.sourceCodes.length) panel.append(node('p', 'Códigos históricos sin resolver: ' + review.sourceCodes.join(', ') + '. Los enlaces siguientes no se atribuyen a esos códigos.'));
  const links = document.createElement('ul');
  const seen = new Set();
  for (const ref of review.references) {
   const source = sources.get(ref.sourceId);
   if (!source || seen.has(source.id)) continue;
   let url; try { url = new URL(source.url); } catch (_) { continue; }
   if (url.protocol !== 'https:') continue;
   seen.add(source.id);
   const li = document.createElement('li');
   const prefix = ref.origin === 'CITA_HISTORICA_B8' ? (source.status === 'CONTENIDO_CONSULTADO' ? 'Cita histórica B8, consultada: ' : 'Cita histórica B8, sin verificar: ') : (source.status === 'CONTENIDO_CONSULTADO' ? 'Fuente consultada: ' : 'Fuente citada, sin verificar: ');
   const a = node('a', prefix + (source.documentEdition || url.hostname));
   a.href = url.href; a.target = '_blank'; a.rel = 'noopener noreferrer';
   li.append(a); links.append(li);
  }
  panel.append(links);
  if (!seen.size) panel.append(node('p', 'Sin enlace documental recuperado para esta identidad exacta.'));
 }
 for (const id of ids) document.getElementById(id).addEventListener('change', () => queueMicrotask(refresh));
 document.querySelectorAll('.tabs [data-tab]').forEach(b => b.addEventListener('click', () => queueMicrotask(refresh)));
 new MutationObserver(() => queueMicrotask(refresh)).observe(result, {attributes:true, attributeFilter:['hidden']});
 window.addEventListener('beforeprint', refresh);
 refresh();
}
mountDocumentaryReview('f800EvidenceData', 'f800Evidence', 'Conciliación documental · F800GS');
mountDocumentaryReview('s1000EvidenceData', 's1000rrEvidence', 'Conciliación documental · S1000RR');
mountDocumentaryReview('r1250EvidenceData', 'r1250Evidence', 'Conciliación documental · R1250GS / Adventure');
mountDocumentaryReview('r1200EvidenceData', 'r1200Evidence', 'Conciliación documental · R1200GS / Adventure');
mountDocumentaryReview('rTouringEvidenceData', 'rTouringEvidence', 'Conciliación documental · R1250RT / R1300GS y Adventure');
mountDocumentaryReview('ninetEvidenceData', 'ninetEvidence', 'Conciliación documental · R nineT y variantes');
mountDocumentaryReview('rFinalEvidenceData', 'rFinalEvidence', 'Conciliación documental · R antiguas y recientes');
mountDocumentaryReview('f750f850EvidenceData', 'f750f850Evidence', 'Conciliación documental · F750GS / F850GS / Adventure');
mountDocumentaryReview('f650f700EvidenceData', 'f650f700Evidence', 'Conciliación documental · F650 / F700 y generaciones');
mountDocumentaryReview('fFinalEvidenceData', 'fFinalEvidence', 'Conciliación documental · F900 / F450');
mountDocumentaryReview('kEvidenceData', 'kEvidence', 'Conciliación documental · Familia K');
mountDocumentaryReview('cEvidenceData', 'cEvidence', 'Conciliación documental · Familia C');
mountDocumentaryReview('sFinalEvidenceData', 'sFinalEvidence', 'Conciliación documental · S1000R / S1000XR');
mountDocumentaryReview('gmEvidenceData', 'gmEvidence', 'Conciliación documental · Familias G / M');
