'use strict';
function normVisual(v){
 return String(v||'').toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^A-Z0-9]+/g,'');
}
// Alias de entrada SOLO para búsquedas textuales. No infiere año, plataforma, VIN ni IMMO.
function normalizedBMWModelInput(value){
 const k=normVisual(value);
 const aliases={R1250GSA:'R1250GSADVENTURE',R1200GSA:'R1200GSADVENTURE',R1300GSA:'R1300GSADVENTURE',F850GSA:'F850GSADVENTURE',F900GSA:'F900GSADVENTURE'};
 return aliases[k]||k;
}
// Búsqueda tolerante a espacios / siglas, SIN inferir generación ni plataforma.
function matchesBMWModelQuery(label, query){
 const input=String(query||'').trim();
 if(!input)return true;
 const target=normVisual(label),whole=normalizedBMWModelInput(input);
 if(target.includes(whole))return true;
 const words=input.split(/\s+/).filter(Boolean);
 return words.every(word=>target.includes(normalizedBMWModelInput(word)));
}

// Stable identity is independent of array order. No historical rule is inferred.
function auditRecordId(record) {
 return 'transponders:' + JSON.stringify(['year','family','model','platform','system'].map(k=>String(record[k] ?? '')));
}
function auditRuleFor(record) {
 return Object.freeze({recordId:auditRecordId(record),control:'VINCULO_AUDITORIA_PENDIENTE',
  scope:'Regla histórica pendiente de vinculación documental; no autoriza operación.',
  source:'Tablas históricas conservadas sin asociación por índice.'});
}
function auditFlagsFor(record) {
 const flags=['VINCULO_AUDITORIA_PENDIENTE'];
 if(/CONDICIONAL/i.test(record.evidence||''))flags.push('RESULTADO_CONDICIONAL');
 if(/CONFLICTO/i.test([record.evidence,record.result].join(' ')))flags.push('CONFLICTO_DECLARADO');
 return flags;
}

// A broken or stalled image must not hold the print button indefinitely.
function waitForPrintImages(images, timeoutMs = 2500) {
 return Promise.all(images.map(image => new Promise(resolve => {
  let finished = false;
  const done = () => {
   if (finished) return;
   finished = true;
   clearTimeout(timer);
   image.removeEventListener('load', loaded);
   image.removeEventListener('error', done);
   resolve();
  };
  const loaded = () => {
   if (typeof image.decode === 'function') Promise.resolve().then(() => image.decode()).then(done, done);
   else done();
  };
  const timer = setTimeout(done, timeoutMs);
  image.loading = 'eager';
  image.addEventListener('load', loaded, {once:true});
  image.addEventListener('error', done, {once:true});
  if (image.complete) loaded();
 })));
}
