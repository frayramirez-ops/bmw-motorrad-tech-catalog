(function () {
 'use strict';
 const data = JSON.parse(document.getElementById('galleryData').textContent);
 const search = document.getElementById('gallerySearch');
 const kind = document.getElementById('galleryKind');
 const grid = document.getElementById('galleryGrid');
 const dialog = document.getElementById('galleryDialog');
 const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/[^A-Z0-9]/g, '');
 const aliases = {R1250GSA:'R1250GSADVENTURE',R1300GSA:'R1300GSADVENTURE',F850GSA:'F850GSADVENTURE'};
 const scopeText = entry => entry.scope === 'REFERENCIA_DE_FAMILIA' ? 'Fotografía de familia: no identifica una variante individual.' : 'Verificar visualmente modelo, versión y generación antes de asociarla a una ficha.';
 function node(tag, text) { const el = document.createElement(tag); el.textContent = text; return el; }
 function openImage(entry) {
  const image = document.getElementById('dialogImage');
  document.getElementById('dialogTitle').textContent = entry.label;
  document.getElementById('dialogScope').textContent = scopeText(entry);
  image.alt = entry.label + ' · recurso recuperado'; image.src = entry.path;
  dialog.showModal();
 }
 function render() {
  const raw = normalize(search.value), query = aliases[raw] || raw;
  const entries = data.entries.filter(e => (kind.value === 'all' || e.kind === kind.value) && (!query || normalize(e.label).includes(query)));
  grid.replaceChildren();
  for (const entry of entries) {
   const card = document.createElement('article'); card.className = 'card'; card.dataset.entryId = entry.id;
   const button = document.createElement('button'); button.type = 'button'; button.className = 'thumbnail'; button.setAttribute('aria-label', 'Ampliar ' + entry.label);
   const image = document.createElement('img'); image.loading = 'lazy'; image.decoding = 'async'; image.src = entry.path; image.alt = entry.label + ' · ' + (entry.kind === 'recorte' ? 'recorte' : 'fotografía');
   image.addEventListener('error', () => { button.replaceChildren(node('span', 'Recurso no disponible')); button.disabled = true; });
   button.append(image); button.addEventListener('click', () => openImage(entry));
   const type = node('span', entry.kind === 'recorte' ? 'Recorte' : 'Fotografía'); type.className = 'kind';
   card.append(button, node('h2', entry.label), type, node('p', scopeText(entry))); grid.append(card);
  }
  document.getElementById('galleryCount').textContent = entries.length + ' de ' + data.entries.length + ' recursos';
  document.getElementById('galleryEmpty').hidden = entries.length !== 0;
 }
 search.value = new URLSearchParams(location.search).get('modelo') || '';
 search.addEventListener('input', render); kind.addEventListener('change', render);
 document.getElementById('filters').addEventListener('submit', event => event.preventDefault());
 document.getElementById('filters').addEventListener('reset', event => {
  event.preventDefault(); search.value = ''; kind.value = 'all'; render();
 });
 document.getElementById('closeDialog').addEventListener('click', () => dialog.close());
 render();
})();
