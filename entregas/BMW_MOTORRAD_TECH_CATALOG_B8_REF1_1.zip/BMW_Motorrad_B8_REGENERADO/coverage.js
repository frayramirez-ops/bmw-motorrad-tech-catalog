(function () {
 'use strict';
 const data = JSON.parse(document.getElementById('coverageData').textContent);
 const filters = ['coverageSearch','coverageFamily','coverageYear','coverageStatus'].map(id=>document.getElementById(id));
 const [search,family,year,status] = filters;
 const labels = {not_reviewed:'Sin conciliación detallada',limited:'Evidencia limitada; aplicación pendiente',reviewed_pending:'Conciliada; evidencia pendiente',hypothesis:'Hipótesis no acreditada'};
 const size = 40; let page = 0, filtered = [];
 function node(tag,text) { const el=document.createElement(tag);el.textContent=text;return el; }
 for (const [count,label] of [[data.summary.records,'Fichas existentes'],[data.summary.detailed,'Con conciliación detallada'],[data.summary.notDetailed,'Sin conciliación detallada']]) {
  const card=document.createElement('div');card.className='stat';card.append(node('strong',count),node('span',label));document.getElementById('coverageSummary').append(card);
 }
 document.getElementById('claimsSummary').textContent=data.summary.claimsReviewed+' afirmaciones inventariadas en bloques conciliados: '+data.summary.claimsDocumented+' con respaldo limitado y '+data.summary.claimsPending+' pendientes.';
 for (const row of data.families) {
  family.add(new Option(row.family,row.family));
  const el=node('div','Familia '+row.family+': '+row.detailed+' de '+row.records+' fichas con conciliación detallada');el.className='family';document.getElementById('familySummary').append(el);
 }
 for (const value of [...new Set(data.records.map(r=>r.year))].sort((a,b)=>b-a)) year.add(new Option(String(value),String(value)));
 function render() {
  const start=page*size, visible=filtered.slice(start,start+size), body=document.getElementById('coverageRows');body.replaceChildren();
  for (const record of visible) {
   const tr=document.createElement('tr');tr.dataset.recordId=record.recordId;
   for (const text of [record.year,record.family+' · '+record.model,record.platform,(record.section==='transponders'?'Transponders':'Diagnóstico')+' · '+record.system,labels[record.status],record.detailed?record.documentedClaims+'/'+record.claims+' afirmaciones':'Sin desglose']) tr.append(node('td',text));
   const pending=document.createElement('td');
   if(record.pendingClaims>0){const link=node('a',record.pendingClaims+' pendientes');link.href='PENDIENTES_TECNICOS.html?record='+encodeURIComponent(record.recordId);link.setAttribute('aria-label','Ver pendientes de '+record.model+' '+record.year+' '+record.system);pending.append(link);}
   else pending.textContent=record.detailed?'Sin pendientes inventariados':'Sin desglose';
   tr.append(pending);body.append(tr);
  }
  document.getElementById('coverageCount').textContent=filtered.length?(start+1)+'–'+(start+visible.length)+' de '+filtered.length+' fichas':'0 fichas';
  document.getElementById('coverageEmpty').hidden=filtered.length!==0;
  document.getElementById('coveragePage').textContent=filtered.length?'Página '+(page+1)+' de '+Math.ceil(filtered.length/size):'Sin resultados';
  document.getElementById('coveragePrev').disabled=page===0;
  document.getElementById('coverageNext').disabled=start+size>=filtered.length;
 }
 function apply() {
  filtered=data.records.filter(r=>(!family.value||r.family===family.value)&&(!year.value||String(r.year)===year.value)&&(!status.value||(status.value==='detailed'?r.detailed:r.status===status.value))&&(!search.value.trim()||matchesBMWModelQuery([r.year,r.family,r.model,r.platform,r.system].join(' '),search.value)));
  page=0;render();
 }
 search.addEventListener('input',apply);[family,year,status].forEach(el=>el.addEventListener('change',apply));
 document.getElementById('filters').addEventListener('submit',event=>event.preventDefault());
 document.getElementById('filters').addEventListener('reset',event=>{event.preventDefault();filters.forEach(el=>el.value='');apply();});
 document.getElementById('coveragePrev').addEventListener('click',()=>{if(page>0){page--;render();}});
 document.getElementById('coverageNext').addEventListener('click',()=>{if((page+1)*size<filtered.length){page++;render();}});
 apply();
})();
