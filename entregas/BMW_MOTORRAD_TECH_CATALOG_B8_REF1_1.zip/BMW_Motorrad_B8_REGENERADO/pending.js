(function () {
 'use strict';
 const data=JSON.parse(document.getElementById('pendingData').textContent);
 const labels={sistema:'Sistema',chip:'Chip',modulo:'Módulo',antena:'Antena',conector:'Conector',ubicacion:'Ubicación de diagnóstico',acceso:'Acceso diagnóstico',mercado_equipamiento:'Mercado / equipamiento'};
 const fields=['pendingSearch','pendingFamily','pendingTopic','pendingYear'].map(id=>document.getElementById(id));
 const [search,family,topic,year]=fields;
 const size=25;let page=0,filtered=[];
 let recordId=new URLSearchParams(location.search).get('record')||'';
 function node(tag,text){const el=document.createElement(tag);el.textContent=text;return el;}
 function sourceLink(source){
  let url;try{url=new URL(source.url);}catch(_){return null;}
  if(url.protocol!=='https:')return null;
  const prefix=source.status==='CONTENIDO_CONSULTADO'?'Referencia consultada: ':'Cita sin verificar: ';
  const link=node('a',prefix+source.title);link.href=url.href;link.target='_blank';link.rel='noopener noreferrer';return link;
 }
 document.getElementById('pendingSummary').textContent=data.records.length+' afirmaciones pendientes en '+new Set(data.records.map(r=>r.recordId)).size+' fichas del inventario B8.';
 for(const value of [...new Set(data.records.map(r=>r.family))].sort())family.add(new Option(value,value));
 for(const value of Object.keys(labels).filter(k=>data.records.some(r=>r.topic===k)))topic.add(new Option(labels[value],value));
 for(const value of [...new Set(data.records.map(r=>r.year))].sort((a,b)=>b-a))year.add(new Option(String(value),String(value)));
 function render(){
  const start=page*size,visible=filtered.slice(start,start+size),body=document.getElementById('pendingRows');body.replaceChildren();
  for(const row of visible){
   const card=document.createElement('article');card.className='pendingCard';card.dataset.recordId=row.recordId;card.dataset.topic=row.topic;
   card.append(node('h2',row.model+' · '+row.year+' · '+labels[row.topic]),node('p',row.platform+' · '+(row.section==='transponders'?'Transponders':'Diagnóstico')+' · '+row.system));
   if(row.recordStatus==='HIPOTESIS_NO_ACREDITADA'){const flag=node('p','Hipótesis no acreditada; requiere evidencia aplicable.');flag.className='hypothesis';card.append(flag);}
   card.append(node('p','Para resolver: '+row.nextAction));
   const details=document.createElement('details');details.append(node('summary','Ver evidencia y límites'));
   if(row.finding)details.append(node('p',row.finding));
   details.append(node('p','Límite: '+row.limitation));
   for(const finding of row.contextFindings)details.append(node('p',finding));
   if(row.observations.length){
    const list=document.createElement('ul');
    for(const observation of row.observations){
     const item=node('li',(observation.pdfPage?'Página PDF '+observation.pdfPage:observation.section||'Observación')+'. '+observation.scope);
     const link=sourceLink(observation.source);if(link)item.append(document.createElement('br'),link);list.append(item);
    }
    details.append(list);
   }else details.append(node('p','Sin observación documental aplicable registrada para esta afirmación.'));
   if(row.sourceCodes.length)details.append(node('p','Códigos de fuente heredados sin diccionario verificado: '+row.sourceCodes.join(', ')+'. No se atribuyen automáticamente a los enlaces siguientes.'));
   const references=document.createElement('ul');
   for(const source of row.references){const link=sourceLink(source);if(link){const item=document.createElement('li');if(source.origin==='CITA_HISTORICA_B8')item.append(node('span','Cita histórica B8. '));item.append(link);if(source.scope)item.append(node('p','Alcance de la referencia: '+source.scope));references.append(item);}}
   if(references.childElementCount)details.append(references);
   card.append(details);body.append(card);
  }
  document.getElementById('pendingCount').textContent=filtered.length?(start+1)+'–'+(start+visible.length)+' de '+filtered.length+' afirmaciones':'0 afirmaciones';
  document.getElementById('pendingEmpty').hidden=filtered.length!==0;
  document.getElementById('pendingPage').textContent=filtered.length?'Página '+(page+1)+' de '+Math.ceil(filtered.length/size):'Sin resultados';
  document.getElementById('pendingPrev').disabled=page===0;document.getElementById('pendingNext').disabled=start+size>=filtered.length;
  document.getElementById('pendingExport').disabled=filtered.length===0;
  const context=document.getElementById('pendingContext');context.hidden=!recordId;context.textContent=recordId?'Vista limitada a una ficha. «Limpiar filtros» vuelve al inventario completo.':'';
 }
 function apply(){
  filtered=data.records.filter(r=>(!recordId||r.recordId===recordId)&&(!family.value||r.family===family.value)&&(!topic.value||r.topic===topic.value)&&(!year.value||String(r.year)===year.value)&&(!search.value.trim()||matchesBMWModelQuery([r.year,r.family,r.model,r.platform,r.system].join(' '),search.value)));
  page=0;render();
 }
 search.addEventListener('input',apply);[family,topic,year].forEach(el=>el.addEventListener('change',apply));
 document.getElementById('pendingFilters').addEventListener('submit',event=>event.preventDefault());
 document.getElementById('pendingFilters').addEventListener('reset',event=>{event.preventDefault();fields.forEach(el=>el.value='');recordId='';history.replaceState(null,'',location.pathname);apply();});
 document.getElementById('pendingPrev').addEventListener('click',()=>{if(page>0){page--;render();}});
 document.getElementById('pendingNext').addEventListener('click',()=>{if((page+1)*size<filtered.length){page++;render();}});
 document.getElementById('pendingExport').addEventListener('click',()=>{
  if(!filtered.length)return;
  const quote=value=>'"'+String(value??'').replaceAll('"','""')+'"';
  const rows=[['identidad','registro_revision','seccion','anio','familia','modelo','plataforma','sistema','afirmacion','estado','limite','siguiente_accion'],...filtered.map(r=>[r.recordId,r.review,r.section,r.year,r.family,r.model,r.platform,r.system,r.topic,'PENDIENTE_CONTRASTE_DOCUMENTAL',r.limitation,r.nextAction])];
  const blob=new Blob(['\ufeff'+rows.map(r=>r.map(quote).join(',')).join('\r\n')+'\r\n'],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),link=document.createElement('a');
  link.href=url;link.download='BMW_PENDIENTES_FILTRADOS.csv';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
 });
 apply();
})();
