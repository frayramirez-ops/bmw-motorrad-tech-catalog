# BMW Motorrad Tech Catalog — B8-REF3.3

Para uso local, empieza por `LEEME_PRIMERO.md`. Aplicación estática en `BMW_Motorrad_B8_REGENERADO/`. Esta documentación corresponde a la recuperación actual; no sustituye documentos históricos que no fueron entregados.

Lee primero [docs/ESTADO_ACTUAL.md](docs/ESTADO_ACTUAL.md) y después [docs/RECUPERACION_B8.md](docs/RECUPERACION_B8.md) antes de cambiar datos o reglas técnicas.

Arranque desde la raíz del repositorio:

```sh
python3 -m http.server 8000 --bind 127.0.0.1 --directory BMW_Motorrad_B8_REGENERADO
```

Regresión: `python3 -m unittest discover -s tests -v`.

Después de actualizar un registro de conciliación, ejecutar `python3 scripts/build_coverage.py`. Verificar con `python3 scripts/build_coverage.py --check`; la cobertura y el padrón son derivados, no fuentes maestras.
Requiere Python 3, Node.js para comprobaciones sintácticas, Playwright Python, Chromium en `/usr/bin/chromium` y `pdftotext` (Poppler) para comprobar PDF (disponibles en el entorno actual). El catálogo no necesita esos últimos tres componentes para ejecutarse.

Usa el checkout existente: el entorno ya está aislado. No crees worktrees salvo petición expresa. No publiques, despliegues ni certifiques aplicaciones técnicas sin autorización y evidencia.

## Primera entrega de referencia

`VERSION.json` identifica B8-REF3.3; `docs/ACEPTACION_REFERENCIA_1_0.md` fija el alcance aceptado como referencia local y sus límites. Los originales están en `originals/b8`, sin depender de rutas externas del entorno.

Empaquetar: `python3 scripts/package_release.py --output RUTA_NUEVA.zip`. Verificar: `python3 scripts/package_release.py --verify RUTA.zip`. El empaquetador no sobrescribe archivos existentes. Los iniciadores no necesitan Node, Playwright ni paquetes Python; esas herramientas son solo para pruebas.

El inventario documental está cerrado para las 815 fichas B8. Consultar `docs/CIERRE_INVENTARIO_DOCUMENTAL.md`, `docs/PLAN_POSTERIOR_REFERENCIA.md` y el CSV derivado `docs/PENDIENTES_TECNICOS_B8.csv` antes de trabajar en compatibilidades. Son 2144 afirmaciones pendientes, no un porcentaje global de proyecto.

Al cambiar la versión de entrega, actualizar solo el sello de interfaz y las referencias activas. No sustituir versiones globalmente dentro del HTML: los registros JSON embebidos conservan su historial y deben coincidir exactamente con los JSON de `docs/`. Las pruebas de procedencia comprueban esa igualdad.

Cierre funcional local y bloqueos de entrega: `docs/CIERRE_FUNCIONAL_Y_BLOQUEOS.md`. Validación de una entrega extraída: `python3 scripts/verify_local_delivery.py --archive RUTA.zip --output-dir CARPETA_NUEVA`; requiere las herramientas de pruebas y conserva el resultado previo.

El usuario aceptó cerrar la primera versión como catálogo de referencia con pendientes visibles. El cierre del software en ese alcance no certifica datos ni acredita recepción del archivo. No abrir otra ronda de candidatas para resolver evidencias externas sin un objetivo concreto. Estado y validación vigentes: `docs/ACTUALIZACION_DIAGNOSTICA_REF3.md` y `docs/VALIDACION_BLOQUE_3.json`.

## Antecedente: actualización 1.1

Consulta `docs/ACTUALIZACION_R1250GSA_2020.md` para la corrección de la Adventure 2020 y once ubicaciones de GS/Adventure. La ficha separa información documentada y componentes pendientes. La validación de esa versión se registra en `docs/VALIDACION_REFERENCIA_1_1.json`; los documentos de cierre 1.0 son antecedentes de alcance, no cifras actuales.

## Trabajo y entregas por bloques

El usuario solicita avances grandes y transversales, no una entrega por modelo aislado. Agrupar la investigación por tema y contrastar las siete familias antes de entregar. Un modelo señalado por el usuario inicia una revisión del patrón completo. Estado del bloque: `docs/ACTUALIZACION_TRANSVERSAL_REF2.md`; secuencia: `docs/PLAN_DESARROLLO_BLOQUES.md`.

Después de cambiar afirmaciones, observaciones o datos de referencia curados, ejecutar en este orden:

```sh
python3 scripts/build_diagnostic_profiles.py
python3 scripts/build_model_references.py
python3 scripts/build_coverage.py
python3 scripts/build_diagnostic_profiles.py --check
python3 scripts/build_model_references.py --check
python3 scripts/build_coverage.py --check
```

El primer generador actualiza fichas de referencia, catorce JSON embebidos, exportaciones de afirmaciones/pendientes y matriz CSV de campos disponibles. No rellena por año/familia; exige evidencia de la propia ficha, rechaza fuentes sin consultar y evita añadir chip/módulo/conector pendiente como dato curado. Un campo vacío de la matriz significa sin dato documentado para ese campo; no equivale a cero ni a ausencia del componente. Los 815 registros se conservan.

La entrega pública de ZIP y SHA-256 está autorizada por el usuario en la rama `entrega/b8-ref1-0`, conservando `main`. Mantener los paquetes previos, verificar la descarga del nuevo y conservar el trabajo del checkout. Esto no autoriza despliegues web ni mensajes externos.

## Perfiles de diagnóstico REF3

`docs/hex-function-chart-data.json` conserva 159 perfiles normalizados de la tabla pública HEX y su huella. `scripts/build_diagnostic_profiles.py` cruza modelo, plataforma, periodo y, para desambiguar, tipo documental del manual. Rechaza las ocho hipótesis Keyless S1000RR y no extiende intervalos cerrados. Sus nombres de diagnóstico no identifican ECU física, fabricante, PN, chip ni sistema instalado. Los 1000 estados/afirmaciones originales de chip/módulo de REF2 permanecen idénticos.

Verificar la normalización con `scripts/import_hex_function_chart.py --html RUTA_CAPTURA --check-data docs/hex-function-chart-data.json`; requiere una copia del HTML con el SHA-256 declarado. Para actualizar el dataset se debe revisar una captura nueva y sus cambios de alcance; no copiar perfiles entre modelos por similitud.

Los perfiles ampliados se muestran y exportan en la misma matriz. Las tres correcciones de formato de R1100R/RS/RT 2001 están documentadas en `r-final-reconciliation.json`, `diagnosticHardwareUpdate3`. El código original C10 permanece como identidad histórica, no como dato de puerto confirmado.

## Investigación de componentes por lotes

La preparación del siguiente bloque está en [docs/COMPONENTES_BLOQUE_4.md](docs/COMPONENTES_BLOQUE_4.md). `scripts/build_component_batches.py` genera una cola de 192 lotes con las 1000 afirmaciones de chip/módulo, conservando sus estados y evidencia. `--check` detecta salidas obsoletas. Es una herramienta de investigación; no actualiza la aplicación ni acredita componentes por agrupación. La cola no altera los datos técnicos. REF3.1 añade la guía de conexión descrita abajo; las afirmaciones de hardware mantienen el estado de REF3.0.

## Guía de conexión REF3.1

`GUIA_INTERFACES_HEX.html` permite consultar los formatos físicos y adaptadores HEX según puerto y herramienta identificados, sin asignarlos por año. Incluye la incompatibilidad eléctrica de la interfaz amarilla antigua con el adaptador OBD-II. Datos: `docs/hex-connector-reference.json`; sincronizar y verificar con `python3 scripts/build_connector_reference.py` y `--check`. Alcance y pruebas: `docs/GUIA_INTERFACES_REF3_1.md`. Los estados de las 3760 afirmaciones y sus 1000 contenidos de chip/módulo permanecen iguales a REF3.0.

## Actualización de datos REF3.2

Estado vigente y evidencia: `docs/ACTUALIZACION_EWS_RT_REF3_2.md`. El cribado de 500 identidades permitió revisar diez afirmaciones EWS mecánico de R1250RT 2020–2024 con cinco páginas primarias y huellas verificadas. `componentHomologationUpdate4` conserva los estados previos y restringe el delta; las pruebas reconstruyen exactamente la huella de las 1000 afirmaciones anteriores a este bloque. Los perfiles HEX no acreditan hardware ni intervienen en esta corrección. Los apartados REF3/REF3.1 anteriores conservan su historial.

## Puntos de lectura REF3.3

R1250RT 2019–2022 Keyless incorpora ocho referencias de punto de lectura de respaldo por manual propio, distinguiendo cuadro anterior y TFT. No se identifica la pieza interna de antena ni se cambia chip/módulo. El estado actual es 1616 referencias limitadas y 2144 pendientes; véase `docs/ACTUALIZACION_LECTURA_RT_REF3_3.md`. Los números anteriores corresponden al historial de bloques.
