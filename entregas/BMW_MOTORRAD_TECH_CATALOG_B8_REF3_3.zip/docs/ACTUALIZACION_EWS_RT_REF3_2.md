# REF3.2 — referencias de homologación EWS por edición

Se cribaron las 500 identidades de transponder de las siete familias, usando su fuente primaria y sistema seleccionado. El resultado está en `REVISION_APENDICES_COMPONENTES.json`; es una búsqueda dirigida de identificadores en las capturas, no una declaración de lectura completa de todos los manuales. Las cinco páginas candidatas se volvieron a extraer de los PDF y sus SHA-256 se cotejaron contra las recuperaciones originales.

## Cambio de datos

Las fichas de **R1250RT 2020–2024, solo Mecánica**, tenían pendientes las referencias de chip y módulo pese a que su propia edición cita el equipo. Se incorporan diez afirmaciones con estado `HOMOLOGACION_DOCUMENTADA_UNIDAD_PENDIENTE`:

- El apéndice cita el transponder **TMS37145 / tipo DST80**, a 134 kHz.
- **TMS3705** se identifica como **IC de estación base**, separado del transponder de la llave.
- La declaración identifica el transceptor de inmovilizador **EWS4** y a **BECOM Electronics GmbH**.

No se confirma el componente instalado, PN, equipamiento de mercado ni aplicación por VIN. Las páginas pertenecen a declaraciones con sus propios ámbitos regulatorios; no acreditan que una motocicleta concreta comercializada en México monte esa pieza. Estas referencias no se trasladan a la selección Keyless, a R1250RT 2019, a otros años ni a otras familias.

| Ficha | Edición propia | Página PDF |
|---|---|---:|
| R1250RT 2020 Mecánica | 08.2019, 3.ª | 270 |
| R1250RT 2021 Mecánica | 07.2020, 1.ª | 295 |
| R1250RT 2022 Mecánica | 06.2021, 2.ª | 299 |
| R1250RT 2023 Mecánica | 04.2022, 3.ª | 308 |
| R1250RT 2024 Mecánica | 04/2023, 4.ª | 302 |

Las referencias históricas US 2023 que B8 citaba para 2021/2022 no se usan como fuente primaria de la corrección. Las cinco ediciones ya estaban consultadas y vinculadas a sus respectivas fichas. La distinción entre página PDF y página impresa se conserva; las cifras de la tabla son páginas del archivo.

## Integridad y efecto

`componentHomologationUpdate4` en `r1250rt-r1300gs-reconciliation.json` conserva los diez objetos de afirmación anteriores y las cinco observaciones nuevas. La prueba reconstruye la huella exacta previa de las 1000 afirmaciones de chip/módulo, permitiendo únicamente el delta acotado a esas cinco identidades y dos temas. Los perfiles de software HEX no son la evidencia de este cambio.

El inventario B8 sigue en 815 registros y 3760 afirmaciones. Las referencias limitadas pasan de **1598 a 1608**, y los pendientes de **2162 a 2152**. Dentro de los 192 lotes de componentes hay ahora 852 afirmaciones pendientes y 148 con referencias limitadas. Estos números no miden piezas instaladas confirmadas ni porcentaje de finalización.

Las páginas, fuentes y huellas están en `VERIFICACION_EWS4_RT.json`. Se actualizan los resúmenes por ficha, los catorce JSON embebidos y las exportaciones mediante los generadores existentes. El resumen de programación conserva su restricción y los originales B8 permanecen intactos.

## Comprobaciones

La regresión comprueba todas las selecciones y la presencia de los datos en las cinco fichas mecánicas, su ausencia en Keyless/2019 y la distinción de TMS3705. La muestra de entrega añade impresión de R1250RT 2023 Mecánica. Resultados: `VALIDACION_REF3_2.json` y `VALIDACION_ENTREGA_REF3_2.json`.

El acceso a los proveedores externos continúa sin aplicarse. Esta revisión usa las capturas oficiales existentes; no declara resuelto ese acceso ni completa por analogía los componentes restantes.
