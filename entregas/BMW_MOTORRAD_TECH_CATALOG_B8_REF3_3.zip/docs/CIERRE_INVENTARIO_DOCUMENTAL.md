> Estado vigente REF3.3: 1616 referencias limitadas y 2144 pendientes. Ocho posiciones de lectura de respaldo RT se incorporan con fuente y configuración de cuadro; no se identifica la pieza interna. Véase `ACTUALIZACION_LECTURA_RT_REF3_3.md`.

> Actualización vigente REF3.2: 3760 afirmaciones, 1608 referencias limitadas y 2152 pendientes. El cierre del inventario no certifica datos por unidad. La revisión de cinco apéndices EWS propios incorpora diez referencias limitadas y conserva los estados anteriores; véase `ACTUALIZACION_EWS_RT_REF3_2.md`. Las cifras anteriores de este documento se conservan como historial.

# Inventario documental B8 y seguimiento técnico — B8-REF3.0

**815/815 fichas recibidas tienen desglose documental (100 % del inventario B8).** Se preservan fuente, identidad y resultados originales. Catorce registros contienen 3760 afirmaciones: 1598 con respaldo limitado de edición, homologación, opción o especialista, y 2162 pendientes. Este hito no certifica motocicletas ni declara terminado el proyecto técnico.

Hay 757 fichas con algún respaldo limitado, 50 revisadas sin respaldo suficiente y ocho hipótesis Keyless S1000RR sin acreditar. Las familias C, F, G, K, M, R y S quedan inventariadas. Ninguna ficha se eliminó para mejorar el indicador. B8 abarca 2000–2026; el padrón BMW por mercado 2003–2027 sigue sin establecerse.

## Pendientes identificados

`PENDIENTES_TECNICOS_B8.csv` reúne cada afirmación abierta y su registro de origen; se regenera mediante `python3 scripts/build_coverage.py`. No editarlo como fuente maestra. Las cifras siguientes cuentan afirmaciones, no motocicletas o inspecciones necesarias: una ficha puede tener varias.

| Tema | Afirmaciones pendientes |
|---|---:|
| Sistema | 52 |
| Chip | 431 |
| Módulo | 431 |
| Antena | 109 |
| Conector | 312 |
| Ubicación sin respaldo suficiente de manual/especialista | 6 |
| Acceso diagnóstico | 6 |
| Mercado/equipamiento | 815 |
| Total | 2162 |

## Siguiente fase de desarrollo y aceptación

- Recuperar diccionario F, revisiones perdidas y matriz de aceptación original del primer desarrollador. Sin esa procedencia, las 500 reglas de programación permanecen sin asociación documental verificable; no se reasignan por posición o parecido. Esos vínculos son un control separado de las 3760 afirmaciones.
- Resolver contradicciones con documentos específicos antes de solicitar datos de unidad: hipótesis Keyless S1000RR, cubiertas C400GT, chips C600/C650, fechas e identidades CT/C16C. Añadir evidencia al registro correcto y probar el cambio de contexto, conservando historial del dato recibido.
- Para compatibilidad técnica, identificar mercado, variante, fecha y componente mediante documento aplicable o evidencia de unidad. No hay motocicleta disponible: no prometer inspecciones ni rellenar VIN, chips, módulos o contactos por analogía. Una certificación genérica no identifica todos los componentes.
- Completar aceptación funcional fuera del entorno Linux: Windows/macOS, muestra de impresiones y licencias/atribuciones de recursos. El ZIP 1.0 ya se entregó por GitHub; mantener el canal de entrega y comprobar los archivos de nuevas versiones.
- Revaluar la matriz `ACEPTACION_RC16.md` cuando exista evidencia de cada criterio. La aplicación conserva sus restricciones mientras la compatibilidad no esté acreditada; el usuario autorizó distribuir los paquetes en la rama de entrega de GitHub; no hay despliegue web.

## Qué está comprobado y qué falta

La regresión verifica el funcionamiento de 701 selecciones, paneles documentales, búsqueda, comparador, notas/favoritos, copia, impresión restringida, galería, HTTP local y paquete con manifiesto. Permanecen 114 emergencias históricas en datos. Los resultados exactos y límites de prueba están en `VALIDACION_RC16.json`; no sustituyen verificación por VIN ni disponibilidad de todo el padrón BMW.

El alcance cerrado es el inventario documental recibido. El alcance pendiente comprende evidencia técnica, aceptación completa y entrega accesible. No se asigna un porcentaje global de proyecto mezclando esos denominadores.

## Seguimiento RC13

En RC13 se conservaron los conteos del cierre RC12. La consulta interactiva de pendientes permite filtrar, revisar fuentes/acciones y exportar coincidencias. El contraste C400GT añade diez manuales y 21 observaciones, sin cerrar sus 16 afirmaciones de antena; la diferencia entre idiomas queda registrada. Véase `PENDIENTES_CONSULTA.md` y `C400GT_CONTRASTE_MULTILINGUE.md`.

## Seguimiento RC14

Se incorporan referencias especialista de acceso para 33 afirmaciones de R1200GS/Adventure y S1000RR, separando modelos y refrigeración. El total pasa de 2495 a 2454 pendientes; 1298 afirmaciones tienen respaldo limitado. Quedan seis accesos con límites de variante, plataforma o periodo sin resolver. Ningún conector, CT ni resultado de programación se libera por este cambio. Véase `SEGUIMIENTO_ACCESOS_RC14.md`.

## Revisión temporal RC16

El índice oficial de plataforma/periodo y pasajes EWS concordantes sustentan ocho afirmaciones de sistema/antena en cuatro fichas mecánicas. El total actual es 2454 pendientes y 1306 con respaldo limitado, sin certificación individual. Se conserva el historial y la diferencia entre fecha de edición y periodo de producción. Véase `TEMPORALIDAD_MANUALES_RC16.md`.

## Actualización B8-REF1.1

Once ubicaciones de GS/Adventure tienen respaldo explícito en la vista lateral derecha de sus propios manuales. Total vigente: 1317 referencias limitadas y 2443 pendientes; ninguna regla de chip/programación se libera. La ficha Adventure 2020 distingue datos de modelo y componentes sin evidencia. Los apartados RC anteriores son históricos.

## Bloque transversal B8-REF2.0

Se resuelven 278 ubicaciones adicionales y se generan resúmenes de evidencia para 757 fichas de las siete familias. Se añaden datos de pila/alcance en 222 registros Keyless; no se aplica una pila universal. Estado vigente: `ACTUALIZACION_TRANSVERSAL_REF2.md`.

## Bloque REF3

Se añaden perfiles de diagnóstico del fabricante en 789 fichas y se documenta formato de tres pines en tres diagnósticos R1100. Los perfiles no identifican pieza ni chip; las afirmaciones de chip/módulo de REF2 no cambian. Estado vigente: `ACTUALIZACION_DIAGNOSTICA_REF3.md`.
