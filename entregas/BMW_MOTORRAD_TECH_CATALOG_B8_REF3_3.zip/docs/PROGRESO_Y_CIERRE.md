# Progreso y trabajo para el cierre — REF3.3

Fecha de revisión: 10 de noviembre de 2026.

La aplicación de referencia local está entregada y probada en Linux/Chromium. Esto no acredita ejecución en Windows/macOS ni aceptación en el equipo del usuario. El porcentaje global de finalización no está fijado: faltan la matriz original de aceptación completa y el padrón por mercado.

El indicador documental es **43,0 %**: 1616 de 3760 afirmaciones tienen referencia limitada. Las otras 2144 siguen pendientes. Una referencia limitada no certifica chip, módulo, equipamiento o compatibilidad por VIN.

| Tema | Referencias limitadas | Total | Proporción | Pendientes |
|---|---:|---:|---:|---:|
| sistema | 448 | 500 | 89,6 % | 52 |
| chip | 74 | 500 | 14,8 % | 426 |
| modulo | 74 | 500 | 14,8 % | 426 |
| antena | 399 | 500 | 79,8 % | 101 |
| mercado_equipamiento | 0 | 815 | 0,0 % | 815 |
| conector | 3 | 315 | 1,0 % | 312 |
| ubicacion | 309 | 315 | 98,1 % | 6 |
| acceso | 309 | 315 | 98,1 % | 6 |

Los 852 pendientes conjuntos de chip/módulo y 312 de conector son los primeros bloques de componentes. Las 815 afirmaciones de mercado/equipamiento necesitan fuentes comerciales y de opciones, con alcance de modelo separado de la unidad instalada. No se elimina una afirmación por falta de evidencia ni se presenta como confirmada para aumentar el porcentaje.

## Revisión de los seis diagnósticos restantes

Se revisaron las fuentes y límites registrados de las seis ubicaciones pendientes. No se cambió ninguna afirmación:
- K1600GTL 2015: La guía HEX consultada delimita GTL 2010–2014; la fila Exclusive 2013+ no acredita GTL 2015/2016. El manual propio consultado no aporta una ubicación específica suficiente.
- K1600GTL 2016: La guía HEX consultada delimita GTL 2010–2014; la fila Exclusive 2013+ no acredita GTL 2015/2016. El manual propio consultado no aporta una ubicación específica suficiente.
- R nineT /5 2020: Conflicto de plataforma: B8 K21, índice y edición propia /5 desde Pure K22; no se traslada la ubicación a la plataforma original sin resolver la discrepancia.
- R 1100 S Light 2001: Fuente comercial/prensa heredada sin verificar en este bloque; no se dispone de pasaje aplicable a esta variante que identifique la ubicación.
- R 1200 C Montana 2001: Fuente comercial/prensa heredada sin verificar en este bloque; no se dispone de pasaje aplicable a esta variante que identifique la ubicación.
- R 1200 C Phoenix 2001: Fuente comercial/prensa heredada sin verificar en este bloque; no se dispone de pasaje aplicable a esta variante que identifique la ubicación.

Los detalles y conteos reproducidos desde los catorce registros se conservan en `PROGRESO_PROYECTO.json`. Se requiere evidencia nueva o resolver el conflicto señalado antes de completar esos campos. La última entrega pública verificada es REF3.2. REF3.3 incorpora ocho referencias de punto de lectura; su estado de publicación se verifica por separado.
