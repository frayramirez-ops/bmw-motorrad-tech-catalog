# REF3.3 — puntos de lectura de respaldo por configuración de cuadro

Se revisaron los límites registrados de 161 afirmaciones pendientes: 109 de antena/lectura y 52 de sistema, repartidas entre las siete familias. El cotejo dirigido de ocho páginas de cuatro manuales propios permitió incorporar ocho referencias de punto de lectura en R1250RT 2019–2022, para las filas Keyless principal y emergencia. Las otras 153 afirmaciones conservan su estado pendiente. El análisis no equivale a lectura completa de todos los manuales.

## Datos incorporados

| Edición propia | Fichas | Página PDF | Punto de apoyo documentado |
|---|---|---:|---|
| R1250RT 01.2019, 2.ª | 2019, Keyless principal/emergencia | 65–66 | Llave de respaldo en hueco centrado sobre el cuadro; mando sin pila detrás del cuadro, a la altura de testigos, con acceso a cubierta/altavoz según equipamiento. |
| R1250RT 08.2019, 3.ª | 2020, Keyless principal/emergencia | 68–69 | Misma distinción de punto para llave de respaldo y mando sin pila, documentada en la edición propia. |
| R1250RT 07.2020, 1.ª | 2021, Keyless principal/emergencia | 72–73 | Llave de respaldo o mando sin pila a la izquierda del centro y justo debajo de la pantalla TFT. |
| R1250RT 06.2021, 2.ª | 2022, Keyless principal/emergencia | 76–77 | Punto a la izquierda del centro y debajo de TFT, documentado en la edición propia. |

Es el **punto de apoyo para lectura de respaldo**. No identifica el emplazamiento interno de la antena, pieza, PN, frecuencia RF, chip o módulo instalado. No se traslada el procedimiento entre cuadro anterior y TFT, entre llave mecánica y Keyless ni entre modelos por semejanza. La opción y aplicabilidad de unidad siguen condicionadas.

La información de posición ya constaba en la afirmación de sistema y sus observaciones de esas mismas fichas; faltaba reflejarla en el campo de lectura. Se reutilizan las ocho observaciones consultadas y se cotejan de nuevo sus páginas y huellas. No se añaden fuentes históricas posteriores como sustituto del manual propio.

## Integridad y magnitud del cambio

`antennaReferenceUpdate5` conserva los ocho objetos de afirmación previos. La prueba reconstruye la huella exacta de las 3760 afirmaciones de la entrega pública REF3.2 al restituir esos ocho objetos: las otras 3752 afirmaciones no cambian. Las 1000 afirmaciones de chip/módulo mantienen el estado de REF3.2; las hipótesis Keyless S1000RR permanecen excluidas.

El estado documental pasa a 1616 referencias limitadas y 2144 pendientes de un total de 3760: **43,0 % con respaldo limitado**, no porcentaje global de terminación ni certificación por VIN. Antena/lectura tiene 399 referencias limitadas de 500; persisten 101 pendientes. Sistema se mantiene en 448 de 500, con 52 pendientes.

Las discrepancias C400GT, ausencia de identificación de inmovilizador en monocilíndricas, plataformas conflictivas, transiciones y referencias sin consultar no se resuelven por encontrar una llave o un capítulo de contacto. Esos límites permanecen en `REVISION_SISTEMA_ANTENA.json`.

## Evidencia y validación

`VERIFICACION_LECTURA_RT.json` conserva las cuatro fuentes, ocho páginas y huellas cotejadas. No se redistribuyen los PDF originales. Los resúmenes, CSV y pendientes se actualizan con los generadores existentes.

Las pruebas distinguen puntos anteriores/TFT, verifican la asignación exacta por identidad y conservan la diferencia de pila CR1632/CR2032, la restricción de programación y la no asignación de referencias mecánicas a Keyless. La entrega extraída comprueba también el campo de lectura de la muestra RT 2021. Resultados en `VALIDACION_REF3_3.json` y `VALIDACION_ENTREGA_REF3_3.json`.
