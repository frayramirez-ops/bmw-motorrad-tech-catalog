> REF3.3 añade ocho referencias de punto de lectura de respaldo RT 2019–2022, diferenciando cuadro anterior y TFT. La revisión de 161 afirmaciones conserva 153 pendientes; no identifica la pieza interna de antena. Véase `ACTUALIZACION_LECTURA_RT_REF3_3.md`.

# Estado actual — punto de entrada

Revisión transversal de apéndices: se cribaron las 500 identidades de transponder. Cinco ediciones propias de R1250RT 2020–2024 aportan diez referencias limitadas de chip/módulo para la selección Mecánica. Las páginas citan TMS37145/DST80 y EWS4/BECOM, distinguiendo TMS3705 como estación base; no se asignan a Keyless ni a unidades sin identificar. Véase `ACTUALIZACION_EWS_RT_REF3_2.md`.

**Versión vigente: B8-REF3.3 — referencias EWS mecánico, guía de interfaces y perfiles de diagnóstico.** Se cruzan 159 perfiles publicados por HEX con 789 fichas B8 (680 selecciones visibles) por modelo, plataforma y periodo. La matriz conjunta tiene información documental para 799 entradas, de las que 689 son seleccionables; 16 entradas siguen sin referencias suficientes. Se distinguen perfiles de motor/acceso/bus y software, no identificación de hardware instalado. Se corrige el formato legado de tres pines de R1100R/RS/RT 2001 sin alterar su identidad histórica C10. Estado de afirmaciones: 3760, con 1616 referencias limitadas y 2144 pendientes. Véase `ACTUALIZACION_DIAGNOSTICA_REF3.md` y `VALIDACION_BLOQUE_3.json`.

REF3.1 incorpora una guía de conexión HEX basada en dos páginas consultadas, con 20 combinaciones puerto/herramienta y sin asignaciones automáticas por modelo/año. La preparación de componentes queda en 192 lotes de investigación; no añade identificaciones de hardware. Véase `GUIA_INTERFACES_REF3_1.md`.

La matriz `FICHAS_REFERENCIA_B8.csv` muestra los campos reales de cada ficha. El generador evita asignar batería Keyless a llave mecánica y no libera componentes pendientes. Se mantiene la diferencia CR1632/CR2032 de R1250RT según edición. La programación continúa restringida.


Los apartados siguientes conservan el recorrido histórico de la recuperación; la versión vigente se identifica en la cabecera y en VERSION.json. `F800_CIERRE_CONCILIACION.md` conserva el historial y contiene cifras anteriores que sus secciones posteriores sustituyen.

## Antecedentes: trabajo comprobado

- Recuperación B8: 89 recursos originales restaurados, registro de hashes y datos fuente preservados.
- Reparaciones funcionales: búsqueda, comparador, declaración de sistema y alcance de funciones compartidas.
- Auditoría histórica: eliminados los vínculos por posición; 500 reglas pendientes de asociación documental. No se liberó programación.
- F800GS: 46 fichas conciliadas, 43 seleccionables y dos candidatas 2027 separadas.
- Evidencia F800GS: 98/210 afirmaciones con respaldo limitado (46,7 %); 112/210 pendientes de evidencia aplicable. No es un porcentaje global del proyecto ni de certificación por VIN.
- Fuentes F800GS: 16 consultadas, seis citas sin verificar; 30 observaciones con páginas/secciones y hashes.
- Última regresión ejecutada: 52 pruebas, 51 pasan y una omitida porque Chromium administrado bloquea file://. Se validan las 701 selecciones, los catorce bloques documentales, el iniciador HTTP y la integridad del ZIP. La cobertura y la consulta de pendientes validan procedencia, filtros y CSV; quedan 2454 afirmaciones abiertas. Véase `VALIDACION_RC16.json`.

## Pendientes y vías de resolución

| Tema | Afirmaciones pendientes | Evidencia necesaria |
|---|---:|---|
| Mercado/equipamiento | 46 | Mercado, fecha y opciones de fábrica de una unidad identificada o documento OEM específico |
| Chip | 23 | Lectura/identificación y referencia aplicable; un manual de EWS no identifica automáticamente el semiconductor |
| Módulo | 23 | Pieza instalada, fabricante y número de parte con aplicabilidad contrastada |
| Conector | 20 | Foto/inspección de contactos o documento específico; mantener CT mientras no se resuelva |

La inspección de las figuras OEM de PDF 136 de la edición estándar 04.2016 y PDF 195 de la edición moderna 03.2024 no permitió acreditar el número de contactos. El indicador no aumenta por haber abierto una figura. Se documenta el resultado en `f800-inspeccion-figuras.json`.

Los 112 pendientes se agrupan en **20 contextos de catálogo**: 11 GS 798 cc, seis Adventure y tres GS 895 cc. No son 20 unidades verificadas. La agrupación evita repetir solicitudes de equipamiento para el mismo contexto; no fusiona chips, sistemas ni afirmaciones y no autoriza extrapolar de un VIN a todo un año.

## Cómo aportar evidencia

`F800_CAPTURA_POR_CONTEXTO.csv` ofrece una fila por contexto con campos vacíos para completar. `f800-contextos-revision.json` conserva los vínculos exactos a las 112 afirmaciones. `F800_PENDIENTES_RESOLUCION.csv` mantiene el detalle individual.

Para una unidad o un documento disponible:

1. Identificar modelo/generación, año-modelo, mercado y referencia de la unidad o edición documental. No elegir la generación solo por el nombre F800GS.
2. Aportar la página/documento que delimita opciones de fábrica y fecha; identificar qué alternativa equipa realmente la unidad.
3. Para el conector: documentar ubicación y cara de contactos de forma legible, con la identificación de la unidad. No inferir el formato de los iconos de equipos compatibles.
4. Para módulo/llave: conservar la referencia de pieza y el resultado de identificación o lectura con su procedencia. No registrar una compatibilidad solo por aspecto visual.
5. Asociar cada evidencia a una afirmación, conservar su hash, alcance y resultado de revisión. Una evidencia aportada permanece por revisar antes de cambiar estado.

No introducir valores supuestos para rellenar los campos. Un contexto sin unidad o documento permanece pendiente. El documento maestro de fuentes F y las versiones históricas ausentes siguen sin recuperarse.

## Límites de esta entrega

No se publicaron ni desplegaron cambios. La aplicación es estática; no hay sincronización de evidencias ni certificación automática. Los recorridos básicos de copia, favoritos, notas e impresión están probados; véase `VALIDACION_USO_DIARIO.md`. Pendientes generales: revisión visual completa de impresiones, cobertura adicional de navegadores y almacenamiento, revisión visual/licencias de recursos, galería original ausente (se reconstruyó una biblioteca visual), padrón por mercado y expansión documental al resto de familias.

## Siguiente bloque iniciado: S1000RR

Conciliación de 42 fichas, con 12 manuales oficiales consultados y 23 observaciones. De 193 afirmaciones, 56 tienen respaldo limitado (29,0 %) y 137 permanecen pendientes. La ficha 2014 conserva un conflicto de edición posterior; no se extrapola homologación a K46 2013–2018. Ocho filas Keyless de B8 se identifican como hipótesis no acreditadas, en contraste con el historial del ZIP; no se eliminaron datos. Véase `S1000RR_CONCILIACION.md`. Estas cifras no cambian el porcentaje F800GS ni establecen un porcentaje global.

## Funciones de uso diario

Corregidos el resumen copiado de fichas restringidas, la espera de imágenes al imprimir, el identificador duplicado de favoritos y la carga de notas dañadas. Se conserva exportación de notas en sesión cuando falla el almacenamiento. Se probaron respaldo/restauración, deduplicación, importación inválida y límite acumulado de 10000 notas. Estas mejoras no cambian los porcentajes de evidencia documental ni liberan datos técnicos.

## Biblioteca visual reconstruida

Se reparó el destino de los enlaces de B8 con una biblioteca nueva de 24 recursos (16 fotografías y ocho recortes). Tiene búsqueda, filtros, ampliación y contexto por modelo. No representa la galería original ni una validación OEM o de permisos. La apertura por HTTP local está comprobada; file:// no pudo validarse por política del navegador. Véase `BIBLIOTECA_VISUAL.md`. Los porcentajes documentales no cambian.

## Cobertura global de las fichas existentes

La nueva vista `ESTADO_CATALOGO.html` y el CSV `PADRON_CATALOGO_B8.csv` describen las 815 fichas B8: 631 con conciliación detallada y 184 sin ese desglose. En los bloques conciliados hay 2912 afirmaciones inventariadas: 1015 con respaldo limitado y 1897 pendientes. Las 184 fichas sin revisión detallada tienen conteos de afirmaciones desconocidos (null/blanco), nunca cero pendientes. No es el padrón mundial BMW ni un porcentaje de finalización. Véase `COBERTURA_CATALOGO.md`.

## Familia R: R1250GS / Adventure

Primer bloque de 44 fichas conciliadas con ocho manuales propios de GS/Adventure y 30 observaciones. De 209 afirmaciones, 91 tienen respaldo limitado y 118 siguen pendientes. Las variantes mecánicas y Keyless no se certifican por VIN ni por mercado; la emergencia Keyless se documenta en cubierta de rueda trasera según edición. Las 33 consultas seleccionables se prueban y ninguna libera referencias de programación. Véase `R1250GS_CONCILIACION.md`.

## Entrega candidata B8-RC1

Se consolidó una candidata funcional con iniciador local Python estándar, envoltorios Windows/macOS-Linux, guía `LEEME_PRIMERO.md`, originales B8 completos e inventario de integridad. Se probaron las 701 combinaciones seleccionables del catálogo y el reinicio, además de integridad y detección de alteraciones del ZIP. Las 114 entradas de emergencia Keyless se conservan fuera de los selectores independientes. La matriz `ACEPTACION_RC1.md` no da por cumplida la certificación técnica ni el padrón por mercado: esas limitaciones continúan abiertas.

## Ampliación documental B8-RC2: R1200GS / Adventure

74 fichas adicionales con 23 manuales oficiales y 37 observaciones. Sus 340 afirmaciones se dividen en 88 con respaldo limitado y 252 pendientes. Se conservan las plataformas separadas en GS 2013 y Adventure 2014. Tres fichas que citan una edición posterior al año consultado mantienen todas sus afirmaciones pendientes. No se compararon resultados del ZIP en este nuevo bloque; no se interpreta que sus listas vacías demuestren ausencia histórica. Véase `R1200GS_CONCILIACION.md`.

Cobertura vigente: **206 de 815 fichas con revisión detallada (25,3 % de cobertura documental)**, 609 sin ese desglose. Los cuatro bloques reúnen 952 afirmaciones: 333 con respaldo limitado y 619 pendientes. Las fichas revisadas se distribuyen en 163 con algún respaldo limitado, 35 sin afirmaciones suficientemente respaldadas y ocho hipótesis no acreditadas. No es porcentaje de finalización ni certificación.

`VERSION.json` identifica ahora RC2; la matriz vigente es `ACEPTACION_RC2.md`. RC1 y su validación quedan como antecedentes. El usuario informó que no pudo descargar el ZIP: su integridad local no demuestra entrega. No se dispone de una vía comprobada para adjuntarlo desde este entorno; no se publicó ni desplegó como alternativa.

## Ampliación documental B8-RC3: R1250RT / R1300GS y Adventure

45 fichas adicionales, 208 afirmaciones: 61 con respaldo limitado y 147 pendientes. Doce PDF oficiales consultados, un índice oficial y una cita histórica sin verificar; 41 observaciones con páginas/hashes. La edición RT US 2023 citada históricamente para 2021/2022 se distingue de las fuentes primarias anteriores recuperadas. El índice identifica subgeneraciones RT que B8 agrupa; no se determina VIN por analogía. Lector R1300 bajo asiento del conductor separado de procedimientos RT junto al cuadro. Véase `R1250RT_R1300GS_CONCILIACION.md`.

Cobertura vigente: **251/815 fichas con conciliación detallada (30,8 % de cobertura documental)** y 564 sin desglose. En cinco bloques: 1160 afirmaciones, 394 respaldadas de forma limitada y 766 pendientes. Se distinguen 208 fichas con algún respaldo limitado, 35 revisadas sin respaldo suficiente y ocho hipótesis no acreditadas. No es porcentaje de finalización.

La candidata vigente es RC3 (`VERSION.json`, `ACEPTACION_RC3.md`). Las RC1/RC2 y sus validaciones quedan como antecedentes. Se conserva el bloqueo de programación; no se publica ni despliega. La entrega descargable por el chat sigue pendiente de una vía comprobada.

## Ampliación documental B8-RC4: R nineT y variantes

70 fichas adicionales: 35 transponders y 35 diagnóstico, todas seleccionables. Hay 315 afirmaciones, con 136 respaldadas de forma limitada (99 de edición, 34 de homologación, tres de especialista) y 179 pendientes. Se consultaron 34 PDF oficiales, índice BMW y fila HEX; tres citas históricas continúan sin verificar. El registro conserva 100 observaciones. Véase `NINET_CONCILIACION.md`.

Se separan manuales por variante. El archivo 0319 de Pure en realidad tiene portada /5 y no se usa para Pure 2020. La plataforma K21 heredada de /5 discrepa de la entrada BMW Pure/K22: las dos filas /5 conservan todas sus afirmaciones pendientes. Los apéndices EWS4 respaldan homologación sin certificar chip/módulo por unidad; certificados Keyless no se convierten en equipamiento instalado.

Cobertura vigente: **321/815 fichas con revisión detallada (39,4 % de cobertura documental)** y 494 sin desglose. En seis bloques: 1475 afirmaciones, 530 con respaldo limitado y 945 pendientes. Hay 276 fichas con algún respaldo limitado, 37 revisadas sin respaldo suficiente y ocho hipótesis no acreditadas. No es porcentaje de finalización.

La candidata vigente es RC4 (`VERSION.json`, `ACEPTACION_RC4.md`); los apartados RC1–RC3 se conservan como antecedentes históricos. Continúa la restricción de programación. No se publica ni despliega y la entrega descargable por el chat sigue sin vía comprobada.

## Ampliación documental B8-RC5: últimas fichas R

46 fichas adicionales, con 207 afirmaciones: 36 con respaldo limitado (24 de edición, 12 de especialista) y 171 pendientes. Quince manuales oficiales, índice BMW, guía HEX y dos páginas BMW México consultados; seis citas históricas sin verificar. Hay 46 observaciones. Véase `R_FINAL_CONCILIACION.md`.

Los 15 transponders antiguos siguen con todas sus afirmaciones pendientes: una llave mecánica no acredita ausencia ni presencia de inmovilizador. Se conserva conflicto entre fecha impresa y año consultado en GS 2001, R1150R 2002 y R1150RT 2002. Los modelos recientes tienen documentos propios; Keyless/equipamiento de una unidad, chip, módulo y conector no se resuelven por analogía. El panel distingue nombre/edición y cita histórica.

Cobertura vigente: **367/815 fichas con desglose (45,0 % de cobertura documental)**, 448 sin él. Las 279 fichas R tienen registro de revisión, sin certificar la familia. En siete bloques: 1682 afirmaciones, 566 con respaldo limitado y 1116 pendientes. Hay 304 fichas con algún respaldo limitado, 55 revisadas sin respaldo suficiente y ocho hipótesis no acreditadas. No es porcentaje de finalización.

La candidata vigente es RC5 (`VERSION.json`, `ACEPTACION_RC5.md`); RC1–RC4 conservan antecedentes. Continúan restricciones técnicas y pendientes de evidencia individual. No se publica ni despliega; la descarga del paquete por este chat sigue sin vía comprobada.

## Ampliación documental B8-RC6: F750GS / F850GS / Adventure

68 fichas adicionales, 323 afirmaciones: 149 con respaldo limitado (119 de edición y 30 de homologación) y 174 pendientes. Once PDF oficiales e índice BMW consultados, con 57 observaciones. Se separan modelos, alternativas Mecánica/Keyless y sus lectores; no se transfieren certificados a chips Keyless. Las 51 consultas seleccionables se prueban; 17 emergencias quedan en el registro histórico. Véase `F750_F850_CONCILIACION.md`.

Cobertura vigente: **435/815 fichas con desglose (53,4 % de cobertura documental)**, 380 sin él. En ocho bloques: 2005 afirmaciones, 715 con respaldo limitado y 1290 pendientes. Hay 372 fichas con algún respaldo limitado, 55 revisadas sin respaldo suficiente y ocho hipótesis no acreditadas. F tiene 114/182 fichas revisadas; R conserva 279/279, sin certificación técnica. No es porcentaje de finalización.

La candidata vigente es RC6 (`VERSION.json`, `ACEPTACION_RC6.md`); las anteriores conservan antecedentes. Continúan restricciones técnicas, pendientes individuales de F800GS y falta de evidencia por unidad. No se publica ni despliega. La descarga por este chat sigue sin vía comprobada.

## Ampliación documental B8-RC7: F650 / F700

40 fichas adicionales: 180 afirmaciones, 42 con respaldo limitado (24 de edición y 18 de especialista) y 138 pendientes. Once PDF oficiales, índice y guía HEX consultados; tres citas históricas sin verificar. Hay 35 observaciones. Se separan R13 monocilíndrica, K72 bicilíndrica de 798 cc y generaciones F700. Véase `F650_F700_CONCILIACION.md`.

Las nueve filas monocilíndricas de transponder conservan todas sus afirmaciones pendientes. Ningún chip/módulo de este bloque se identifica mediante EWS genérico. Se conservan dos CT y ocho conflictos cronológicos de manual posterior al año consultado; portada/colofón 2009 se comprobaron visualmente por extracción dañada. Las 40 consultas se prueban sin liberar programación.

Cobertura vigente: **475/815 fichas con desglose (58,3 % de cobertura documental)** y 340 sin él. En nueve bloques: 2185 afirmaciones, 757 con respaldo limitado y 1428 pendientes. Hay 403 fichas con algún respaldo limitado, 64 revisadas sin respaldo suficiente y ocho hipótesis no acreditadas. F tiene 154/182 fichas revisadas; R mantiene 279/279 sin certificación técnica. No es porcentaje de finalización.

La candidata vigente es RC7 (`VERSION.json`, `ACEPTACION_RC7.md`); las anteriores conservan antecedentes. Siguen pendientes individuales F800GS, identificación por unidad, diccionario F y revisiones perdidas. No se publica ni despliega. La descarga del paquete por este chat sigue sin vía comprobada.

## Ampliación documental B8-RC8: últimas fichas F

28 fichas adicionales, 132 afirmaciones: 57 con respaldo limitado (44 de edición, 12 de homologación y una opción documentada) y 75 pendientes. Se consultaron nueve PDF oficiales, índice y listado BMW México; un portal comercial queda sin verificar. Son 46 observaciones. Véase `F_FINAL_CONCILIACION.md`.

F450GS ya tiene referencias OEM propias KD1, sin resolver inmovilizador por llave mecánica ni reemplazar la plataforma pendiente de unidad. Su acceso diagnóstico usa asiento trasero/pasajero. F900R documenta Mecánica y Keyless OE pero no se selecciona variante; GS/Adventure mantienen chip/módulo Keyless pendientes. Las 22 consultas seleccionables se prueban sin liberar programación.

Cobertura vigente: **503/815 fichas con desglose (61,7 % de cobertura documental)**, 312 sin él. En diez bloques: 2317 afirmaciones, 814 con respaldo limitado y 1503 pendientes. Hay 430 fichas con algún respaldo limitado, 65 revisadas sin respaldo suficiente y ocho hipótesis no acreditadas. F mantiene 182/182 con revisión y R 279/279, sin certificación técnica. No es porcentaje de finalización.

La candidata vigente es RC8 (`VERSION.json`, `ACEPTACION_RC8.md`); las anteriores conservan antecedentes. Quedan pendientes individuales de familias revisadas, fuentes F, revisiones perdidas y verificaciones por unidad. No se publica ni despliega. La descarga por este chat sigue sin vía comprobada.

## Ampliación documental B8-RC9: familia K

128 fichas adicionales: 595 afirmaciones, 201 con respaldo limitado (166 de edición, ocho de homologación y 27 de especialista) y 394 pendientes. Se consultaron 32 PDF, índice y guía HEX; cuatro citas históricas siguen sin verificar. Hay 100 observaciones y 45 pasajes EWS/respaldo comprobados por contenido. Véase `K_CONCILIACION.md`.

Se separan K41/K44, GT/GTL/Exclusive/B, periodos de especialista y cuatro CT. Ocho filas tienen conflicto cronológico de edición posterior; dos accesos GTL 2015/2016 no se resuelven usando Exclusive. Keyless no identifica su semiconductor/módulo y las ubicaciones de lector se conservan por edición. Las 104 consultas seleccionables se prueban, sin liberar programación.

Cobertura vigente: **631/815 fichas con desglose (77,4 % de cobertura documental)**, 184 sin él. En once bloques: 2912 afirmaciones, 1015 con respaldo limitado y 1897 pendientes. Hay 548 fichas con algún respaldo limitado, 75 revisadas sin respaldo suficiente y ocho hipótesis no acreditadas. F (182), R (279) y K (128) tienen todas sus filas revisadas, sin certificación técnica. No es porcentaje de finalización.

La candidata vigente es RC9 (`VERSION.json`, `ACEPTACION_RC9.md`); las anteriores conservan antecedentes. Quedan C (87), S (73), G (18) y M (seis) sin desglose, además de pendientes individuales y criterios técnicos de salida. No se publica ni despliega. La descarga por este chat sigue sin vía comprobada.

## Ampliación documental B8-RC10: familia C

87 fichas adicionales (52 transponders, 35 diagnóstico), 400 afirmaciones: 105 con respaldo limitado (97 de edición y ocho de especialista) y 295 pendientes. Se consultaron 26 PDF oficiales, índice BMW y guía HEX; 71 observaciones con páginas/secciones y hashes. Véase `C_CONCILIACION.md`.

Se separan C600 Sport, C650 Sport/GT y C400X/GT. Los resultados mecánicos conservan 13 conflictos de chip y cinco valores condicionados; EWS genérico no los resuelve. Cinco ediciones C400GT mencionan cubierta de batería y cubierta de rueda trasera para el lector: 16 afirmaciones de antena siguen pendientes. Se preservan diez C16C. Las 70 selecciones se comprueban sin liberar programación; 17 emergencias permanecen históricas.

Cobertura vigente: **718/815 fichas con desglose (88,1 % de cobertura documental)**, 97 sin él. En doce bloques: 3312 afirmaciones, 1120 con respaldo limitado y 2192 pendientes. Hay 635 fichas con algún respaldo limitado, 75 revisadas sin respaldo suficiente y ocho hipótesis no acreditadas. F (182), R (279), K (128) y C (87) tienen registro para todas sus filas, sin certificación técnica. No es porcentaje global de finalización.

La candidata vigente es RC10 (`VERSION.json`, `ACEPTACION_RC10.md`). Restan S (73), G (18) y M (seis) sin desglose. Siguen pendientes la evidencia individual, fuentes perdidas y demás criterios técnicos de salida. No se publica ni despliega. La descarga por este chat sigue sin vía comprobada.

## Ampliación documental B8-RC11: S1000R / S1000XR

73 fichas adicionales (48 transponders, 25 diagnóstico), 340 afirmaciones: 133 con respaldo limitado (108 de edición, 20 de homologación y cinco de especialista) y 207 pendientes. Se consultaron 19 PDF oficiales, índice BMW y guía HEX; 66 observaciones con páginas/secciones y hashes. Véase `S_FINAL_CONCILIACION.md`.

Se separan modelos, plataformas y Mecánica/Keyless. El lector de respaldo se describe detrás del asiento del conductor en R y junto al depósito en XR. Ocho antenas mecánicas conservan ubicación pendiente porque su pasaje EWS no la precisa; no se aplica otra edición. Se preservan cuatro CT y 52 afirmaciones pendientes de chip/módulo Keyless. Las 60 selecciones se prueban sin liberar programación; 13 emergencias permanecen históricas.

Cobertura vigente: **791/815 fichas con desglose (97,1 % de cobertura documental)**, 24 sin él. En trece bloques: 3652 afirmaciones, 1253 con respaldo limitado y 2399 pendientes. Hay 708 fichas con algún respaldo limitado, 75 revisadas sin respaldo suficiente y ocho hipótesis no acreditadas. F (182), R (279), K (128), C (87) y S (115) tienen registro para todas sus filas, sin certificación técnica. No es porcentaje global de finalización.

La candidata vigente es RC11 (`VERSION.json`, `ACEPTACION_RC11.md`). Restan G (18) y M (seis) sin desglose. La evidencia individual, las fuentes perdidas y demás criterios técnicos de salida siguen pendientes. No se publica ni despliega. La descarga por este chat sigue sin vía comprobada.

## Cierre del inventario documental B8-RC12: G / M

24 fichas adicionales (12 transponders, 12 diagnóstico), 108 afirmaciones: 12 con respaldo limitado (cuatro de edición y ocho de especialista) y 96 pendientes. Se consultaron 12 PDF oficiales y tres fuentes web conservadas (índice BMW, HEX y listado BMW México); 37 observaciones. Portada y colofón del G650GS 08.2008 se verificaron visualmente por extracción dañada. Véase `GM_CONCILIACION.md`.

Los 12 transponders mantienen todas sus afirmaciones pendientes: llave mecánica no demuestra presencia/ausencia de inmovilizador; las fichas 2026 no tienen sistema/plataforma identificados. Los ocho registros 2026 conservan POR VERIFICAR/CONFIRMAR SISTEMA. Se registra desfase entre periodo 11/2010 y edición 11.2011 en cuatro fichas G650GS. Se separan manuales propios de M1000R/RR/XR y cortes de periodo 2026, sin aplicar su homologación al mando Keyless. Las 24 selecciones se comprueban sin liberar programación.

Cobertura vigente: **815/815 fichas con desglose (100 % del inventario documental B8 recibido)**, ninguna sin él. En catorce bloques: 3760 afirmaciones, 1265 con respaldo limitado y 2495 pendientes. Hay 720 fichas con algún respaldo limitado, 87 revisadas sin respaldo suficiente y ocho hipótesis no acreditadas. Todas las familias tienen registro, sin certificación técnica. No es porcentaje global de finalización.

`PENDIENTES_TECNICOS_B8.csv` reúne las 2495 afirmaciones abiertas con acción y registro de origen. La candidata vigente es RC12 (`VERSION.json`, `ACEPTACION_RC12.md`). El próximo trabajo es resolver evidencia y criterios de salida, según `CIERRE_INVENTARIO_DOCUMENTAL.md` y `PLAN_CONTINUIDAD_RC12.md`. No se publica ni despliega. La descarga por este chat sigue sin vía comprobada.

## Seguimiento B8-RC13: consulta de pendientes y contraste C400GT

Nueva vista de 2495 afirmaciones pendientes, enlazada desde cobertura y por identidad exacta de ficha. Permite combinar modelo/plataforma, familia, tema y año, abrir fuentes/límites y exportar resultados o el CSV completo. Los datos se generan a partir de los mismos catorce registros; no se editan estados en la interfaz. Véase `PENDIENTES_CONSULTA.md`.

El seguimiento C400GT añade diez manuales propios (cinco alemanes y cinco españoles) y 21 observaciones. Las ediciones españolas 09.2024 y 03.2025 son coherentes en tapa de batería; las anteriores y los textos alemán/inglés conservan contradicciones. Se revisaron figuras inglesas PDF 83/161/163 de 09.2024. Las 16 afirmaciones de antena continúan pendientes de aclaración aplicable; no se elige una traducción ni se certifica una unidad. Véase `C400GT_CONTRASTE_MULTILINGUE.md`.

Continúan **815/815 fichas con desglose**, 3760 afirmaciones, 1265 con respaldo limitado y 2495 pendientes. El 100 % es solo inventario documental, no finalización técnica. RC13 conserva restricciones y criterios de salida (`ACEPTACION_RC13.md`, `PLAN_CONTINUIDAD_RC13.md`). No se publicó ni desplegó; la descarga del ZIP por el chat sigue sin vía comprobada.

## Seguimiento B8-RC14: acceso diagnóstico

33 afirmaciones pasan de pendiente a referencia especialista limitada: 26 de R1200GS/Adventure y siete de S1000RR. Se consultó una instantánea nueva de HEX GS-911, preservando las antiguas. Cuatro observaciones separan GS/Adventure y aire/líquido; una corresponde a S1000RR. Los registros conservan las afirmaciones previas en `followUp.changes`. Véase `SEGUIMIENTO_ACCESOS_RC14.md`.

Los conflictos de edición y seis CT permanecen; la guía no valida contactos ni programación. Quedan seis accesos pendientes: /5 por discrepancia de plataforma, GTL 2015/2016 por periodo/variante y tres versiones especiales 2001 sin respaldo específico. La consulta de pendientes muestra el alcance de cada referencia.

Estado vigente: **815/815 fichas con desglose**, 3760 afirmaciones, 1298 con respaldo limitado y 2462 pendientes. Hay 753 fichas con alguna referencia limitada, 54 revisadas sin respaldo suficiente y ocho hipótesis no acreditadas. El 100 % sigue referido solo al inventario documental. RC14 mantiene los criterios de salida (`ACEPTACION_RC14.md`, `PLAN_CONTINUIDAD_RC14.md`). No se publicó ni desplegó; la descarga del ZIP por el chat sigue sin vía comprobada.

## Cierre de verificación funcional local B8-RC15

Se corrigió la impresión y se desactivó el resumen histórico duplicado que mostraba valores de transponder fuera del control actual de consulta. Los datos originales y los 14 registros documentales permanecen idénticos a sus fuentes, sin cambiar su historial. Se comprueba una entrega extraída fuera del checkout, con espacios/acentos y solicitudes remotas bloqueadas: 107 archivos HTTP por hash, 24 imágenes y 14 PDF de muestra.

El inventario sigue en 815/815 fichas, con 1298 afirmaciones de respaldo limitado y 2462 pendientes. El cierre funcional local no equivale a aceptación del proyecto completo. Los bloqueos de evidencia, licencias, plataformas y recepción están en `CIERRE_FUNCIONAL_Y_BLOQUEOS.md`. Resultados: `VALIDACION_RC15.json` y `VALIDACION_ENTREGA_LOCAL_RC15.json`. No se publicó ni desplegó; el canal de descarga desde el chat sigue sin vía comprobada.

La suite final RC15 ejecutó 50 pruebas: 49 correctas y una omitida por bloqueo administrado de file://. La validación de entrega comprobó 107 archivos locales, 24 imágenes y 14 PDF de muestra con solicitudes remotas bloqueadas. Se cierra esta verificación local, sin dar por cumplidos los bloqueos externos ni la aceptación técnica.

## Revisión documental B8-RC16: fecha de edición y periodo OEM

La nueva consulta del índice oficial confirma asignaciones de manual posterior a periodos anteriores: R1200GS K25 31 desde 01/2012, S1000RR K46 11 desde 08/2013 y K1200GT K44 desde 07/2007. Se contrastan pasajes EWS/antena con ediciones anteriores de la misma plataforma. Ocho afirmaciones de cuatro fichas mecánicas pasan a respaldo de edición, sin certificar unidad ni año completo. Los estados/hallazgos previos se conservan, junto al seguimiento de acceso RC14.

Estado vigente: **815/815 fichas con desglose**, 3760 afirmaciones, 1306 con respaldo limitado y 2454 pendientes. Hay 757 fichas con alguna referencia limitada, 50 sin respaldo suficiente y ocho hipótesis no acreditadas. Quedan 52 sistemas y 109 antenas pendientes; chip, módulo y mercado de las cuatro fichas revisadas no se acreditan. Véase `TEMPORALIDAD_MANUALES_RC16.md`, `ACEPTACION_RC16.md` y `VALIDACION_RC16.json`.

El cierre funcional RC15 y sus muestras impresas permanecen como evidencia de esa entrega. La revisión RC16 no equivale a cierre técnico ni elimina los bloqueos externos. No se publica ni despliega; no hay canal de adjuntar/exportar ZIP al usuario en esta sesión.

La suite RC16 ejecutó 52 pruebas: 51 correctas y una omitida. La entrega extraída conserva 107 archivos HTTP correctos, 24 imágenes y 14 PDF generados con solicitudes remotas bloqueadas; sus resultados están en `VALIDACION_ENTREGA_LOCAL_RC16.json`. Las muestras PDF incluidas en el paquete siguen siendo las de RC15, identificadas como tales.
