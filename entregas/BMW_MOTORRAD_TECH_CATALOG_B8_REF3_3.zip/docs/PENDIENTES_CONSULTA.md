# Consulta de pendientes técnicos — RC16

La aplicación incorpora `PENDIENTES_TECNICOS.html` para consultar las 2144 afirmaciones abiertas. Se accede desde cobertura o desde el enlace de pendientes de una ficha. La consulta por ficha usa su identidad exacta; una identidad inexistente muestra cero resultados, sin sustituirla por otra.

Puedes buscar por modelo/plataforma, combinar familia, tema y año, recorrer páginas de 25 afirmaciones y abrir evidencia/límites. Cada afirmación muestra qué falta para resolverla, observaciones con número de página/sección y fuentes consultadas o citas sin verificar. Cada enlace conserva además el alcance de su referencia: una fuente de acceso no se presenta como confirmación de contactos. Los códigos F y las hipótesis no acreditadas conservan su carácter histórico. Se incluyen filas de emergencia que no son un tercer sistema seleccionable del catálogo.

«Limpiar filtros» elimina también el contexto de ficha y vuelve al inventario completo. «Exportar resultados (CSV)» descarga todas las coincidencias, aunque se repartan en varias páginas; con cero resultados queda deshabilitado. «Descargar todos los pendientes (CSV)» sirve la copia completa, idéntica al CSV de documentación. Ninguna operación edita datos, cierra afirmaciones ni certifica resultados.

## Procedencia y actualización

El generador `scripts/build_coverage.py` usa los mismos catorce registros de revisión para cobertura, padrón y pendientes. Los datos de la nueva vista conservan identidad, registro de origen, acción, límite, observaciones y referencias de cada afirmación. Las fuentes se resuelven dentro de su propio registro para evitar mezclar instantáneas por una URL compartida.

Se genera HTML con JSON embebido y CSV completos en la aplicación. La consulta no necesita solicitudes remotas, paquetes de aplicación, cuentas ni almacenamiento de usuario. `pending.js` filtra/exporta en el navegador; `pending.css` adapta la presentación a móvil. Los PDF y páginas de fuente solo se abren cuando el usuario sigue sus enlaces.

```sh
python3 scripts/build_coverage.py
python3 scripts/build_coverage.py --check
```

El generador conserva el comportamiento de conteos desconocidos y detecta archivos derivados obsoletos. El HTML inserta datos como texto, con JSON escapado; los enlaces aceptan únicamente HTTPS. No se renderiza markup de las observaciones ni enlaces javascript.

## Validación

Dos pruebas en `test_pending.py` contrastan todas las afirmaciones con su registro y estado pendiente, CSV completo, fuentes y observaciones. Chromium comprueba navegación desde cobertura, contexto exacto/inexistente, paginación, filtros combinados y alias GSA, estado vacío, fuentes, exportación filtrada/completa, retorno, móvil de 375 px y rechazo de HTML/enlaces ejecutables en datos. La suite global mantiene las 701 selecciones y restricciones. Resultados: `VALIDACION_RC16.json`.

No se publicó ni desplegó esta vista. La verificación de descarga en HTTP local no demuestra que el usuario pueda descargar el ZIP desde el chat.
