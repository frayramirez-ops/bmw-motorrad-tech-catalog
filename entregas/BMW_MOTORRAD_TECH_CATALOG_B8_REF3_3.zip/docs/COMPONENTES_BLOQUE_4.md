# Bloque de componentes — preparación transversal

Estado: investigación preparada, pendiente de acceso a fuentes de componentes. La preparación original se realizó sobre B8-REF3.0; REF3.1 la incorpora junto con una guía de conexión HEX. Esta preparación no modifica la aplicación, sus datos técnicos, las reglas de programación ni los paquetes publicados.

## Cola reproducible

`component-review-batches.json` y `COMPONENTES_LOTES_REVISION.csv` reúnen las 1000 afirmaciones de chip/módulo de las 500 fichas de transponder. Son 862 afirmaciones pendientes de contraste y 138 con referencias limitadas de homologación. Estas últimas no se reclasifican como identificaciones de chip o pieza instalada.

Se organizan en 192 lotes de las siete familias. Cada lote mantiene el modelo, plataforma y sistema exactos de B8, años consecutivos y los mismos perfiles de diagnóstico disponibles. Los huecos temporales generan lotes distintos; llave principal, emergencia y mecánica permanecen separadas. Las ocho hipótesis no acreditadas se mantienen identificadas al final y no se utilizan para acreditar aplicabilidad.

El orden prioriza el número de afirmaciones pendientes que una investigación podría contrastar; no representa ventas ni popularidad. Entre los lotes amplios figuran F750GS/F850GS, F800GS 798 cc, G650GS, R1250RT y K1600GT/GTL. Se revisarán conjuntamente las fuentes que cubran varios lotes, pero cada afirmación conserva su aplicabilidad individual.

El texto B8 histórico se exporta como `texto_B8_NO_VALIDADO`, únicamente para localizar y contrastar la referencia original. Los perfiles HEX son pistas de investigación de diagnóstico: no demuestran equivalencia física de módulos, PN o transponder. Agrupar tampoco acredita que todos los años lleven la misma pieza.

## Evidencia que permite completar el bloque

Para una identificación documental de componente se necesita una fuente del fabricante o documentación técnica verificable que identifique el componente y delimite modelo/plataforma, periodo y sistema. Deben conservarse URL, versión, captura/huella, página o sección y alcance exacto. Una tabla de soporte de herramienta sin identificación de componente no cierra chip ni módulo. Los conflictos con B8 se registran; no se sobrescribe el resultado histórico.

La referencia de modelo puede documentarse sin una motocicleta disponible cuando existe evidencia suficiente. Confirmar la pieza instalada, su equipamiento o aplicación por VIN requiere evidencia de esa unidad y no se deduce del lote.

## Acceso pendiente

Los cuatro dominios `tmpro2.com`, `www.tmpro2.com`, `obdstar.com` y `www.obdstar.com` están guardados en el borrador junto con los tres dominios anteriores. En la comprobación del 7 de noviembre de 2026, la instancia seguía en revisión de configuración 3 y el borrador en revisión 4; los dominios nuevos aún no figuraban en la configuración activa. No se repitieron las peticiones que ya habían recibido un rechazo 403 de la política de red, porque no se observó un cambio aplicado.

La revisión y guardado se realizan en el editor del entorno. Después de aplicar la configuración se debe comprobar el estado y abrir una conexión nueva antes de afirmar que esas fuentes son accesibles. No requiere una contraseña ni un token compartidos en el chat. Publicar la configuración del entorno, cuando lo solicite el producto, no despliega el catálogo.

## Reproducción y comprobación

```sh
python3 scripts/build_component_batches.py
python3 scripts/build_component_batches.py --check
python3 -m unittest discover -s tests -p test_component_batches.py -v
```

El generador comprueba las huellas de los catorce registros contra la cobertura existente y falla si están desactualizadas. Las dos pruebas verifican conservación de todas las identidades/afirmaciones, estados, hallazgos, fuentes y observaciones, igualdad JSON/CSV, separación de plataformas/sistemas, continuidad temporal y exclusión de hipótesis.

No se ha obtenido nueva evidencia de componentes de los sitios bloqueados; por ello esta preparación no reduce el número de pendientes ni constituye otra entrega del catálogo.

## Revisión del 10 de noviembre de 2026

REF3.2 incorpora diez referencias limitadas de homologación EWS mecánico en cinco ediciones R1250RT, con sus estados anteriores conservados. La cola actualizada mantiene 192 lotes y 1000 afirmaciones: 852 pendientes y 148 referencias limitadas. Las cifras 862/138 anteriores describen la preparación original. Véase `ACTUALIZACION_EWS_RT_REF3_2.md`.
