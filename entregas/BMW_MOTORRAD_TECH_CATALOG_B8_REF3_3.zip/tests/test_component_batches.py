import csv
import io
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from build_component_batches import generated_files


class ComponentBatchTests(unittest.TestCase):
    def test_claims_retain_identity_status_and_evidence(self):
        outputs, summary = generated_files()
        data = json.loads(outputs[ROOT / 'docs/component-review-batches.json'])
        self.assertEqual(summary, {
            'records': 500, 'claims': 1000, 'batches': 192, 'pendingClaims': 852,
            'limitedReferenceClaims': 148, 'hypothesisRecordsExcluded': 8,
            'families': ['C', 'F', 'G', 'K', 'M', 'R', 'S'],
        })
        expected = {}
        coverage = json.loads((ROOT / 'docs/coverage-data.json').read_text())
        for filename in coverage['inputs']['reviewSha256']:
            review = json.loads((ROOT / 'docs' / filename).read_text())
            for row in review['records']:
                for claim in row['claims']:
                    if claim['topic'] in {'chip', 'modulo'}:
                        expected[row['recordId'], claim['topic']] = claim
        seen = set()
        for group in data['batches']:
            for row in group['records']:
                for claim in row['claims']:
                    key = row['recordId'], claim['topic']
                    self.assertNotIn(key, seen)
                    seen.add(key)
                    source = expected[key]
                    for name in ['status', 'finding', 'limitation', 'nextAction']:
                        self.assertEqual(claim[name], source.get(name, ''))
                    self.assertEqual(claim['observations'], source.get('observations', []))
                    self.assertEqual([s['id'] for s in claim['sources']], source.get('sourceIds', []))
        self.assertEqual(seen, set(expected))
        rows = list(csv.DictReader(io.StringIO(outputs[ROOT / 'docs/COMPONENTES_LOTES_REVISION.csv'].lstrip('\ufeff'))))
        self.assertEqual({(r['identidad'], r['afirmacion']) for r in rows}, seen)
        self.assertEqual(len(rows), 1000)

    def test_batches_preserve_platform_system_gaps_and_hypotheses(self):
        outputs, _ = generated_files()
        data = json.loads(outputs[ROOT / 'docs/component-review-batches.json'])
        profiles = {r['recordId']: r for r in json.loads((ROOT / 'docs/diagnostic-profile-bindings.json').read_text())['records']}
        ids = set()
        excluded = 0
        for group in data['batches']:
            self.assertNotIn(group['id'], ids)
            ids.add(group['id'])
            years = group['years']
            self.assertEqual(years, list(range(min(years), max(years) + 1)))
            for row in group['records']:
                for field in ['family', 'model', 'platform', 'system']:
                    self.assertEqual(row['identity'][field], group[field])
                self.assertEqual(profiles[row['recordId']]['profileIds'], group['diagnosticProfileLeads'])
                hypothesis = row['recordStatus'] == 'HIPOTESIS_NO_ACREDITADA'
                self.assertEqual(hypothesis, group['hypothesisExcludedFromApplicability'])
                if hypothesis:
                    excluded += 1
                    self.assertEqual(group['diagnosticProfileLeads'], [])
        self.assertEqual(excluded, 8)
        for path, content in outputs.items():
            self.assertEqual(path.read_bytes(), content.encode(), str(path))


if __name__ == '__main__':
    unittest.main()
