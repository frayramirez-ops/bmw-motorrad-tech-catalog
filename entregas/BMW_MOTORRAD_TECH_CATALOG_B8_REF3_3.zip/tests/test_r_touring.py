"""RT periods and GS/Adventure reader locations must not leak across identities."""
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

PENDING='PENDIENTE_CONTRASTE_DOCUMENTAL'

class RTouringTests(unittest.TestCase):
    def test_reader_points_delta_and_previous_full_claims_fingerprint(self):
        registry=json.loads((ROOT/'docs/r1250rt-r1300gs-reconciliation.json').read_text())
        update=registry['antennaReferenceUpdate5']
        rows={r['recordId']:r for r in registry['records']}
        expected={rid for rid,r in rows.items() if r['section']=='transponders' and r['identity']['model']=='R1250RT' and r['identity']['year'] in range(2019,2023) and r['identity']['system'] in ['Keyless (Principal)','Keyless (Emergencia)']}
        self.assertEqual(len(expected),8)
        self.assertEqual({(c['recordId'],c['topic']) for c in update['changes']},{(rid,'antena') for rid in expected})
        self.assertEqual(len(update['changes']),8)
        self.assertEqual(len(update['reusedObservationIds']),8)
        prior={(c['recordId'],c['topic']):c['previousClaim'] for c in update['changes']}
        for rid in expected:
            row=rows[rid];claims={c['topic']:c for c in row['claims']}
            self.assertEqual(prior[rid,'antena']['status'],PENDING)
            self.assertEqual(claims['antena']['status'],'DOCUMENTADO_EN_EDICION_APLICABILIDAD_PENDIENTE')
            self.assertEqual(claims['antena']['sourceIds'],[row['references'][0]['sourceId']])
            self.assertEqual(claims['antena']['observations'],claims['sistema']['observations'])
            self.assertIn('ubicación interna',claims['antena']['limitation'])
            if row['identity']['year']<2021:
                self.assertIn('detrás del cuadro',claims['antena']['finding'])
            else:
                self.assertIn('debajo de la pantalla TFT',claims['antena']['finding'])
        baseline=[]
        for path in (ROOT/'docs').glob('*-reconciliation.json'):
            review=json.loads(path.read_text())
            for row in review['records']:
                for claim in row['claims']:
                    baseline.append([row['recordId'],prior.get((row['recordId'],claim['topic']),claim)])
        raw=json.dumps(sorted(baseline,key=lambda x:(x[0],x[1]['topic'])),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
        self.assertEqual(len(baseline),3760)
        self.assertEqual(hashlib.sha256(raw).hexdigest(),'795ff229dacb51bf3f620f618a33e4b7ba5688e712b8631c84f1da147ebea767')
        scan=json.loads((ROOT/'docs/REVISION_SISTEMA_ANTENA.json').read_text())
        self.assertEqual(len(scan['checks']),161)
        self.assertEqual(scan['summary']['topics'],{'sistema':52,'antena':109})
        self.assertEqual(scan['summary']['pendingRetained'],153)
        self.assertEqual({(r['recordId'],r['topic']) for r in scan['checks'] if r['disposition']=='PUNTO_DE_LECTURA_DOCUMENTADO_EN_EDICION_PROPIA'},set(prior))

    def test_appendix_update_is_limited_to_five_mechanical_rt_editions(self):
        review=json.loads((ROOT/'docs/r1250rt-r1300gs-reconciliation.json').read_text())
        update=review['componentHomologationUpdate4']
        rows={r['recordId']:r for r in review['records']}
        expected={r['recordId'] for r in rows.values() if r['section']=='transponders' and r['identity']['model']=='R1250RT' and r['identity']['system']=='Mecánica' and r['identity']['year'] in range(2020,2025)}
        self.assertEqual(len(expected),5)
        self.assertEqual(len(update['changes']),10)
        self.assertEqual({(c['recordId'],c['topic']) for c in update['changes']},{(rid,topic) for rid in expected for topic in ['chip','modulo']})
        observations={o['id']:o for o in review['observations']}
        self.assertEqual(len(update['additionalObservationIds']),5)
        for change in update['changes']:
            self.assertEqual(change['previousClaim']['status'],PENDING)
            row=rows[change['recordId']]
            claim=next(c for c in row['claims'] if c['topic']==change['topic'])
            self.assertEqual(claim['status'],'HOMOLOGACION_DOCUMENTADA_UNIDAD_PENDIENTE')
            self.assertEqual(len(claim['observations']),1)
            observation=observations[claim['observations'][0]]
            self.assertIn(observation['id'],update['additionalObservationIds'])
            self.assertEqual(observation['sourceId'],row['references'][0]['sourceId'])
            self.assertIn('TMS37145',observation['normalizedExcerpt'])
            self.assertIn('TMS3705',observation['normalizedExcerpt'])
            self.assertIn('BECOM',observation['normalizedExcerpt'])
            self.assertEqual(row['referenceFacts']['reviewedOn'],'2026-11-10')
        scan=json.loads((ROOT/'docs/REVISION_APENDICES_COMPONENTES.json').read_text())
        self.assertEqual(len(scan['records']),500)
        self.assertEqual(len({r['recordId'] for r in scan['records']}),500)
        self.assertEqual(sum(scan['summary']['dispositions'].values()),500)
        self.assertEqual({r['recordId'] for r in scan['records'] if r['disposition']=='REFERENCIA_DE_HOMOLOGACION_REVISADA'},expected)

    def test_registry_provenance_and_limits(self):
        review=json.loads((ROOT/'docs/r1250rt-r1300gs-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="rTouringEvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual(len(review['records']),45);self.assertEqual(len(sources),14);self.assertEqual((len(observations)-len(review['bulkReferenceUpdate']['additionalObservationIds'])-len(review['componentHomologationUpdate4']['additionalObservationIds'])),41)
        self.assertEqual(sum(s['status']=='CITADA_SIN_VERIFICAR'for s in sources.values()),1)
        claims=0;documented=0
        for row in review['records']:
            identity=row['identity'];original=next(r for r in db[row['section']]if all(r[k]==v for k,v in identity.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            primary=sources[row['references'][0]['sourceId']]
            self.assertEqual(primary['model'],identity['model']);self.assertLessEqual(primary['editionYear'],identity['year'])
            self.assertEqual(row['zipComparisonStatus'],'NO_CONTRASTADO_EN_ESTE_BLOQUE')
            if identity['model']=='R1250RT':
                self.assertTrue(primary['discovery']['indexEntries'])
                self.assertTrue(all(e['file']==primary['discovery']['filename']for e in primary['discovery']['indexEntries']))
                if identity['year']in[2021,2022]:self.assertTrue(any('CONFLICTO_HISTORICO_CRONOLOGICO'in f for f in row['findings']))
                if row['section']=='diagnostico':self.assertTrue(any('SEMANTICA_HEREDADA'in f for f in row['findings']))
            for c in row['claims']:
                claims+=1
                corrected=(row['section']=='transponders' and identity['model']=='R1250RT' and identity['system']=='Mecánica' and identity['year'] in range(2020,2025) and c['topic'] in ['chip','modulo'])
                if corrected:
                    self.assertEqual(c['status'],'HOMOLOGACION_DOCUMENTADA_UNIDAD_PENDIENTE')
                elif c['topic']in['chip','modulo','conector','mercado_equipamiento']:
                    self.assertEqual(c['status'],PENDING)
                if identity['model']=='R1250RT'and c['topic']=='antena':
                    if identity['system']=='Mecánica'and identity['year']>2020:
                        self.assertEqual(c['status'],PENDING)
                if c['status']==PENDING:continue
                documented+=1;self.assertTrue(c['observations'])
                self.assertEqual(c['sourceIds'],[primary['id']])
                for oid in c['observations']:
                    o=observations[oid]
                    self.assertEqual(o['sourceId'],primary['id'])
                    self.assertEqual(o['documentSha256'],primary['retrieval']['sha256'])
                    if identity['model'].startswith('R1300')and c['topic']in['sistema','antena']:
                        self.assertIn('asiento del conductor',o['scope']);self.assertNotIn('rueda trasera',o['scope'])
        self.assertEqual(claims,208);self.assertEqual(documented,96)

    def test_browser_all_selections_and_context_switch(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/r1250rt-r1300gs-reconciliation.json').read_text())
                visible=[r for r in review['records']if r['identity']['system']!='Keyless (Emergencia)']
                self.assertEqual(len(visible),34)
                select='''row=>{
                    setTab(row.section,{reset:true});
                    for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                    const declaration=document.getElementById('bmwSystemDeclaration');
                    if(row.section==='transponders'&&!declaration.hidden){
                      const type=row.identity.system.includes('Keyless')?'Keyless':'Mecánica';
                      [...declaration.querySelectorAll('button')].find(b=>b.textContent===type).click();
                    }
                    $('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));
                }'''
                for row in visible:
                    with self.subTest(record=row['recordId']):
                        page.evaluate(select,row)
                        self.assertTrue(page.locator('#rTouringEvidence').is_visible())
                        self.assertEqual(page.locator('#rTouringEvidence').get_attribute('data-record-id'),row['recordId'])
                        for panel in ['f800Evidence','s1000rrEvidence','r1250Evidence','r1200Evidence']:
                            self.assertFalse(page.locator('#'+panel).is_visible())
                        text=page.locator('#rTouringEvidence').inner_text()
                        if row['identity']['model'].startswith('R1300'):
                            self.assertIn('asiento del conductor',text);self.assertNotIn('rueda trasera',text)
                        if row['section']=='transponders':
                            self.assertIn('Chip y programación no validados',page.locator('#status').inner_text());self.assertEqual(page.locator('#gallery img').count(),0)
                            chip=page.locator('#rTouringEvidence [data-reference-fields~="chip"]')
                            if row['identity']['model']=='R1250RT' and row['identity']['system']=='Mecánica' and row['identity']['year'] in range(2020,2025):
                                self.assertEqual(chip.count(),1)
                                self.assertIn('TMS37145',chip.inner_text())
                                self.assertIn('estación base, no como chip de la llave',chip.inner_text())
                                self.assertIn('BECOM',page.locator('#rTouringEvidence [data-reference-fields~="modulo"]').inner_text())
                            else:self.assertEqual(chip.count(),0)
                            if row['identity']['model']=='R1250RT' and row['identity']['system']=='Keyless (Principal)' and row['identity']['year'] in range(2019,2023):
                                reader=page.locator('#rTouringEvidence [data-reference-fields~="antena"]')
                                self.assertEqual(reader.count(),1)
                                self.assertIn('detrás del cuadro' if row['identity']['year']<2021 else 'debajo de la pantalla TFT',reader.inner_text())

                page.set_viewport_size({'width':375,'height':812})
                self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                old=json.loads((ROOT/'docs/r1200gs-reconciliation.json').read_text())['records'][0]
                page.evaluate(select,old)
                self.assertTrue(page.locator('#r1200Evidence').is_visible());self.assertFalse(page.locator('#rTouringEvidence').is_visible())
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
