"""K41/K44 and GT/GTL/Exclusive/B evidence must not be merged by family name."""
import csv
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

PENDING='PENDIENTE_CONTRASTE_DOCUMENTAL'

class KTests(unittest.TestCase):
    def test_models_periods_and_component_limits(self):
        review=json.loads((ROOT/'docs/k-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="kEvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual((len(review['records']),len(sources),len(observations)),(128,39,101))
        self.assertEqual(sum(s.get('retrieval',{}).get('type')=='.pdf'for s in sources.values()),32)
        pending=0;limited=0;homologation=0;specialist=0;conflicts=0;ct=0;keyless_pending=0
        for row in review['records']:
            ident=row['identity'];original=next(r for r in db[row['section']]if all(r[k]==v for k,v in ident.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            primary=sources[row['references'][0]['sourceId']];self.assertIn(ident['model'],primary['models'])
            self.assertTrue(primary['discovery']['indexEntries'])
            if ident['model']in['K1200GT (K41)','K1200GT (K44)','K1300GT']:
                self.assertTrue(any(e['model']['EW']==ident['platform']for e in primary['discovery']['indexEntries']))
            conflict=any('CONFLICTO_CRONOLOGICO'in f for f in row['findings'])
            if conflict:conflicts+=1
            if conflict and row['section']=='transponders':self.assertTrue(all(c['status']==PENDING for c in row['claims']if not(row.get('temporalEvidence')and c['topic']in['sistema','antena'])))
            if ident['system']=='Conector CT':ct+=1;self.assertTrue(any('TRANSICION_CT'in f for f in row['findings']))
            if row['section']=='diagnostico'and ident['model']=='K1600GTL'and ident['year']in[2015,2016]:
                self.assertTrue(any('ALCANCE_HEX_GTL'in f for f in row['findings']))
                self.assertEqual(next(c for c in row['claims']if c['topic']=='acceso')['status'],PENDING)
            for c in row['claims']:
                if c['topic']in['conector','ubicacion','mercado_equipamiento']:self.assertEqual(c['status'],PENDING)
                if 'Keyless'in ident['system']and c['topic']in['chip','modulo']:
                    keyless_pending+=1;self.assertEqual(c['status'],PENDING)
                if c['status']==PENDING:pending+=1
                else:
                    limited+=1;self.assertTrue(c['observations'])
                    if c['status']=='HOMOLOGACION_DOCUMENTADA_UNIDAD_PENDIENTE':
                        homologation+=1;self.assertEqual(ident['system'],'Mecánica');self.assertIn(ident['year'],[2020,2021])
                    if c['status']=='REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE':specialist+=1;self.assertEqual(c['topic'],'acceso')
                    elif row.get('temporalEvidence')and c['topic']in['sistema','antena']:self.assertIn(row['temporalEvidence']['indexSourceId'],c['sourceIds'])
                    else:self.assertEqual(c['sourceIds'],[primary['id']])
                for oid in c['observations']:
                    o=observations[oid];self.assertIn(o['sourceId'],c['sourceIds'])
                    self.assertEqual(o['documentSha256'],sources[o['sourceId']]['retrieval']['sha256'])
                    if 'Keyless'in ident['system']and c['topic']=='antena':
                        self.assertIn('-backup-',oid)
                        if ident['year']>=2022:self.assertIn('no fija una ubicación',o['scope'])
        self.assertEqual((pending,limited,homologation,specialist,conflicts,ct,keyless_pending),(390,205,8,27,8,4,96))
        self.assertEqual(observations['src-9a349fc351e8ee77-colophon-176']['pdfPage'],176)
        for name,count in [('K_AFIRMACIONES.csv',595),('K_PENDIENTES.csv',390)]:
            with(ROOT/'docs'/name).open(encoding='utf-8-sig',newline='')as f:self.assertEqual(len(list(csv.DictReader(f))),count)

    def test_browser_all_selectable_variants(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/k-reconciliation.json').read_text())
                rows=[r for r in review['records']if r['identity']['system']!='Keyless (Emergencia)'];self.assertEqual(len(rows),104)
                select='''row=>{
                    setTab(row.section,{reset:true});
                    for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                    const declaration=document.getElementById('bmwSystemDeclaration');
                    const name=/keyless/i.test(row.identity.system)?'Keyless':/mecánica|ews/i.test(row.identity.system)?'Mecánica':null;
                    if(row.section==='transponders'&&!declaration.hidden&&name){
                      const b=[...declaration.querySelectorAll('button')].find(b=>b.textContent===name);if(b)b.click();
                    }
                    $('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));
                }'''
                for row in rows:
                    with self.subTest(record=row['recordId']):
                        page.evaluate(select,row)
                        panel=page.locator('#kEvidence');self.assertTrue(panel.is_visible())
                        self.assertEqual(panel.get_attribute('data-record-id'),row['recordId'])
                        for other in ['f800Evidence','s1000rrEvidence','r1250Evidence','r1200Evidence','rTouringEvidence','ninetEvidence','rFinalEvidence','f750f850Evidence','f650f700Evidence','fFinalEvidence']:
                            self.assertFalse(page.locator('#'+other).is_visible())
                        if row['identity']['system']=='Conector CT':self.assertIn('TRANSICION_CT',panel.inner_text())
                        if row['section']=='transponders':
                            self.assertIn('No es posible',page.locator('#status').inner_text());self.assertEqual(page.locator('#gallery img').count(),0)
                page.set_viewport_size({'width':375,'height':812});self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                old=next(r for r in json.loads((ROOT/'docs/f-final-reconciliation.json').read_text())['records']if r['section']=='diagnostico')
                page.evaluate(select,old)
                self.assertTrue(page.locator('#fFinalEvidence').is_visible());self.assertFalse(page.locator('#kEvidence').is_visible())
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
