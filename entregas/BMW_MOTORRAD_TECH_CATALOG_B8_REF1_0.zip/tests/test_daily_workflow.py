"""Daily workflows in isolated browser contexts; no user storage is touched."""
import functools
import json
import re
import subprocess
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from playwright.sync_api import sync_playwright
from test_recovery import APP, QuietHandler

NOTES='duplikey_bmw_tech_v606_notas'

class DailyWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=cls.server.serve_forever,daemon=True).start()
        cls.playwright=sync_playwright().start()
        cls.browser=cls.playwright.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])

    @classmethod
    def tearDownClass(cls):
        cls.browser.close();cls.playwright.stop();cls.server.shutdown();cls.server.server_close()

    def setUp(self):
        self.context=self.browser.new_context()
        self.addCleanup(self.context.close)
        self.page=self.context.new_page();self.page.set_default_timeout(6000)
        self.errors=[];self.page.on('pageerror',lambda e:self.errors.append(str(e)))

    def open_catalog(self):
        self.page.goto(f'http://127.0.0.1:{self.server.server_port}/?qa=1',wait_until='networkidle')
        self.page.click('[data-tab="transponders"]')
        for id,value in [('year','2008'),('family','F'),('model','F800GS (798 cc)'),('platform','K72'),('system','Mecánica')]:
            self.page.select_option('#'+id,value)
        self.page.locator('#v606Text').evaluate("el=>{for(let p=el.parentElement;p;p=p.parentElement)if(p.tagName==='DETAILS')p.open=true}")

    def test_both_copy_buttons_respect_pending_audit(self):
        self.open_catalog()
        self.page.evaluate("()=>{window.copied=[];navigator.clipboard.writeText=async text=>{window.copied.push(text)}}")
        self.page.locator('#quickTools button').filter(has_text='Copiar resumen').click()
        self.page.locator('#bmwConsultToolbar button').filter(has_text='Copiar ficha técnica').click()
        self.page.wait_for_function('window.copied.length===2')
        for copied in self.page.evaluate('window.copied'):
            self.assertIn('INFORMACIÓN NO VERIFICADA',copied)
            self.assertNotIn('ID46 / PCF7936',copied)
            self.assertNotIn('Silca identifica',copied)
        self.assertEqual(self.errors,[])

    def test_favorite_survives_reload_and_restores_exact_selection(self):
        self.open_catalog();self.page.click('#favToggle')
        self.page.reload(wait_until='networkidle')
        self.page.locator('#favPanel > summary').click()
        self.page.locator('#favList button').click()
        self.assertEqual(self.page.locator('#model').input_value(),'F800GS (798 cc)')
        self.assertEqual(self.page.locator('#platform').input_value(),'K72')
        self.assertEqual(self.page.locator('#system').input_value(),'Mecánica')
        self.assertIn('No es posible',self.page.locator('#status').inner_text())
        self.assertEqual(self.page.locator('#gallery img').count(),0)
        self.page.click('#favToggle')
        self.assertEqual(self.page.locator('#favList button').count(),0)
        self.assertEqual(self.errors,[])

    def test_notes_roundtrip_duplicate_and_invalid_import(self):
        self.open_catalog()
        note='Observación de prueba: componente pendiente <script>no ejecutar</script>'
        self.page.fill('#v606Text',note);self.page.click('#v606Save')
        self.assertIn(note,self.page.locator('#v606NotesList').inner_text())
        with self.page.expect_download() as event:self.page.click('#v606Export')
        backup=json.loads(Path(event.value.path()).read_text())
        self.assertEqual(backup['schema'],'notes-v1');self.assertEqual(len(backup['notes']),1)
        self.page.reload(wait_until='networkidle')
        self.page.locator('#v606Text').evaluate("el=>{for(let p=el.parentElement;p;p=p.parentElement)if(p.tagName==='DETAILS')p.open=true}")
        self.assertIn(note,self.page.locator('#v606NotesList').inner_text())
        self.page.evaluate('localStorage.removeItem('+json.dumps(NOTES)+')')
        self.page.reload(wait_until='networkidle')
        self.page.locator('#v606Text').evaluate("el=>{for(let p=el.parentElement;p;p=p.parentElement)if(p.tagName==='DETAILS')p.open=true}")
        for _ in range(2):
            self.page.set_input_files('#v606Import',{'name':'notes.json','mimeType':'application/json','buffer':json.dumps(backup).encode()})
            self.page.wait_for_function("document.getElementById('v606Import').value===''")
        self.assertEqual(self.page.locator('#v606NotesList article').count(),1)
        self.page.set_input_files('#v606Import',{'name':'bad.json','mimeType':'application/json','buffer':b'{"schema":"notes-v1","notes":[null]}'})
        self.page.wait_for_function("document.getElementById('v606Status').textContent.includes('Formato de respaldo no válido')")
        self.assertIn('Formato de respaldo no válido',self.page.locator('#v606Status').inner_text())
        self.assertEqual(self.page.locator('#v606NotesList article').count(),1)
        large={'schema':'notes-v1','notes':[{'moto':'caso '+str(i),'kind':'prueba','state':'pendiente','text':'nota','at':'2026-11-04'} for i in range(10000)]}
        self.page.set_input_files('#v606Import',{'name':'large.json','mimeType':'application/json','buffer':json.dumps(large).encode()})
        self.page.wait_for_function("document.getElementById('v606Status').textContent.includes('supera el límite')")
        self.assertEqual(self.page.locator('#v606NotesList article').count(),1)
        self.assertEqual(self.errors,[])

    def test_corrupt_saved_notes_do_not_break_startup(self):
        self.context.add_init_script("localStorage.setItem('"+NOTES+"','[null,42]')")
        self.open_catalog()
        self.assertEqual(self.page.locator('#v606NotesList article').count(),0)
        self.page.fill('#v606Text','Nueva nota válida');self.page.click('#v606Save')
        self.assertEqual(self.page.locator('#v606NotesList article').count(),1)
        self.assertEqual(self.errors,[])

    def test_unavailable_storage_keeps_note_exportable(self):
        self.context.add_init_script("const original=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='"+NOTES+"')throw new DOMException('quota','QuotaExceededError');return original.call(this,k,v)}")
        self.open_catalog();self.page.fill('#v606Text','Nota solo de sesión');self.page.click('#v606Save')
        self.assertIn('siguen en esta sesión',self.page.locator('#v606Status').inner_text())
        self.assertIn('Nota solo de sesión',self.page.locator('#v606NotesList').inner_text())
        with self.page.expect_download() as event:self.page.click('#v606Export')
        self.assertEqual(json.loads(Path(event.value.path()).read_text())['notes'][0]['text'],'Nota solo de sesión')
        self.assertEqual(self.errors,[])

    def test_print_timeout_and_restricted_pdf(self):
        self.open_catalog()
        pending=[];self.page.route('**/stalled.png',lambda route:pending.append(route))
        self.page.evaluate("window.printCalls=0;window.print=()=>{window.dispatchEvent(new Event('beforeprint'));window.printCalls++;window.dispatchEvent(new Event('afterprint'))};const image=new Image();image.src='/stalled.png';document.getElementById('result').append(image)")
        self.page.click('#print');self.page.wait_for_function('window.printCalls===1')
        self.assertTrue(self.page.locator('#print').is_enabled())
        for route in pending:route.abort()
        self.page.evaluate("document.querySelectorAll('img[src$=\"stalled.png\"]').forEach(e=>e.remove())")
        self.page.emulate_media(media='print')
        with tempfile.TemporaryDirectory() as folder:
            pdf=Path(folder)/'restricted.pdf';self.page.pdf(path=str(pdf),format='A4',print_background=True)
            text=subprocess.run(['pdftotext',str(pdf),'-'],capture_output=True,check=True).stdout.decode()
            first_page=subprocess.run(['pdftotext','-f','1','-l','1',str(pdf),'-'],capture_output=True,check=True).stdout.decode()
        text=' '.join(text.split())
        self.assertIn('No es posible obtener información técnica confiable',text)
        self.assertIn('No es posible obtener información técnica confiable',' '.join(first_page.split()))
        self.assertNotIn('Auditoría de registros no confirmados',text)
        self.assertEqual(self.page.locator('body > .bmw-oem-archive-link').evaluate("e=>getComputedStyle(e).display"),'none')
        self.assertNotIn('ID46 / PCF7936 · condicionado',text)
        self.assertEqual(self.errors,[])
