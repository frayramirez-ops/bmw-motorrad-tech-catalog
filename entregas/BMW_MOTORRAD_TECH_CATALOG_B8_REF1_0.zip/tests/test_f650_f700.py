"""F650 engine generations must stay separate; mechanical locks do not prove immobilizer absence."""
import csv
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

PENDING='PENDIENTE_CONTRASTE_DOCUMENTAL'

class F650F700Tests(unittest.TestCase):
    def test_generation_provenance_and_unknown_chips(self):
        review=json.loads((ROOT/'docs/f650-f700-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="f650f700EvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual((len(review['records']),len(sources),len(observations)),(40,16,35))
        self.assertEqual(sum(s.get('retrieval',{}).get('type')=='.pdf'for s in sources.values()),11)
        pending=0;limited=0;specialist=0;mono_trans=0;conflicts=0;chip_pending=0
        for row in review['records']:
            ident=row['identity'];original=next(r for r in db[row['section']]if all(r[k]==v for k,v in ident.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            primary=sources[row['references'][0]['sourceId']];self.assertIn(ident['model'],primary['models'])
            self.assertTrue(primary['discovery']['indexEntries'])
            mono=row['reviewGroup']=='MONOCILINDRICA_HISTORICA'
            self.assertEqual(primary['platform']in['R13','K14 02'],mono)
            if any('CONFLICTO_CRONOLOGICO'in f for f in row['findings']):conflicts+=1
            if mono and row['section']=='transponders':
                mono_trans+=1;self.assertTrue(all(c['status']==PENDING for c in row['claims']))
            if ident['model']=='F700GS'and ident['year']in[2015,2016]and row['section']=='diagnostico':
                self.assertEqual(ident['system'],'Conector CT');self.assertTrue(any('TRANSICION_CT'in f for f in row['findings']))
            for c in row['claims']:
                if c['topic']in['chip','modulo','conector','ubicacion','mercado_equipamiento']:self.assertEqual(c['status'],PENDING)
                if c['topic']in['chip','modulo']:chip_pending+=1
                if c['status']==PENDING:pending+=1
                else:
                    limited+=1;self.assertTrue(c['observations'])
                    if c['status']=='REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE':specialist+=1;self.assertEqual(c['topic'],'acceso')
                    else:self.assertEqual(c['sourceIds'],[primary['id']])
                for oid in c['observations']:
                    o=observations[oid];self.assertIn(o['sourceId'],c['sourceIds'])
                    self.assertEqual(o['documentSha256'],sources[o['sourceId']]['retrieval']['sha256'])
                    if c['topic']=='acceso'and'-f650-'in oid:self.assertTrue(oid.endswith('-mono')if mono else oid.endswith('-twin'))
                if not mono and c['topic']=='sistema':
                    engine=[observations[o]for o in c['observations']if'-engine-'in o]
                    self.assertEqual(len(engine),1);self.assertIn('798',engine[0]['scope'])
        self.assertEqual((pending,limited,specialist,mono_trans,conflicts,chip_pending),(138,42,18,9,8,40))
        self.assertIn('visually',sources['src-07a4cfe3ecee06ab']['documentEdition'])
        self.assertEqual(observations['src-07a4cfe3ecee06ab-colophon-159']['pdfPage'],159)
        for name,count in [('F650_F700_AFIRMACIONES.csv',180),('F650_F700_PENDIENTES.csv',138)]:
            with(ROOT/'docs'/name).open(encoding='utf-8-sig',newline='')as f:self.assertEqual(len(list(csv.DictReader(f))),count)

    def test_browser_all_generations_and_ct(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/f650-f700-reconciliation.json').read_text())
                select='''row=>{
                    setTab(row.section,{reset:true});
                    for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                    const declaration=document.getElementById('bmwSystemDeclaration');
                    const name=/keyless/i.test(row.identity.system)?'Keyless':/mecánica|ews/i.test(row.identity.system)?'Mecánica':null;
                    if(row.section==='transponders'&&!declaration.hidden&&name){
                      const b=[...declaration.querySelectorAll('button')].find(b=>b.textContent===name);if(b)b.click();
                    }
                    $('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));
                }'''
                self.assertEqual(len(review['records']),40)
                for row in review['records']:
                    with self.subTest(record=row['recordId']):
                        page.evaluate(select,row)
                        panel=page.locator('#f650f700Evidence');self.assertTrue(panel.is_visible())
                        self.assertEqual(panel.get_attribute('data-record-id'),row['recordId'])
                        for other in ['f800Evidence','s1000rrEvidence','r1250Evidence','r1200Evidence','rTouringEvidence','ninetEvidence','rFinalEvidence','f750f850Evidence']:
                            self.assertFalse(page.locator('#'+other).is_visible())
                        if row['identity']['system']=='Conector CT':self.assertIn('TRANSICION_CT',panel.inner_text())
                        if row['section']=='transponders':
                            self.assertIn('No es posible',page.locator('#status').inner_text());self.assertEqual(page.locator('#gallery img').count(),0)
                page.set_viewport_size({'width':375,'height':812});self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                old=next(r for r in json.loads((ROOT/'docs/f750-f850-reconciliation.json').read_text())['records']if r['section']=='diagnostico')
                page.evaluate(select,old)
                self.assertTrue(page.locator('#f750f850Evidence').is_visible());self.assertFalse(page.locator('#f650f700Evidence').is_visible())
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
