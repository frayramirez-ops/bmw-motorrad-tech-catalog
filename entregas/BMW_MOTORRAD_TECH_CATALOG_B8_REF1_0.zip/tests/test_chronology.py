"""Edition dates are distinct from explicit OEM platform/period assignments."""
import functools
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

D='DOCUMENTADO_EN_EDICION_APLICABILIDAD_PENDIENTE'
P='PENDIENTE_CONTRASTE_DOCUMENTAL'

class ChronologyTests(unittest.TestCase):
    def test_explicit_period_evidence_is_required_and_claims_stay_limited(self):
        changes=[];records=[]
        for name,expected in [('r1200gs-reconciliation.json',2),('s1000rr-reconciliation.json',2),('k-reconciliation.json',4)]:
            data=json.loads((ROOT/'docs'/name).read_text());sources={s['id']:s for s in data['sources']};obs={o['id']:o for o in data['observations']}
            self.assertEqual(len(data['temporalFollowUp']['changes']),expected)
            for row in data['records']:
                if not row.get('temporalEvidence'):continue
                records.append(row);e=row['temporalEvidence'];entry=e['indexEntry'];ident=row['identity']
                self.assertEqual(entry['model']['EW'],ident['platform']);self.assertEqual(entry['model']['MARKT'],'EUR')
                self.assertTrue(sources[e['primarySourceId']]['url'].endswith(entry['file']))
                self.assertGreater(int(re.search(r'20\d\d',sources[e['primarySourceId']]['documentEdition'])[0]),ident['year'])
                self.assertEqual(sources[e['indexSourceId']]['retrieval']['sha256'],'450bbd7ae91bf03d9b25753869c96911aa45b95d53897facdccf75db2ea1ccb6')
                self.assertTrue(any('fecha'in c['limitation'].lower()or'periodo'in c['limitation'].lower()for c in row['claims']if c['topic']=='sistema'))
                for c in row['claims']:
                    self.assertEqual(c['status'],D if c['topic']in['sistema','antena']else P)
                    if c['topic']in['sistema','antena']:
                        self.assertEqual(c['sourceIds'],[e['primarySourceId'],e['indexSourceId'],e['corroboratingSourceId']])
                        self.assertTrue(any(obs[oid]['sourceId']==e['indexSourceId']for oid in c['observations']))
                        self.assertIn('no certificación',c['limitation'])
                self.assertTrue(all(c['status']==P for c in e['previousClaims']))
            changes+=data['temporalFollowUp']['changes']
        self.assertEqual(len(changes),8);self.assertEqual(len(records),4)
        self.assertEqual({(r['identity']['model'],r['identity']['year'])for r in records},{('R1200GS',2012),('S1000RR',2014),('K1200GT (K44)',2007),('K1200GT (K44)',2008)})

    def test_browser_temporal_references_do_not_release_technical_results(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=browser.new_page();page.set_default_timeout(6000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                for name,panel in [('r1200gs-reconciliation.json','r1200Evidence'),('s1000rr-reconciliation.json','s1000rrEvidence'),('k-reconciliation.json','kEvidence')]:
                    data=json.loads((ROOT/'docs'/name).read_text())
                    for row in data['records']:
                        if not row.get('temporalEvidence'):continue
                        page.evaluate('''r=>{setTab(r.section,{reset:true});for(let i=0;i<4;i++){$(ids[i]).value=String(r.identity[ids[i]]);cascade(i+1);}const d=document.getElementById('bmwSystemDeclaration');if(!d.hidden){const b=[...d.querySelectorAll('button')].find(b=>b.textContent==='Mecánica');if(b)b.click();}$('system').value=r.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));}''',row)
                        el=page.locator('#'+panel);self.assertTrue(el.is_visible());self.assertEqual(el.get_attribute('data-record-id'),row['recordId'])
                        self.assertIn('CRONOLOGIA_DOCUMENTAL_ACOTADA_RC16',el.inner_text());self.assertIn('Índice oficial BMW',el.inner_text())
                        self.assertIn('No es posible obtener información técnica confiable',page.locator('#status').inner_text());self.assertEqual(page.locator('#gallery img').count(),0);self.assertFalse(page.locator('#v603Panel').is_visible())
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
