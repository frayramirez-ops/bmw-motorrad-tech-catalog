"""Release gates: complete selector traversal, standard-library launcher and ZIP integrity."""
import functools
import importlib.util
import json
import re
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
import urllib.request
import zipfile
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

spec=importlib.util.spec_from_file_location('package_release',ROOT/'scripts/package_release.py')
release=importlib.util.module_from_spec(spec);spec.loader.exec_module(release)

class ReleaseTests(unittest.TestCase):
    def test_all_selectable_catalog_records(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                scope=page.locator('#referenceScope')
                self.assertTrue(scope.is_visible())
                self.assertIn('Catálogo de referencia local',scope.inner_text())
                self.assertIn('2454',scope.inner_text())
                self.assertIn('1306',scope.inner_text())
                self.assertIn('programación permanecen restringidos',scope.inner_text())
                for target in ('ESTADO_CATALOGO.html','PENDIENTES_TECNICOS.html'):
                    self.assertEqual(scope.locator(f'a[href="{target}"]').count(),1)
                rows=page.evaluate("()=>[...DB.transponders.filter(r=>r.system!=='Keyless (Emergencia)').map(r=>({section:'transponders',record:r})),...DB.diagnostico.map(r=>({section:'diagnostico',record:r}))]")
                self.assertEqual(len(rows),701)
                failures=[]
                for start in range(0,len(rows),25):
                    outcomes=page.evaluate('''async rows=>{
                     const results=[];
                     for(const item of rows){
                      const r=item.record;
                      try {
                       setTab(item.section,{reset:true});
                       for(let i=0;i<4;i++){$(ids[i]).value=String(r[ids[i]]);cascade(i+1);}
                       const declaration=document.getElementById('bmwSystemDeclaration');
                       if(item.section==='transponders'&&!declaration.hidden){
                        const name=/keyless/i.test(r.system)?'Keyless':/mecánica|ews/i.test(r.system)?'Mecánica':null;
                        const b=[...declaration.querySelectorAll('button')].find(b=>b.textContent===name);
                        if(b)b.click();
                       }
                       $('system').value=r.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));
                       await Promise.resolve();await Promise.resolve();
                       const exact=ids.every(k=>String($(k).value)===String(r[k]));
                       const title=$('resultTitle').textContent===`BMW ${r.model} · ${r.year}`;
                       const visible=!$('result').hidden;
                       const content=item.section==='diagnostico'?!!$('details').textContent.trim():$('status').textContent.includes('No es posible obtener información técnica confiable.')&&!$('gallery').querySelector('img');
                       if(!exact||!title||!visible||!content)results.push({year:r.year,model:r.model,system:r.system,exact,title,visible,content});
                      }catch(e){results.push({year:r.year,model:r.model,system:r.system,error:String(e)})}
                     }
                     return results;
                    }''',rows[start:start+25])
                    failures.extend(outcomes)
                self.assertEqual(failures[:10],[],f'{len(failures)} failed catalog selections')
                self.assertEqual(errors,[])
                self.assertFalse(page.locator('#v603Panel').is_visible())
                page.click('#reset');self.assertFalse(page.locator('#result').is_visible())
                browser.close()
        finally:server.shutdown();server.server_close()

    def test_local_launcher_serves_the_catalog(self):
        process=subprocess.Popen([sys.executable,str(ROOT/'scripts/serve_catalog.py'),'--port','0','--no-browser'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            line=process.stdout.readline()
            match=re.search(r'(http://127\.0\.0\.1:\d+/)',line);self.assertIsNotNone(match,line)
            with urllib.request.urlopen(match[1],timeout=5)as response:
                self.assertEqual(response.status,200);self.assertIn(json.loads((ROOT/'VERSION.json').read_text())['version'].encode(),response.read())
            with urllib.request.urlopen(match[1]+'ESTADO_CATALOGO.html',timeout=5)as response:self.assertEqual(response.status,200)
        finally:
            process.terminate();process.communicate(timeout=5)

    def test_release_manifest_and_tamper_detection(self):
        with tempfile.TemporaryDirectory()as folder:
            archive=Path(folder)/'release.zip';manifest=release.package(archive)
            self.assertEqual(manifest['version'],json.loads((ROOT/'VERSION.json').read_text()))
            names={r['path']for r in manifest['files']}
            self.assertIn('originals/b8/index.html',names)
            self.assertIn('INICIAR_CATALOGO.bat',names)
            self.assertTrue(all('.git'not in Path(n).parts and '__pycache__'not in Path(n).parts for n in names))
            self.assertEqual(release.verify(archive),manifest)
            with self.assertRaisesRegex(ValueError,'ya existe'):release.package(archive)
            tampered=Path(folder)/'tampered.zip'
            with zipfile.ZipFile(archive)as source,zipfile.ZipFile(tampered,'w',compression=zipfile.ZIP_DEFLATED)as target:
                for name in source.namelist():target.writestr(name,b'changed'if name=='LEEME_PRIMERO.md'else source.read(name))
            with self.assertRaisesRegex(ValueError,'Hash distinto'):release.verify(tampered)
