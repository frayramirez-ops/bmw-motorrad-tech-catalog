"""GS and Adventure evidence stays model-specific; homologation does not certify Keyless chips."""
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

class R1250GSTests(unittest.TestCase):
    def test_registry_model_and_component_limits(self):
        review=json.loads((ROOT/'docs/r1250gs-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="r1250EvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual(len(review['records']),44)
        self.assertEqual(len(sources),8);self.assertEqual(len(observations),30)
        claims=0;documented=0
        for row in review['records']:
            identity=row['identity'];original=next(r for r in db[row['section']]if all(r[k]==v for k,v in identity.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            for ref in row['references']:
                self.assertEqual('Adventure'in sources[ref['sourceId']]['documentEdition'],'Adventure'in identity['model'])
            for claim in row['claims']:
                claims+=1
                if 'Keyless'in identity['system']and claim['topic']in['chip','modulo']:
                    self.assertEqual(claim['status'],'PENDIENTE_CONTRASTE_DOCUMENTAL')
                if claim['topic']in['mercado_equipamiento','conector','ubicacion']:
                    self.assertEqual(claim['status'],'PENDIENTE_CONTRASTE_DOCUMENTAL')
                if claim['status']=='PENDIENTE_CONTRASTE_DOCUMENTAL':continue
                documented+=1;self.assertTrue(claim['observations'])
                for id in claim['observations']:
                    ob=observations[id];self.assertEqual(ob['documentSha256'],sources[ob['sourceId']]['retrieval']['sha256'])
        self.assertEqual(claims,209);self.assertEqual(documented,91)

    def test_browser_model_switch_and_restriction(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/r1250gs-reconciliation.json').read_text())
                visible=[r for r in review['records']if r['identity']['system']!='Keyless (Emergencia)']
                self.assertEqual(len(visible),33)
                for row in visible:
                    with self.subTest(record=row['recordId']):
                        page.evaluate('''row=>{
                         setTab(row.section,{reset:true});
                         for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                         const panel=document.getElementById('bmwSystemDeclaration');
                         if(row.section==='transponders'&&!panel.hidden){
                          const type=row.identity.system.includes('Keyless')?'Keyless':'Mecánica';
                          [...panel.querySelectorAll('button')].find(b=>b.textContent===type).click();
                         }else{$('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));}
                        }''',row)
                        self.assertTrue(page.locator('#r1250Evidence').is_visible())
                        self.assertEqual(page.locator('#r1250Evidence').get_attribute('data-record-id'),row['recordId'])
                        self.assertFalse(page.locator('#f800Evidence').is_visible())
                        self.assertFalse(page.locator('#s1000rrEvidence').is_visible())
                        if row['section']=='transponders':
                            self.assertIn('No es posible',page.locator('#status').inner_text())
                            self.assertEqual(page.locator('#gallery img').count(),0)
                            if 'Keyless'in row['identity']['system']:self.assertIn('rueda trasera',page.locator('#r1250Evidence').inner_text())
                page.set_viewport_size({'width':375,'height':812})
                self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
