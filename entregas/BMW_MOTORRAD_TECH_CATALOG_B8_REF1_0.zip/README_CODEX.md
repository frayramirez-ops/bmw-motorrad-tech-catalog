# BMW Motorrad Tech Catalog — B8-REF1.0

Para uso local, empieza por `LEEME_PRIMERO.md`. Aplicación estática en `BMW_Motorrad_B8_REGENERADO/`. Esta documentación corresponde a la recuperación actual; no sustituye documentos históricos que no fueron entregados.

Lee primero [docs/ESTADO_ACTUAL.md](docs/ESTADO_ACTUAL.md) y después [docs/RECUPERACION_B8.md](docs/RECUPERACION_B8.md) antes de cambiar datos o reglas técnicas.

Arranque desde la raíz del repositorio:

```sh
python3 -m http.server 8000 --bind 127.0.0.1 --directory BMW_Motorrad_B8_REGENERADO
```

Regresión: `python3 -m unittest discover -s tests -v`.

Después de actualizar un registro de conciliación, ejecutar `python3 scripts/build_coverage.py`. Verificar con `python3 scripts/build_coverage.py --check`; la cobertura y el padrón son derivados, no fuentes maestras.
Requiere Python 3, Node.js para comprobaciones sintácticas, Playwright Python, Chromium en `/usr/bin/chromium` y `pdftotext` (Poppler) para comprobar PDF (disponibles en el entorno actual). El catálogo no necesita esos últimos tres componentes para ejecutarse.

Usa el checkout existente: el entorno ya está aislado. No crees worktrees salvo petición expresa. No publiques, despliegues ni certifiques aplicaciones técnicas sin autorización y evidencia.

## Primera entrega de referencia

`VERSION.json` identifica B8-REF1.0; `docs/ACEPTACION_REFERENCIA_1_0.md` fija el alcance aceptado como referencia local y sus límites. Los originales están en `originals/b8`, sin depender de rutas externas del entorno.

Empaquetar: `python3 scripts/package_release.py --output RUTA_NUEVA.zip`. Verificar: `python3 scripts/package_release.py --verify RUTA.zip`. El empaquetador no sobrescribe archivos existentes. Los iniciadores no necesitan Node, Playwright ni paquetes Python; esas herramientas son solo para pruebas.

El inventario documental está cerrado para las 815 fichas B8. Consultar `docs/CIERRE_INVENTARIO_DOCUMENTAL.md`, `docs/PLAN_POSTERIOR_REFERENCIA.md` y el CSV derivado `docs/PENDIENTES_TECNICOS_B8.csv` antes de trabajar en compatibilidades. Son 2454 afirmaciones pendientes, no un porcentaje global de proyecto.

Al cambiar la versión de entrega, actualizar solo el sello de interfaz y las referencias activas. No sustituir versiones globalmente dentro del HTML: los registros JSON embebidos conservan su historial y deben coincidir exactamente con los JSON de `docs/`. Las pruebas de procedencia comprueban esa igualdad.

Cierre funcional local y bloqueos de entrega: `docs/CIERRE_FUNCIONAL_Y_BLOQUEOS.md`. Validación de una entrega extraída: `python3 scripts/verify_local_delivery.py --archive RUTA.zip --output-dir CARPETA_NUEVA`; requiere las herramientas de pruebas y conserva el resultado previo.

El usuario aceptó cerrar la primera versión como catálogo de referencia con pendientes visibles. El cierre del software en ese alcance no certifica datos ni acredita recepción del archivo. No abrir otra ronda de candidatas para resolver evidencias externas sin un objetivo concreto. Estado y validación vigentes: `docs/CIERRE_REFERENCIA_1_0.md`.
