/* Documentary reconciliation only: this layer cannot release technical rules. */
function mountDocumentaryReview(dataId, panelId, titleText) {
 'use strict';
 const data = JSON.parse(document.getElementById(dataId).textContent);
 const records = new Map(data.records.map(r => [r.recordId, r]));
 const sources = new Map(data.sources.map(s => [s.id, s]));
 const result = document.getElementById('result');
 const panel = document.createElement('section');
 panel.id = panelId; panel.hidden = true;
 panel.setAttribute('aria-label', titleText);
 panel.style.cssText = 'border:1px solid #acbfd4;border-radius:10px;padding:14px;margin:14px 0;overflow-wrap:anywhere';
 result.append(panel);
 function node(tag, text) { const n = document.createElement(tag); n.textContent = text; return n; }
 function refresh() {
  panel.replaceChildren(); panel.hidden = true;
  if (result.hidden) return;
  const selection = selected();
  const record = sourceRows().find(r => ids.every(k => String(r[k]) === String(selection[k])));
  if (!record) return;
  const id = tab + ':' + JSON.stringify(ids.map(k => String(record[k] ?? '')));
  const review = records.get(id);
  if (!review) return;
  panel.hidden = false; panel.dataset.recordId = id;
  panel.append(node('h3', titleText));
  panel.append(node('p', 'Generación: ' + review.generation.replaceAll('_', ' ') + ' · ' + record.year + ' · ' + record.system));
  panel.append(node('p', 'Contraste documental por edición, sin certificación por VIN. Las referencias pendientes no confirman chip, módulo, conector ni equipamiento de esta unidad.'));
  const list = document.createElement('ul');
  const labels = {
   PENDIENTE_CONTRASTE_DOCUMENTAL:'pendiente de evidencia aplicable',
   REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE:'referencia de especialista; aplicación individual pendiente',
   DOCUMENTADO_EN_EDICION_APLICABILIDAD_PENDIENTE:'documentado en una edición; aplicación individual pendiente',
   OPCION_DOCUMENTADA_APLICABILIDAD_PENDIENTE:'opción documentada; equipamiento individual pendiente',
   HOMOLOGACION_DOCUMENTADA_UNIDAD_PENDIENTE:'homologación documentada; unidad sin identificar'
  };
  for (const claim of review.claims) {
   const item = node('li', claim.topic.replaceAll('_', ' ') + ': ' + (labels[claim.status] || 'pendiente'));
   if (claim.finding) item.append(node('p', claim.finding));
   if (claim.nextAction) item.append(node('p', 'Para resolver: ' + claim.nextAction));
   for (const id of claim.observations || []) {
    const observation = data.observations.find(o => o.id === id);
    if (observation) item.append(node('small', observation.pdfPage ? 'Página PDF ' + observation.pdfPage + (observation.printedPage == null ? '' : ', impresa ' + observation.printedPage) + '. ' + observation.scope : observation.section + '. ' + observation.scope));
   }
   list.append(item);
  }
  panel.append(list);
  for (const finding of review.findings) panel.append(node('p', finding));
  if (review.sourceCodes.length) panel.append(node('p', 'Códigos históricos sin resolver: ' + review.sourceCodes.join(', ') + '. Los enlaces siguientes no se atribuyen a esos códigos.'));
  const links = document.createElement('ul');
  const seen = new Set();
  for (const ref of review.references) {
   const source = sources.get(ref.sourceId);
   if (!source || seen.has(source.id)) continue;
   let url; try { url = new URL(source.url); } catch (_) { continue; }
   if (url.protocol !== 'https:') continue;
   seen.add(source.id);
   const li = document.createElement('li');
   const prefix = ref.origin === 'CITA_HISTORICA_B8' ? (source.status === 'CONTENIDO_CONSULTADO' ? 'Cita histórica B8, consultada: ' : 'Cita histórica B8, sin verificar: ') : (source.status === 'CONTENIDO_CONSULTADO' ? 'Fuente consultada: ' : 'Fuente citada, sin verificar: ');
   const a = node('a', prefix + (source.documentEdition || url.hostname));
   a.href = url.href; a.target = '_blank'; a.rel = 'noopener noreferrer';
   li.append(a); links.append(li);
  }
  panel.append(links);
  if (!seen.size) panel.append(node('p', 'Sin enlace documental recuperado para esta identidad exacta.'));
 }
 for (const id of ids) document.getElementById(id).addEventListener('change', () => queueMicrotask(refresh));
 document.querySelectorAll('.tabs [data-tab]').forEach(b => b.addEventListener('click', () => queueMicrotask(refresh)));
 new MutationObserver(() => queueMicrotask(refresh)).observe(result, {attributes:true, attributeFilter:['hidden']});
 window.addEventListener('beforeprint', refresh);
 refresh();
}
mountDocumentaryReview('f800EvidenceData', 'f800Evidence', 'Conciliación documental · F800GS');
mountDocumentaryReview('s1000EvidenceData', 's1000rrEvidence', 'Conciliación documental · S1000RR');
mountDocumentaryReview('r1250EvidenceData', 'r1250Evidence', 'Conciliación documental · R1250GS / Adventure');
mountDocumentaryReview('r1200EvidenceData', 'r1200Evidence', 'Conciliación documental · R1200GS / Adventure');
mountDocumentaryReview('rTouringEvidenceData', 'rTouringEvidence', 'Conciliación documental · R1250RT / R1300GS y Adventure');
mountDocumentaryReview('ninetEvidenceData', 'ninetEvidence', 'Conciliación documental · R nineT y variantes');
mountDocumentaryReview('rFinalEvidenceData', 'rFinalEvidence', 'Conciliación documental · R antiguas y recientes');
mountDocumentaryReview('f750f850EvidenceData', 'f750f850Evidence', 'Conciliación documental · F750GS / F850GS / Adventure');
mountDocumentaryReview('f650f700EvidenceData', 'f650f700Evidence', 'Conciliación documental · F650 / F700 y generaciones');
mountDocumentaryReview('fFinalEvidenceData', 'fFinalEvidence', 'Conciliación documental · F900 / F450');
mountDocumentaryReview('kEvidenceData', 'kEvidence', 'Conciliación documental · Familia K');
mountDocumentaryReview('cEvidenceData', 'cEvidence', 'Conciliación documental · Familia C');
mountDocumentaryReview('sFinalEvidenceData', 'sFinalEvidence', 'Conciliación documental · S1000R / S1000XR');
mountDocumentaryReview('gmEvidenceData', 'gmEvidence', 'Conciliación documental · Familias G / M');
