# BMW Motorrad Tech Catalog — B8-REF3.0

Primera versión de referencia local de RE:MOTO LAB | DUPLIKEY MX. Conserva B8 y recupera su interfaz, recursos y trazabilidad disponible. No es una base de compatibilidades certificada por VIN.

## Abrir el catálogo

1. Extrae **todo** el ZIP en una carpeta. No abras solo el HTML desde dentro del ZIP.
2. Necesitas **Python 3**. No hace falta instalar paquetes para usar el catálogo.
3. En Windows, abre `INICIAR_CATALOGO.bat`. En macOS/Linux, ejecuta `sh iniciar_catalogo.sh` desde esta carpeta.
4. El navegador se abrirá con el catálogo. Mantén abierta la ventana del iniciador; para detenerlo, pulsa Ctrl+C.

Si no se abre el navegador, la ventana indica la dirección local. Si el puerto 8000 está ocupado, cierra la otra sesión del catálogo antes de volver a iniciar. No detengas procesos que no reconozcas. Para uso avanzado: `python3 scripts/serve_catalog.py --port 8001`.

El iniciador Python se probó en el entorno Linux de desarrollo. Los envoltorios `.bat` y `.sh` se incluyen para facilitar el arranque; no se ejecutaron en Windows/macOS en esta validación. La apertura directa file:// está bloqueada en el navegador administrado de pruebas; usa el iniciador HTTP.

## Qué incluye

- 815 fichas originales, consulta encadenada, búsqueda y comparador.
- 89 recursos recuperados y biblioteca visual de 24 fotografías/recortes.
- Favoritos, notas locales y su respaldo/restauración, copia e impresión con restricciones técnicas.
- Paneles documentales de todas las familias B8: C, F, G, K, M, R y S; referencias por edición y pendientes explícitos.
- Cobertura consultable y padrón CSV completo de las fichas recibidas.
- Consulta de pendientes por modelo, familia, tema y año, con fuentes, acciones y exportación CSV.
- Originales B8 inmutables en `originals/b8`, documentación y pruebas.

## Alcance técnico de esta versión

Las 815 fichas tienen conciliación detallada (100 % del inventario B8 recibido). Hay 1598 afirmaciones con respaldo limitado y 2162 pendientes; este cierre de inventario no certifica compatibilidad ni finalización técnica. Desde «Consultar cobertura documental del catálogo», abre «Consultar pendientes técnicos y evidencia necesaria». Puedes filtrar o exportar las afirmaciones pendientes; cada ficha de cobertura enlaza también a sus propios pendientes. No hay un porcentaje global de finalización ni un padrón OEM completo por mercado 2003–2027.

Las referencias de programación continúan restringidas hasta reconstruir sus vínculos auditados. Una imagen, certificado o declaración manual de sistema no acredita una aplicación por VIN. No se validaron todas las licencias/atribuciones de las imágenes ni todas las fuentes heredadas F. Véase `docs/ACEPTACION_REFERENCIA_1_0.md`.

## Cuidar tus notas

Las notas y favoritos pertenecen al navegador y dirección local. No están en el ZIP ni sincronizados. Antes de cambiar de carpeta, equipo, navegador o puerto, exporta las notas desde el catálogo. Si falla almacenamiento, una nota puede quedar solo en la sesión: expórtala antes de cerrar. No se certifican datos técnicos por guardar una observación.

## Verificar o mantener esta entrega

- Integridad del ZIP: `python3 scripts/package_release.py --verify RUTA_AL_ZIP`.
- Regresión de desarrollo: `python3 -m unittest discover -s tests -v` (requiere las herramientas descritas en `README_CODEX.md`).
- Cambios documentales: ejecutar `python3 scripts/build_coverage.py` y comprobar `--check`.

El manifiesto verifica integridad de archivos; no es firma digital ni certificación técnica. La versión 1.0 se entregó como ZIP público en GitHub, con autorización del usuario; no se desplegó una aplicación web. Los informes históricos contienen cifras anteriores; consulta `docs/ESTADO_ACTUAL.md` para el estado vigente.

## Estado de esta entrega

Esta versión incorpora el bloque transversal de las siete familias. Véase `docs/ACTUALIZACION_TRANSVERSAL_REF2.md`. Los cierres 1.0/1.1 son antecedentes y la investigación continúa por bloques en `docs/PLAN_DESARROLLO_BLOQUES.md`.

Probada en Linux con Chromium. Quedan por comprobar el equipo del usuario y la recepción del paquete. Las licencias de imágenes requieren revisión antes de cualquier distribución pública. La distribución autorizada es mediante ZIP en GitHub; no hay despliegue web.

## Antecedente: actualización 1.1

Consulta `docs/ACTUALIZACION_R1250GSA_2020.md` para la corrección de la Adventure 2020 y once ubicaciones de GS/Adventure. La ficha separa información documentada y componentes pendientes. La validación de esa versión se registra en `docs/VALIDACION_REFERENCIA_1_1.json`; los documentos de cierre 1.0 son antecedentes de alcance, no cifras actuales.

## Datos disponibles por ficha

Las fichas con evidencia muestran su resumen de referencia y enlaces por página o sección. Hay 757 con datos documentados (647 de las 701 selecciones visibles), 222 fichas Keyless con pila/alcance y 309 fichas de diagnóstico con ubicación respaldada. El enlace «Descargar matriz de datos disponibles (CSV)» permite revisar los 815 registros y sus campos. Las 58 entradas sin datos técnicos documentados se mantienen explícitas; no se rellenan por parecido con otras motos.

## Datos nuevos REF3

Se añaden perfiles de diagnóstico del motor, acceso/inmovilizador, arquitectura y software de referencia por modelo/periodo. La matriz conjunta muestra 799 fichas con alguna información documental (incluye 789 con perfiles HEX); 16 siguen sin datos de referencia suficientes. Los perfiles no identifican la pieza instalada ni confirman Keyless. Los formatos de tres pines de R1100R/RS/RT 2001 se distinguen del código C10 heredado. Consulta `docs/ACTUALIZACION_DIAGNOSTICA_REF3.md`. Cierra el iniciador anterior antes de abrir el nuevo para evitar consultar una versión vieja en el mismo puerto.
