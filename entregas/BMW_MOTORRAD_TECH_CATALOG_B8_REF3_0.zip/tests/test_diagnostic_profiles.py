"""Manufacturer diagnostic profiles must not become guessed installed hardware."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest
from test_recovery import APP,ROOT

spec=importlib.util.spec_from_file_location('diagnostic_profiles',ROOT/'scripts/build_diagnostic_profiles.py')
profiles_builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(profiles_builder)


class DiagnosticProfileTests(unittest.TestCase):
    def test_generated_profiles_model_period_and_platform_boundaries(self):
        check=subprocess.run([sys.executable,str(ROOT/'scripts/build_diagnostic_profiles.py'),'--check'],capture_output=True,text=True)
        self.assertEqual(check.returncode,0,check.stderr)
        source=json.loads((ROOT/'docs/hex-function-chart-data.json').read_text())
        data=json.loads((ROOT/'docs/diagnostic-profile-bindings.json').read_text())
        self.assertEqual(len(source['profiles']),159)
        self.assertEqual(data['sourceInputSha256'],hashlib.sha256((ROOT/'docs/hex-function-chart-data.json').read_bytes()).hexdigest())
        self.assertEqual(data['summary'],{'records':815,'recordsWithDiagnosticProfiles':789,'selectableRecordsWithDiagnosticProfiles':680,'recordsWithEngineProfile':789,'recordsWithAccessProfile':412,'recordsWithoutProfile':26})
        self.assertEqual(len({r['recordId'] for r in data['records']}),815)
        definitions={p['id']:p for p in data['profiles']}
        matched=[r for r in data['records'] if r['profileIds']]
        self.assertEqual({r['identity']['family'] for r in matched},set('CFGKMRS'))
        for row in matched:
            identity=row['identity'];platforms=profiles_builder.platforms(identity['platform'])
            for pid in row['profileIds']:
                definition=definitions[pid]
                self.assertLessEqual(definition['startYear'],identity['year'])
                if definition['endYear'] is not None:self.assertGreaterEqual(definition['endYear'],identity['year'])
                if platforms:self.assertTrue(platforms & set(definition['platforms']))
                self.assertNotIn('Campagne',definition['heading']);self.assertNotIn('Rosenbauer',definition['heading'])
            self.assertIn('perfil_motor',row['fields'])
            self.assertNotIn('chip',row['fields']);self.assertNotIn('modulo',row['fields'])
            if identity['system']=='Mecánica' and 'perfil_acceso' in row['fields']:
                self.assertNotIn('Keyless Entry',row['fields']['perfil_acceso'])
        old_f=[r for r in matched if r['identity']['model']=='F800GS (798 cc)']
        new_f=[r for r in matched if r['identity']['model']=='F800GS (895 cc)']
        self.assertTrue(old_f and new_f)
        self.assertTrue(all('K72' in pid for r in old_f for pid in r['profileIds']))
        self.assertTrue(all('K80' in pid for r in new_f for pid in r['profileIds']))
        transition=[r for r in matched if r['identity']['model']=='R1200GS' and r['identity']['year']==2013]
        self.assertTrue(any('K25' in r['identity']['platform'] for r in transition))
        self.assertTrue(any('K50' in r['identity']['platform'] for r in transition))
        for r in transition:
            expected='K50' if 'K50' in r['identity']['platform'] else 'K25'
            self.assertTrue(all(expected in pid for pid in r['profileIds']))
        beyond=[r for r in data['records'] if r['identity']['model']=='R1250GS Adventure' and r['identity']['year']==2024]
        self.assertEqual(len(beyond),4);self.assertTrue(all(not r['profileIds'] for r in beyond))
        generated=(APP/'diagnostic-profile-data.js').read_text()
        self.assertEqual(json.loads(generated.split('window.BMW_DIAGNOSTIC_PROFILES=',1)[1].rstrip(';\n')),data)

    def test_original_chip_module_claims_and_explicit_three_pin_exception(self):
        claims=[];changed=[];hypotheses=[]
        bindings={r['recordId']:r for r in json.loads((ROOT/'docs/diagnostic-profile-bindings.json').read_text())['records']}
        for path in (ROOT/'docs').glob('*-reconciliation.json'):
            review=json.loads(path.read_text())
            for row in review['records']:
                if row['status']=='HIPOTESIS_NO_ACREDITADA':
                    hypotheses.append(row);self.assertFalse(bindings[row['recordId']]['profileIds'])
                    self.assertTrue(all(c['status']=='PENDIENTE_CONTRASTE_DOCUMENTAL' for c in row['claims']))
                for claim in row['claims']:
                    if claim['topic'] in ('chip','modulo'):claims.append([row['recordId'],claim])
            changed.extend(review.get('diagnosticHardwareUpdate3',{}).get('changes',[]))
        raw=json.dumps(sorted(claims,key=lambda x:(x[0],x[1]['topic'])),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
        self.assertEqual(len(claims),1000)
        self.assertEqual(hashlib.sha256(raw).hexdigest(),'0a72cf8f5a7eaec73dfe59b6c5af77e7574b2e36160779a557eb846cb85a1894')
        self.assertEqual(len(hypotheses),8);self.assertEqual(len(changed),3)
        self.assertEqual({bindings[c['recordId']]['identity']['model'] for c in changed},{'R 1100 R','R 1100 RS','R 1100 RT'})
        for change in changed:
            self.assertEqual(change['topic'],'conector');self.assertEqual(change['previousClaim']['status'],'PENDIENTE_CONTRASTE_DOCUMENTAL')
            self.assertTrue(all(pid.startswith('3P_') for pid in bindings[change['recordId']]['profileIds']))
        for row in bindings.values():
            if row['identity']['model'] in ('R 1100 S','R 1150 GS'):
                self.assertNotIn('formato_documental',row['fields'])
