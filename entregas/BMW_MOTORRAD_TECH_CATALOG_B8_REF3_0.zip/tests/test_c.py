"""C-series: preserve chip conflicts, connector labels and contradictory GT reader passages."""
import csv
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

PENDING='PENDIENTE_CONTRASTE_DOCUMENTAL'

class CTests(unittest.TestCase):
    def test_provenance_and_unresolved_component_conflicts(self):
        review=json.loads((ROOT/'docs/c-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="cEvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual((len(review['records']),len(sources),(len(observations)-len(review['bulkReferenceUpdate']['additionalObservationIds']))),(87,38,92))
        self.assertEqual(sum(s.get('retrieval',{}).get('type')=='.pdf'for s in sources.values()),36)
        pending=limited=specialist=gt_conflicts=mechanical_antennas=c16c=0
        for row in review['records']:
            ident=row['identity'];original=next(r for r in db[row['section']]if all(r[k]==v for k,v in ident.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            primary=sources[row['references'][0]['sourceId']];self.assertEqual(primary['models'],[ident['model']])
            self.assertTrue(primary['discovery']['indexEntries']);self.assertLessEqual(primary['editionYear'],ident['year'])
            self.assertEqual(row['zipComparisonStatus'],'NO_CONTRASTADO_EN_ESTE_BLOQUE')
            self.assertEqual(row['b8Result'],original['result'])
            if ident['system']=='Mecánica':
                code='CONFLICTO_CHIP_HEREDADO'if original['result'].startswith('CONFLICTO:')else'CHIP_CONDICIONADO_HEREDADO'
                self.assertTrue(any(f.startswith(code)for f in row['findings']))
            if ident['system']=='Conector C16C':
                c16c+=1;self.assertTrue(any('C16C_SIN_EQUIVALENCIA'in f for f in row['findings']))
            for c in row['claims']:
                if c['topic']in['chip','modulo','conector','mercado_equipamiento']:self.assertEqual(c['status'],PENDING)
                if c['topic']=='antena'and ident['system']=='Mecánica':
                    mechanical_antennas+=1;self.assertEqual(c['status'],PENDING)
                if c['topic']=='antena'and ident['model']=='C400GT':
                    gt_conflicts+=1;self.assertEqual(c['status'],PENDING);self.assertTrue(c['observations'])
                    self.assertEqual(len(c['sourceIds']),3)
                    self.assertTrue(any('-battery-holder-'in oid for oid in c['observations']))
                    self.assertTrue(any(f.startswith('CONTRASTE_MULTILINGUE')for f in row['findings']))
                    self.assertIn('CONFLICTO_UBICACION_INTERNO',c['finding'])
                    self.assertIn('battery cover',c['finding']);self.assertIn('rear-wheel cover',c['finding'])
                    self.assertTrue(any('CONFLICTO_UBICACION_INTERNO'in f for f in row['findings']))
                if c['status']==PENDING:pending+=1
                else:
                    limited+=1;self.assertTrue(c['observations'])
                    if c['status']=='REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE':
                        specialist+=1;self.assertIn(c['topic'],['acceso','ubicacion']);self.assertLessEqual(ident['year'],2015)
                    else:self.assertEqual(c['sourceIds'],[primary['id']])
                for oid in c['observations']:
                    o=observations[oid];self.assertIn(o['sourceId'],c['sourceIds'])
                    self.assertEqual(o['documentSha256'],sources[o['sourceId']]['retrieval']['sha256'])
        self.assertEqual((pending,limited,specialist,gt_conflicts,mechanical_antennas,c16c),(260,140,16,16,18,10))
        self.assertEqual(len(review['followUp']['editionComparisons']),5)
        self.assertEqual(sum(c['spanishBackupInternallyConsistent']for c in review['followUp']['editionComparisons']),2)
        self.assertEqual(sources['src-ce9a9eac76759941']['documentEdition'],'C650GT 06.2019, 5th edition')
        self.assertEqual(sources['src-a81b645c98f97540']['documentEdition'],'C400GT 09.2024, edition 1.1')
        self.assertEqual(sources['src-d8c049792bc12e8e']['documentEdition'],'C400GT 02.2022, 3rd edition')
        for name,count in [('C_AFIRMACIONES.csv',400),('C_PENDIENTES.csv',260)]:
            with(ROOT/'docs'/name).open(encoding='utf-8-sig',newline='')as f:self.assertEqual(len(list(csv.DictReader(f))),count)

    def test_browser_all_selectable_variants(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/c-reconciliation.json').read_text())
                rows=[r for r in review['records']if r['identity']['system']!='Keyless (Emergencia)'];self.assertEqual(len(rows),70)
                select='''row=>{
                    setTab(row.section,{reset:true});
                    for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                    const declaration=document.getElementById('bmwSystemDeclaration');
                    const name=/keyless/i.test(row.identity.system)?'Keyless':/mecánica|ews/i.test(row.identity.system)?'Mecánica':null;
                    if(row.section==='transponders'&&!declaration.hidden&&name){
                      const b=[...declaration.querySelectorAll('button')].find(b=>b.textContent===name);if(b)b.click();
                    }
                    $('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));
                }'''
                for row in rows:
                    with self.subTest(record=row['recordId']):
                        page.evaluate(select,row)
                        panel=page.locator('#cEvidence');self.assertTrue(panel.is_visible())
                        self.assertEqual(panel.get_attribute('data-record-id'),row['recordId'])
                        for other in ['f800Evidence','s1000rrEvidence','r1250Evidence','r1200Evidence','rTouringEvidence','ninetEvidence','rFinalEvidence','f750f850Evidence','f650f700Evidence','fFinalEvidence','kEvidence']:
                            self.assertFalse(page.locator('#'+other).is_visible())
                        if row['identity']['system']=='Conector C16C':self.assertIn('C16C_SIN_EQUIVALENCIA',panel.inner_text())
                        if row['section']=='transponders'and row['identity']['model']=='C400GT':self.assertIn('CONFLICTO_UBICACION_INTERNO',panel.inner_text())
                        if row['section']=='transponders':
                            self.assertIn('Chip y programación no validados',page.locator('#status').inner_text());self.assertEqual(page.locator('#gallery img').count(),0)
                page.set_viewport_size({'width':375,'height':812});self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                old=next(r for r in json.loads((ROOT/'docs/f-final-reconciliation.json').read_text())['records']if r['section']=='diagnostico')
                page.evaluate(select,old)
                self.assertTrue(page.locator('#fFinalEvidence').is_visible());self.assertFalse(page.locator('#cEvidence').is_visible())
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
