"""Pending work must remain traceable, readable and exportable without releasing claims."""
import copy
import csv
import functools
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

class PendingTests(unittest.TestCase):
    def test_generated_worklist_preserves_claim_provenance(self):
        html=(APP/'PENDIENTES_TECNICOS.html').read_text()
        data=json.loads(re.search(r'<script id="pendingData"[^>]*>(.*?)</script>',html,re.S)[1])
        coverage=json.loads((ROOT/'docs/coverage-data.json').read_text())
        self.assertEqual(data['summary'],coverage['summary']);self.assertEqual(data['inputs'],coverage['inputs'])
        self.assertEqual(len(data['records']),2162)
        reviews={name:json.loads((ROOT/'docs'/name).read_text())for name in data['inputs']['reviewSha256']}
        records={name:{r['recordId']:r for r in review['records']}for name,review in reviews.items()}
        for row in data['records']:
            original=records[row['review']][row['recordId']]
            claim=next(c for c in original['claims']if c['topic']==row['topic'])
            self.assertEqual(claim['status'],'PENDIENTE_CONTRASTE_DOCUMENTAL')
            self.assertEqual(row['nextAction'],claim['nextAction']);self.assertEqual(row['limitation'],claim['limitation'])
            self.assertEqual(row['recordStatus'],original['status'])
            self.assertEqual([s['id']for s in row['references']],[ref['sourceId']for ref in original['references']])
            self.assertEqual(len(row['observations']),len(claim.get('observations',[])))
            self.assertEqual([s['scope']for s in row['references']],[ref.get('scope')for ref in original['references']])
        gt=[r for r in data['records']if r['model']=='C400GT'and r['topic']=='antena']
        self.assertEqual(len(gt),16)
        self.assertTrue(all(any('CONTRASTE_MULTILINGUE'in f for f in r['contextFindings'])for r in gt))
        self.assertEqual((APP/'PENDIENTES_TECNICOS_B8.csv').read_bytes(),(ROOT/'docs/PENDIENTES_TECNICOS_B8.csv').read_bytes())
        with(APP/'PENDIENTES_TECNICOS_B8.csv').open(encoding='utf-8-sig',newline='')as f:rows=list(csv.DictReader(f))
        self.assertEqual({(r['recordId'],r['topic'])for r in data['records']},{(r['identidad'],r['afirmacion'])for r in rows})

    def test_browser_worklist_filters_sources_exports_and_exact_record(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                base=f'http://127.0.0.1:{server.server_port}/'
                page.goto(base+'ESTADO_CATALOGO.html',wait_until='networkidle')
                first=page.locator('#coverageRows tr').first;record_id=first.get_attribute('data-record-id')
                first.get_by_role('link').click();page.wait_for_load_state('networkidle')
                self.assertTrue(page.locator('#pendingContext').is_visible())
                self.assertTrue(all(v==record_id for v in page.locator('.pendingCard').evaluate_all('(rows)=>rows.map(r=>r.dataset.recordId)')))
                page.get_by_role('button',name='Limpiar filtros').click();self.assertNotIn('record=',page.url)
                self.assertEqual(page.locator('#pendingCount').inner_text(),'1–25 de 2162 afirmaciones')
                first_id=page.locator('.pendingCard').first.get_attribute('data-record-id')
                page.click('#pendingNext');self.assertEqual(page.locator('#pendingCount').inner_text(),'26–50 de 2162 afirmaciones')
                page.click('#pendingPrev');self.assertEqual(page.locator('.pendingCard').first.get_attribute('data-record-id'),first_id)
                page.select_option('#pendingFamily','C');page.select_option('#pendingTopic','antena');page.fill('#pendingSearch','C400GT')
                self.assertEqual(page.locator('#pendingCount').inner_text(),'1–16 de 16 afirmaciones')
                page.locator('.pendingCard summary').first.click()
                text=page.locator('.pendingCard').first.inner_text();self.assertIn('CONTRASTE_MULTILINGUE',text)
                self.assertIn('cubierta',text);self.assertIn('Límite:',text)
                for link in page.locator('.pendingCard').first.locator('a').all():self.assertTrue(link.get_attribute('href').startswith('https://'))
                with page.expect_download()as event:page.click('#pendingExport')
                with open(event.value.path(),encoding='utf-8-sig',newline='')as f:export=list(csv.DictReader(f))
                self.assertEqual(len(export),16);self.assertTrue(all(r['modelo']=='C400GT'and r['afirmacion']=='antena'for r in export))
                page.select_option('#pendingYear','2024');self.assertEqual(page.locator('#pendingCount').inner_text(),'1–2 de 2 afirmaciones')
                page.fill('#pendingSearch','inexistente-999');self.assertTrue(page.locator('#pendingEmpty').is_visible());self.assertTrue(page.locator('#pendingExport').is_disabled())
                page.get_by_role('button',name='Limpiar filtros').click()
                page.select_option('#pendingFamily','R');page.fill('#pendingSearch','R1250GSA');self.assertGreater(page.locator('.pendingCard').count(),0)
                page.get_by_role('button',name='Limpiar filtros').click()
                with page.expect_download()as event:page.get_by_role('link',name='Descargar todos los pendientes (CSV)').click()
                with open(event.value.path(),encoding='utf-8-sig',newline='')as f:self.assertEqual(len(list(csv.DictReader(f))),2162)
                page.goto(base+'PENDIENTES_TECNICOS.html?record=identidad-inexistente',wait_until='networkidle');self.assertTrue(page.locator('#pendingEmpty').is_visible())
                page.get_by_role('button',name='Limpiar filtros').click()
                page.set_viewport_size({'width':375,'height':812});self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                page.get_by_role('link',name='Volver a cobertura').click();page.wait_for_load_state('networkidle')
                page.get_by_role('link',name='Consultar pendientes técnicos y evidencia necesaria').click();page.wait_for_load_state('networkidle')
                self.assertEqual(page.locator('#pendingCount').inner_text(),'1–25 de 2162 afirmaciones')
                # Rendering data must not execute markup or make javascript: source links.
                html=(APP/'PENDIENTES_TECNICOS.html').read_text();match=re.search(r'<script id="pendingData"[^>]*>(.*?)</script>',html,re.S)
                payload=json.loads(match[1]);row=copy.deepcopy(payload['records'][0]);row['finding']='<img src=x onerror="window.pendingXss=true">'
                row['references']=[{'url':'javascript:window.pendingXss=true','title':'unsafe','status':'CITADA_SIN_VERIFICAR'}];row['observations']=[];payload['records']=[row]
                html=html[:match.start(1)]+json.dumps(payload,ensure_ascii=False).replace('<','\\u003c')+html[match.end(1):]
                page.route('**/PENDIENTES_TECNICOS.html',lambda route:route.fulfill(status=200,content_type='text/html',body=html))
                page.goto(base+'PENDIENTES_TECNICOS.html',wait_until='networkidle');page.locator('.pendingCard summary').click()
                self.assertIn('<img src=x',page.locator('.pendingCard').inner_text());self.assertEqual(page.locator('.pendingCard img').count(),0)
                self.assertEqual(page.locator('a[href^="javascript:"]').count(),0);self.assertFalse(page.evaluate('Boolean(window.pendingXss)'))
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
