"""GS and Adventure evidence stays model-specific; homologation does not certify Keyless chips."""
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

class R1250GSTests(unittest.TestCase):
    def test_registry_model_and_component_limits(self):
        review=json.loads((ROOT/'docs/r1250gs-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="r1250EvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual(len(review['records']),44)
        self.assertEqual(len(sources),10);self.assertEqual((len(observations)-len(review['bulkReferenceUpdate']['additionalObservationIds'])),49)
        claims=0;documented=0
        for row in review['records']:
            identity=row['identity'];original=next(r for r in db[row['section']]if all(r[k]==v for k,v in identity.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            for ref in row['references']:
                self.assertEqual('Adventure'in sources[ref['sourceId']]['documentEdition'],'Adventure'in identity['model'])
            for claim in row['claims']:
                claims+=1
                if 'Keyless'in identity['system']and claim['topic']in['chip','modulo']:
                    self.assertEqual(claim['status'],'PENDIENTE_CONTRASTE_DOCUMENTAL')
                if claim['topic']in['mercado_equipamiento','conector']:
                    self.assertEqual(claim['status'],'PENDIENTE_CONTRASTE_DOCUMENTAL')
                if claim['status']=='PENDIENTE_CONTRASTE_DOCUMENTAL':continue
                documented+=1;self.assertTrue(claim['observations'])
                for id in claim['observations']:
                    ob=observations[id];self.assertEqual(ob['documentSha256'],sources[ob['sourceId']]['retrieval']['sha256'])
        self.assertEqual(claims,209);self.assertEqual(documented,102)
        changes=review['referenceUpdate11']['claimChanges']
        self.assertEqual(len(changes),11)
        self.assertTrue(all(c['topic']=='ubicacion' and c['previousClaim']['status']=='PENDIENTE_CONTRASTE_DOCUMENTAL' for c in changes))
        for row in review['records']:
            if row['section']=='diagnostico':
                location=next(c for c in row['claims']if c['topic']=='ubicacion')
                self.assertEqual(location['status'],'DOCUMENTADO_EN_EDICION_APLICABILIDAD_PENDIENTE')
                self.assertIn('lateral derecho',location['finding'])
            facts=row.get('referenceFacts')
            target=row['identity']['year']==2020 and row['identity']['model']=='R1250GS Adventure'
            self.assertIsNotNone(facts)
            if not facts:continue
            if target:self.assertIn('K51 MU2',facts['scope'])
            for fact in facts['facts']:
                self.assertTrue(fact['value']);self.assertTrue(fact['observations'])
                for oid in fact['observations']:
                    self.assertIn(oid,observations)
                    self.assertEqual('Adventure' in sources[observations[oid]['sourceId']]['documentEdition'],'Adventure' in row['identity']['model'])

    def test_browser_model_switch_and_restriction(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/r1250gs-reconciliation.json').read_text())
                visible=[r for r in review['records']if r['identity']['system']!='Keyless (Emergencia)']
                self.assertEqual(len(visible),33)
                for row in visible:
                    with self.subTest(record=row['recordId']):
                        page.evaluate('''row=>{
                         setTab(row.section,{reset:true});
                         for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                         const panel=document.getElementById('bmwSystemDeclaration');
                         if(row.section==='transponders'&&!panel.hidden){
                          const type=row.identity.system.includes('Keyless')?'Keyless':'Mecánica';
                          [...panel.querySelectorAll('button')].find(b=>b.textContent===type).click();
                         }else{$('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));}
                        }''',row)
                        self.assertTrue(page.locator('#r1250Evidence').is_visible())
                        self.assertEqual(page.locator('#r1250Evidence').get_attribute('data-record-id'),row['recordId'])
                        self.assertFalse(page.locator('#f800Evidence').is_visible())
                        self.assertFalse(page.locator('#s1000rrEvidence').is_visible())
                        facts=page.locator('#r1250Evidence [data-reference-facts]')
                        target=row['identity']['year']==2020 and row['identity']['model']=='R1250GS Adventure'
                        self.assertEqual(facts.count(),1)
                        if target:
                            self.assertIn('lateral derecho',facts.inner_text())
                            if 'Keyless' in row['identity']['system']:
                                self.assertIn('CR2032',facts.inner_text())
                                self.assertIn('HUF5750',facts.inner_text())
                                self.assertIn('guardabarros',facts.inner_text())
                                self.assertIn('#page=76',facts.locator('a').evaluate_all("items=>items.map(a=>a.getAttribute('href')).join(' ')") )
                            else:
                                self.assertNotIn('CR2032',facts.inner_text())
                            pending=page.locator('#r1250Evidence [data-pending-claims]').inner_text()
                            self.assertNotIn('ubicacion:',pending)
                            if row['section']=='transponders':
                                self.assertIn('chip:',pending)
                                self.assertEqual(page.locator('#result').get_attribute('data-immo-restricted'),'true')
                        if row['section']=='transponders':
                            self.assertIn('Chip y programación no validados',page.locator('#status').inner_text())
                            self.assertEqual(page.locator('#gallery img').count(),0)
                            if 'Keyless'in row['identity']['system']:self.assertIn('rueda trasera',page.locator('#r1250Evidence').inner_text())
                page.set_viewport_size({'width':375,'height':812})
                self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
