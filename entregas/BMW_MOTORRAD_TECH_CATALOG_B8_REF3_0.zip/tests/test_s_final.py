"""S1000R/XR: retain variant separation, Keyless unknowns and CT transitions."""
import csv
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

PENDING='PENDIENTE_CONTRASTE_DOCUMENTAL'

class SFinalTests(unittest.TestCase):
    def test_provenance_variants_and_component_limits(self):
        review=json.loads((ROOT/'docs/s-final-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="sFinalEvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual((len(review['records']),len(sources),(len(observations)-len(review['bulkReferenceUpdate']['additionalObservationIds']))),(73,21,66))
        self.assertEqual(sum(s.get('retrieval',{}).get('type')=='.pdf'for s in sources.values()),19)
        pending=limited=homologation=specialist=mechanical_antenna_pending=ct=options=0
        for row in review['records']:
            ident=row['identity'];original=next(r for r in db[row['section']]if all(r[k]==v for k,v in ident.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            primary=sources[row['references'][0]['sourceId']];self.assertEqual(primary['models'],[ident['model']])
            self.assertTrue(primary['discovery']['indexEntries']);self.assertLessEqual(primary['editionYear'],ident['year'])
            self.assertEqual(row['b8Result'],original['result']);self.assertEqual(row['zipComparisonStatus'],'NO_CONTRASTADO_EN_ESTE_BLOQUE')
            if any(f.startswith('OPCION_DOCUMENTADA')for f in row['findings']):options+=1
            if ident['system']=='Conector CT':ct+=1;self.assertTrue(any('TRANSICION_CT'in f for f in row['findings']))
            for c in row['claims']:
                if c['topic']in['conector','mercado_equipamiento']:self.assertEqual(c['status'],PENDING)
                if 'Keyless'in ident['system']and c['topic']in['chip','modulo']:self.assertEqual(c['status'],PENDING)
                if c['topic']=='antena'and ident['system']=='Mecánica'and (ident['model']=='S1000R'and ident['year']>=2021 or ident['model']=='S1000XR'and ident['year']in[2022,2023]):
                    mechanical_antenna_pending+=1;self.assertEqual(c['status'],PENDING)
                    self.assertTrue(any('UBICACION_ANTENA_PENDIENTE'in f for f in row['findings']))
                if c['status']==PENDING:pending+=1
                else:
                    limited+=1;self.assertTrue(c['observations'])
                    if c['status']=='HOMOLOGACION_DOCUMENTADA_UNIDAD_PENDIENTE':
                        homologation+=1;self.assertEqual(ident['system'],'Mecánica');self.assertIn(c['topic'],['chip','modulo'])
                    if c['status']=='REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE':
                        specialist+=1;self.assertIn(c['topic'],['acceso','ubicacion']);self.assertLessEqual(ident['year'],2016)
                    else:self.assertEqual(c['sourceIds'],[primary['id']])
                for oid in c['observations']:
                    o=observations[oid];self.assertIn(o['sourceId'],c['sourceIds'])
                    self.assertEqual(o['documentSha256'],sources[o['sourceId']]['retrieval']['sha256'])
                    if 'Keyless'in ident['system']and c['topic']=='antena':
                        self.assertIn('-backup-',oid)
                        self.assertIn('detrás del asiento'if ident['model']=='S1000R'else'junto al depósito',o['scope'])
        self.assertEqual((pending,limited,homologation,specialist,mechanical_antenna_pending,ct,options),(182,158,20,10,8,4,30))
        self.assertEqual(sources['src-1b3e76f5c520b159']['documentEdition'],'S1000XR 09.2016, 3.1rd edition')
        for name,count in [('S_FINAL_AFIRMACIONES.csv',340),('S_FINAL_PENDIENTES.csv',182)]:
            with(ROOT/'docs'/name).open(encoding='utf-8-sig',newline='')as f:self.assertEqual(len(list(csv.DictReader(f))),count)

    def test_browser_all_selectable_variants(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/s-final-reconciliation.json').read_text())
                rows=[r for r in review['records']if r['identity']['system']!='Keyless (Emergencia)'];self.assertEqual(len(rows),60)
                select='''row=>{
                    setTab(row.section,{reset:true});
                    for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                    const declaration=document.getElementById('bmwSystemDeclaration');
                    const name=/keyless/i.test(row.identity.system)?'Keyless':/mecánica|ews/i.test(row.identity.system)?'Mecánica':null;
                    if(row.section==='transponders'&&!declaration.hidden&&name){
                      const b=[...declaration.querySelectorAll('button')].find(b=>b.textContent===name);if(b)b.click();
                    }
                    $('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));
                }'''
                for row in rows:
                    with self.subTest(record=row['recordId']):
                        page.evaluate(select,row)
                        panel=page.locator('#sFinalEvidence');self.assertTrue(panel.is_visible())
                        self.assertEqual(panel.get_attribute('data-record-id'),row['recordId'])
                        for other in ['f800Evidence','s1000rrEvidence','r1250Evidence','r1200Evidence','rTouringEvidence','ninetEvidence','rFinalEvidence','f750f850Evidence','f650f700Evidence','fFinalEvidence','kEvidence','cEvidence']:
                            self.assertFalse(page.locator('#'+other).is_visible())
                        if row['identity']['system']=='Conector CT':self.assertIn('TRANSICION_CT',panel.inner_text())
                        if row['section']=='transponders':
                            self.assertIn('Chip y programación no validados',page.locator('#status').inner_text());self.assertEqual(page.locator('#gallery img').count(),0)
                page.set_viewport_size({'width':375,'height':812});self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                old=next(r for r in json.loads((ROOT/'docs/s1000rr-reconciliation.json').read_text())['records']if r['section']=='diagnostico')
                page.evaluate(select,old)
                self.assertTrue(page.locator('#s1000rrEvidence').is_visible());self.assertFalse(page.locator('#sFinalEvidence').is_visible())
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
