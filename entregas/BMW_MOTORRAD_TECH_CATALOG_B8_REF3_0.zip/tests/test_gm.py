"""G/M closure: unknown ignition systems and G650 immobiliser remain unresolved."""
import csv
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

PENDING='PENDIENTE_CONTRASTE_DOCUMENTAL'

class GMTests(unittest.TestCase):
    def test_provenance_unknowns_and_edition_cutoffs(self):
        review=json.loads((ROOT/'docs/gm-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="gmEvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual((len(review['records']),len(sources),(len(observations)-len(review['bulkReferenceUpdate']['additionalObservationIds']))),(24,15,37))
        self.assertEqual(sum(s.get('retrieval',{}).get('type')=='.pdf'for s in sources.values()),12)
        pending=limited=specialist=unknowns=period_mismatch=0
        for row in review['records']:
            ident=row['identity'];original=next(r for r in db[row['section']]if all(r[k]==v for k,v in ident.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            primary=sources[row['references'][0]['sourceId']];self.assertEqual(primary['models'],[ident['model']]);self.assertTrue(primary['discovery']['indexEntries'])
            self.assertEqual(row['b8Result'],original['result']);self.assertEqual(row['zipComparisonStatus'],'NO_CONTRASTADO_EN_ESTE_BLOQUE')
            if ident['model']=='G650GS':self.assertTrue(any('INMOVILIZADOR_PENDIENTE'in f for f in row['findings']))
            else:
                unknowns+=1;self.assertEqual(ident['platform'],'POR VERIFICAR');self.assertEqual(ident['system'],'CONFIRMAR SISTEMA')
                self.assertTrue(any('MY2026_NO_ACREDITADO'in f for f in row['findings']))
                if ident['model'].startswith('M'):
                    manuals=[sources[ref['sourceId']]for ref in row['references']if sources[ref['sourceId']].get('retrieval',{}).get('type')=='.pdf']
                    self.assertEqual(len(manuals),2);self.assertTrue(any(s['editionYear']==2026 for s in manuals));self.assertTrue(all(ident['model']in s['models']for s in manuals))
            if any('DESFASE_PERIODO_EDICION'in f for f in row['findings']):period_mismatch+=1
            if row['section']=='transponders':self.assertTrue(all(c['status']==PENDING for c in row['claims']))
            for c in row['claims']:
                if c['topic']in['conector','mercado_equipamiento']:self.assertEqual(c['status'],PENDING)
                if c['status']==PENDING:pending+=1
                else:
                    limited+=1;self.assertIn(c['topic'],['acceso','ubicacion']);self.assertTrue(c['observations'])
                    if c['status']=='REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE':specialist+=1;self.assertEqual(ident['model'],'G650GS')
                for oid in c['observations']:
                    o=observations[oid];self.assertIn(o['sourceId'],c['sourceIds']);self.assertEqual(o['documentSha256'],sources[o['sourceId']]['retrieval']['sha256'])
                    if oid.endswith('-G650GS'):self.assertIn('no G650 X',o['locator'])
        self.assertEqual((pending,limited,specialist,unknowns,period_mismatch),(84,24,16,8,4))
        self.assertEqual(observations['src-276886ea540d8548-colophon-139']['pdfPage'],139)
        self.assertEqual(sources['src-a2bc7b2f451225e5']['documentEdition'],'G310R 02.2022, 2nd edition')
        for name,count in [('GM_AFIRMACIONES.csv',108),('GM_PENDIENTES.csv',84)]:
            with(ROOT/'docs'/name).open(encoding='utf-8-sig',newline='')as f:self.assertEqual(len(list(csv.DictReader(f))),count)

    def test_browser_all_selectable_variants(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/gm-reconciliation.json').read_text())
                rows=[r for r in review['records']if r['identity']['system']!='Keyless (Emergencia)'];self.assertEqual(len(rows),24)
                select='''row=>{
                    setTab(row.section,{reset:true});
                    for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                    const declaration=document.getElementById('bmwSystemDeclaration');
                    const name=/keyless/i.test(row.identity.system)?'Keyless':/mecánica|ews/i.test(row.identity.system)?'Mecánica':null;
                    if(row.section==='transponders'&&!declaration.hidden&&name){
                      const b=[...declaration.querySelectorAll('button')].find(b=>b.textContent===name);if(b)b.click();
                    }
                    $('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));
                }'''
                for row in rows:
                    with self.subTest(record=row['recordId']):
                        page.evaluate(select,row)
                        panel=page.locator('#gmEvidence');self.assertTrue(panel.is_visible())
                        self.assertEqual(panel.get_attribute('data-record-id'),row['recordId'])
                        for other in ['f800Evidence','s1000rrEvidence','r1250Evidence','r1200Evidence','rTouringEvidence','ninetEvidence','rFinalEvidence','f750f850Evidence','f650f700Evidence','fFinalEvidence','kEvidence','cEvidence','sFinalEvidence']:
                            self.assertFalse(page.locator('#'+other).is_visible())
                        if row['identity']['platform']=='POR VERIFICAR':self.assertIn('IDENTIDAD_POR_VERIFICAR',panel.inner_text())
                        if row['section']=='transponders':
                            self.assertIn('Chip y programación no validados',page.locator('#status').inner_text());self.assertEqual(page.locator('#gallery img').count(),0)
                page.set_viewport_size({'width':375,'height':812});self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                old=next(r for r in json.loads((ROOT/'docs/s1000rr-reconciliation.json').read_text())['records']if r['section']=='diagnostico')
                page.evaluate(select,old)
                self.assertTrue(page.locator('#s1000rrEvidence').is_visible());self.assertFalse(page.locator('#gmEvidence').is_visible())
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
