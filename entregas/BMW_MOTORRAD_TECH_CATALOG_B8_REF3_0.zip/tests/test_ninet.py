"""Variant-specific manuals and homologation must not erase the /5 platform conflict."""
import csv
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

PENDING='PENDIENTE_CONTRASTE_DOCUMENTAL'

class NineTTests(unittest.TestCase):
    def test_variant_provenance_homologation_and_conflicts(self):
        review=json.loads((ROOT/'docs/ninet-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="ninetEvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual(len(review['records']),70);self.assertEqual(len(sources),39);self.assertEqual((len(observations)-len(review['bulkReferenceUpdate']['additionalObservationIds'])),100)
        self.assertEqual(sum(s.get('retrieval',{}).get('type')=='.pdf'for s in sources.values()),34)
        self.assertEqual(sum(s['status']=='CITADA_SIN_VERIFICAR'for s in sources.values()),3)
        claims=0;pending=0;homologation=0;specialist=0;conflicted=0
        for row in review['records']:
            identity=row['identity'];self.assertNotEqual(identity['model'],'R 12 nineT')
            original=next(r for r in db[row['section']]if all(r[k]==v for k,v in identity.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            primary=sources[row['references'][0]['sourceId']]
            self.assertEqual(primary['model'],identity['model']);self.assertLessEqual(primary['editionYear'],identity['year'])
            self.assertTrue(primary['discovery']['indexEntries'])
            self.assertEqual(row['zipComparisonStatus'],'NO_CONTRASTADO_EN_ESTE_BLOQUE')
            if identity['model']=='R nineT /5':
                conflicted+=1;self.assertEqual(identity['platform'],'K21')
                self.assertTrue(any('CONFLICTO_PLATAFORMA'in f for f in row['findings']))
                self.assertTrue(any(e['model']['EW']=='K22'for e in primary['discovery']['indexEntries']))
                self.assertTrue(all(c['status']==PENDING for c in row['claims']))
            for c in row['claims']:
                claims+=1
                if c['topic']in['conector','mercado_equipamiento']:self.assertEqual(c['status'],PENDING)
                if c['status']==PENDING:pending+=1;continue
                self.assertTrue(c['observations'])
                if c['topic']in['chip','modulo']:
                    self.assertEqual(c['status'],'HOMOLOGACION_DOCUMENTADA_UNIDAD_PENDIENTE');homologation+=1
                if c['status']=='REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE':
                    specialist+=1;self.assertEqual(identity['model'],'R nineT');self.assertLessEqual(identity['year'],2016)
                    self.assertIn(c['topic'],['acceso','ubicacion'])
                else:self.assertEqual(c['sourceIds'],[primary['id']])
                for oid in c['observations']:
                    o=observations[oid];s=sources[o['sourceId']]
                    self.assertIn(o['sourceId'],c['sourceIds'])
                    self.assertEqual(o['documentSha256'],s['retrieval']['sha256'])
                    if c['topic']in['chip','modulo']:
                        self.assertIn('EWS4',o['scope']);self.assertIn('no identifica',o['scope'])
                    if identity['model']=='R nineT Racer'and c['topic']=='acceso':self.assertIn('colín',o['scope'])
        self.assertEqual((claims,pending,homologation,specialist,conflicted),(315,145,34,6,2))
        for name,count in [('NINET_AFIRMACIONES.csv',315),('NINET_PENDIENTES.csv',145)]:
            with(ROOT/'docs'/name).open(encoding='utf-8-sig',newline='')as f:rows=list(csv.DictReader(f))
            self.assertEqual(len(rows),count)

    def test_browser_all_variants_and_context_switch(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/ninet-reconciliation.json').read_text())
                select='''row=>{
                    setTab(row.section,{reset:true});
                    for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                    const declaration=document.getElementById('bmwSystemDeclaration');
                    if(row.section==='transponders'&&!declaration.hidden){
                      [...declaration.querySelectorAll('button')].find(b=>b.textContent==='Mecánica').click();
                    }
                    $('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));
                }'''
                for row in review['records']:
                    with self.subTest(record=row['recordId']):
                        page.evaluate(select,row)
                        self.assertTrue(page.locator('#ninetEvidence').is_visible())
                        self.assertEqual(page.locator('#ninetEvidence').get_attribute('data-record-id'),row['recordId'])
                        for panel in ['f800Evidence','s1000rrEvidence','r1250Evidence','r1200Evidence','rTouringEvidence']:
                            self.assertFalse(page.locator('#'+panel).is_visible())
                        text=page.locator('#ninetEvidence').inner_text()
                        if row['identity']['model']=='R nineT /5':self.assertIn('CONFLICTO_PLATAFORMA',text)
                        if row['section']=='transponders':
                            self.assertIn('Chip y programación no validados',page.locator('#status').inner_text());self.assertEqual(page.locator('#gallery img').count(),0)
                page.set_viewport_size({'width':375,'height':812})
                self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                old=next(r for r in json.loads((ROOT/'docs/r1250rt-r1300gs-reconciliation.json').read_text())['records']if r['section']=='diagnostico')
                page.evaluate(select,old)
                self.assertTrue(page.locator('#rTouringEvidence').is_visible());self.assertFalse(page.locator('#ninetEvidence').is_visible())
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
