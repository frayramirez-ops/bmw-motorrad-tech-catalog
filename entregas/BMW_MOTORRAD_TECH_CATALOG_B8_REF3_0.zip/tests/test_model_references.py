"""Bulk updates must retain source scope, exceptions and explicit missing information."""
import copy
import csv
import importlib.util
import json
import re
import subprocess
import sys
import unittest
from test_recovery import APP, ROOT

spec = importlib.util.spec_from_file_location('model_references', ROOT/'scripts/build_model_references.py')
builder = importlib.util.module_from_spec(spec); spec.loader.exec_module(builder)


class ModelReferenceTests(unittest.TestCase):
    def test_complete_matrix_provenance_and_location_changes(self):
        check = subprocess.run([sys.executable, str(ROOT/'scripts/build_model_references.py'), '--check'], capture_output=True, text=True)
        self.assertEqual(check.returncode, 0, check.stderr)
        matrix = json.loads((ROOT/'docs/model-reference-inventory.json').read_text())
        self.assertEqual(matrix['summary'], {
            'records':815, 'recordsWithReference':799, 'recordsWithBaseReference':757, 'recordsWithDiagnosticProfiles':789, 'recordsWithoutDocumentedFacts':16,
            'selectableRecordsWithReference':689, 'recordsWithKeyBattery':222,
            'recordsWithKeyRange':222, 'recordsWithFobHomologation':122,
            'diagnosticRecordsWithLocation':309,
        })
        self.assertEqual((ROOT/'docs/FICHAS_REFERENCIA_B8.csv').read_bytes(), (APP/'FICHAS_REFERENCIA_B8.csv').read_bytes())
        with (APP/'FICHAS_REFERENCIA_B8.csv').open(encoding='utf-8-sig',newline='') as f:
            rows=list(csv.DictReader(f))
        self.assertEqual(len(rows),815)
        self.assertEqual(len({r['identidad'] for r in rows}),815)
        self.assertEqual(sum(r['tiene_datos_documentados']=='NO' for r in rows),16)
        self.assertEqual({r['identity']['family'] for r in matrix['records']},set('CFGKMRS'))
        location_changes=0; primary=0; specialist=0; diagnostic=0; batteries=[]
        for filename in builder.REGISTRIES:
            review=json.loads((ROOT/'docs'/filename).read_text())
            observations={o['id']:o for o in review['observations']}
            sources={s['id']:s for s in review['sources']}
            meta=review['bulkReferenceUpdate']
            self.assertEqual(len(observations),meta['previousObservationCount']+len(meta['additionalObservationIds'])+len(review.get('diagnosticHardwareUpdate3',{}).get('additionalObservationIds',[])))
            for oid in meta['additionalObservationIds']:
                ob=observations[oid];source=sources[ob['sourceId']]
                self.assertEqual(ob['documentSha256'],source['retrieval']['sha256'])
                self.assertEqual(source['status'],'CONTENIDO_CONSULTADO')
                self.assertGreater(ob['pdfPage'],0)
                self.assertTrue(ob['normalizedExcerpt'])
            for change in meta['locationChanges']:
                location_changes+=1
                self.assertEqual(change['previousClaim']['status'],builder.PENDING)
                self.assertEqual(change['topic'],'ubicacion')
                if change['newStatus']=='REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE':specialist+=1
                else:primary+=1
            for row in review['records']:
                claims={c['topic']:c for c in row['claims']}
                if row['section']=='diagnostico':
                    diagnostic+=1
                    self.assertEqual(claims['ubicacion']['status']==builder.PENDING,claims['acceso']['status']==builder.PENDING)
                    if row['identity']['model'] in ('R 1100 R','R 1100 RS','R 1100 RT'):
                        self.assertEqual(claims['conector']['status'],'REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE')
                    else:self.assertEqual(claims['conector']['status'],builder.PENDING)
                    if claims['ubicacion']['status']=='REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE':
                        self.assertEqual(claims['ubicacion']['sourceIds'],claims['acceso']['sourceIds'])
                        self.assertEqual(claims['ubicacion']['observations'],claims['acceso']['observations'])
                facts=row.get('referenceFacts',{}).get('facts',[])
                if not facts:self.assertTrue(all(c['status']==builder.PENDING for c in row['claims']))
                for fact in facts:
                    builder.validate_fact(fact,observations,sources)
                    for field in fact['fields']:
                        if field in ('chip','modulo','conector','mercado_equipamiento'):
                            self.assertIn(claims[field]['status'],builder.DOCUMENTED)
                    if 'pila_mando' in fact['fields']:
                        self.assertIn('Keyless',row['identity']['system'])
                        code=re.search(r'CR\d{4}',fact['value'])[0];batteries.append((row['identity'],code))
                        if code=='CR1632':
                            self.assertEqual(row['identity']['model'],'R1250RT')
                            self.assertIn(row['identity']['year'],[2021,2022])
        self.assertEqual((location_changes,primary,specialist,diagnostic),(278,164,114,315))
        self.assertEqual(sum(code=='CR1632' for _,code in batteries),4)
        self.assertEqual(sum(code=='CR2032' for _,code in batteries),218)

    def test_pending_components_and_other_systems_cannot_be_filled_by_template(self):
        review=json.loads((ROOT/'docs/r1250gs-reconciliation.json').read_text())
        observations={o['id']:o for o in review['observations']};sources={s['id']:s for s in review['sources']}
        original=next(r for r in review['records']if r['identity']['year']==2020 and r['identity']['model']=='R1250GS Adventure' and r['identity']['system']=='Keyless (Principal)')
        row=copy.deepcopy(original);row['curatedReferenceFacts'][0]['fields']=['chip']
        with self.assertRaisesRegex(ValueError,'pending component'):builder.reference_for(row,observations,sources)
        row=copy.deepcopy(original);row['identity']['system']='Mecánica'
        with self.assertRaisesRegex(ValueError,'another selected system'):builder.reference_for(row,observations,sources)
        row=copy.deepcopy(original);oid=row['curatedReferenceFacts'][0]['observations'][0]
        bad_sources=copy.deepcopy(sources);bad_sources[observations[oid]['sourceId']]['status']='CITADA_SIN_VERIFICAR'
        with self.assertRaisesRegex(ValueError,'Unverified source'):builder.reference_for(row,observations,bad_sources)
