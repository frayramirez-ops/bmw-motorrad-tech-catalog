"""GS variants keep their own manuals; passive EWS certificates must not identify Keyless chips."""
import csv
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

PENDING='PENDIENTE_CONTRASTE_DOCUMENTAL'

class F750F850Tests(unittest.TestCase):
    def test_variant_sources_and_homologation_limits(self):
        review=json.loads((ROOT/'docs/f750-f850-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="f750f850EvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual((len(review['records']),len(sources),(len(observations)-len(review['bulkReferenceUpdate']['additionalObservationIds']))),(68,12,57))
        self.assertEqual(sum(s.get('retrieval',{}).get('type')=='.pdf'for s in sources.values()),11)
        claims=0;pending=0;homologation=0;keyless_pending=0
        for row in review['records']:
            ident=row['identity'];original=next(r for r in db[row['section']]if all(r[k]==v for k,v in ident.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            source=sources[row['references'][0]['sourceId']]
            self.assertEqual(source['model'],ident['model']);self.assertLessEqual(source['editionYear'],ident['year'])
            diag=[r for r in db['diagnostico']if all(r[k]==ident[k]for k in ['year','family','model','platform'])]
            self.assertEqual(len(diag),1);self.assertEqual(source['url'],diag[0]['diagnosticEvidence']['manual'])
            self.assertTrue(source['discovery']['indexEntries'])
            for c in row['claims']:
                claims+=1
                if c['topic']in['mercado_equipamiento','conector']:self.assertEqual(c['status'],PENDING)
                if c['topic']in['chip','modulo']:
                    if 'Keyless'in ident['system']:
                        self.assertEqual(c['status'],PENDING);keyless_pending+=1
                    elif ident['year']==2018:self.assertEqual(c['status'],PENDING)
                    else:
                        self.assertEqual(c['status'],'HOMOLOGACION_DOCUMENTADA_UNIDAD_PENDIENTE');homologation+=1
                if c['status']==PENDING:pending+=1;continue
                self.assertTrue(c['observations']);self.assertEqual(c['sourceIds'],[source['id']])
                for oid in c['observations']:
                    ob=observations[oid];self.assertEqual(ob['sourceId'],source['id'])
                    self.assertEqual(ob['documentSha256'],source['retrieval']['sha256'])
                    if 'Keyless'in ident['system']:
                        self.assertIn('bajo el asiento',ob['scope']);self.assertIn('-backup-',oid)
                    if c['topic']in['chip','modulo']:self.assertIn('no identifica',ob['scope'].lower().replace('sin identificar','no identifica'))
        self.assertEqual((claims,pending,homologation,keyless_pending),(323,157,30,68))
        for name,count in [('F750_F850_AFIRMACIONES.csv',323),('F750_F850_PENDIENTES.csv',157)]:
            with(ROOT/'docs'/name).open(encoding='utf-8-sig',newline='')as f:self.assertEqual(len(list(csv.DictReader(f))),count)

    def test_browser_all_selectable_variants(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/f750-f850-reconciliation.json').read_text())
                rows=[r for r in review['records']if r['identity']['system']!='Keyless (Emergencia)'];self.assertEqual(len(rows),51)
                select='''row=>{
                    setTab(row.section,{reset:true});
                    for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                    const declaration=document.getElementById('bmwSystemDeclaration');
                    if(row.section==='transponders'&&!declaration.hidden){
                      const name=row.identity.system.includes('Keyless')?'Keyless':'Mecánica';
                      [...declaration.querySelectorAll('button')].find(b=>b.textContent===name).click();
                    }
                    $('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));
                }'''
                for row in rows:
                    with self.subTest(record=row['recordId']):
                        page.evaluate(select,row)
                        panel=page.locator('#f750f850Evidence');self.assertTrue(panel.is_visible())
                        self.assertEqual(panel.get_attribute('data-record-id'),row['recordId'])
                        for other in ['f800Evidence','s1000rrEvidence','r1250Evidence','r1200Evidence','rTouringEvidence','ninetEvidence','rFinalEvidence']:
                            self.assertFalse(page.locator('#'+other).is_visible())
                        if row['section']=='transponders':
                            self.assertIn('Chip y programación no validados',page.locator('#status').inner_text());self.assertEqual(page.locator('#gallery img').count(),0)
                            if 'Keyless'in row['identity']['system']:self.assertIn('bajo el asiento',panel.inner_text())
                page.set_viewport_size({'width':375,'height':812});self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                old=next(r for r in json.loads((ROOT/'docs/r-final-reconciliation.json').read_text())['records']if r['section']=='diagnostico')
                page.evaluate(select,old)
                self.assertTrue(page.locator('#rFinalEvidence').is_visible());self.assertFalse(page.locator('#f750f850Evidence').is_visible())
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
