"""S1000RR: document evidence must not turn appendix certificates into Keyless fitment."""
import csv
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP, ROOT, QuietHandler

class S1000RRTests(unittest.TestCase):
    def test_registry_and_keyless_hypotheses(self):
        review=json.loads((ROOT/'docs/s1000rr-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="s1000EvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        self.assertEqual(len(review['records']),42)
        self.assertEqual(len(review['sources']),14)
        self.assertEqual((len(review['observations'])-len(review['bulkReferenceUpdate']['additionalObservationIds'])),25)
        self.assertEqual(len(review['withdrawnHypotheses']),4)
        observations={o['id']:o for o in review['observations']}
        sources={s['id']:s for s in review['sources']}
        historical=[]
        claims=0
        documented=0
        for row in review['records']:
            record=next(r for r in db[row['section']] if all(r[k]==v for k,v in row['identity'].items()))
            digest=hashlib.sha256(json.dumps(record,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
            self.assertEqual(digest,row['b8RecordSha256'])
            if row['status']=='HIPOTESIS_NO_ACREDITADA':
                historical.append(row)
                self.assertTrue(row['findings'])
                self.assertTrue(all(c['status']=='PENDIENTE_CONTRASTE_DOCUMENTAL' for c in row['claims']))
            for claim in row['claims']:
                claims+=1
                if claim['status']=='PENDIENTE_CONTRASTE_DOCUMENTAL':continue
                documented+=1
                self.assertTrue(claim['observations'])
                for id in claim['observations']:
                    ob=observations[id]
                    self.assertEqual(ob['documentSha256'],sources[ob['sourceId']]['retrieval']['sha256'])
        self.assertEqual(len(historical),8)
        self.assertEqual(claims,193)
        self.assertEqual(documented,82)

    def test_chronology_and_homologation_limits(self):
        review=json.loads((ROOT/'docs/s1000rr-reconciliation.json').read_text())
        rows=review['records']
        row=next(r for r in rows if r['section']=='transponders' and r['identity']['year']==2014 and r['identity']['system']=='Mecánica')
        self.assertTrue(any('07.2015' in text for text in row['findings']))
        for claim in row['claims']:
            self.assertEqual(claim['status'],'DOCUMENTADO_EN_EDICION_APLICABILIDAD_PENDIENTE'if claim['topic']in['sistema','antena']else'PENDIENTE_CONTRASTE_DOCUMENTAL')
        self.assertTrue(row['temporalEvidence'])
        for row in rows:
            if row['section']=='transponders' and 2013<=row['identity']['year']<=2018:
                for claim in row['claims']:
                    if claim['topic'] in ['chip','modulo']:
                        self.assertEqual(claim['status'],'PENDIENTE_CONTRASTE_DOCUMENTAL')
        with (ROOT/'docs/S1000RR_PENDIENTES.csv').open(encoding='utf-8-sig',newline='') as f:
            pending=list(csv.DictReader(f))
        self.assertEqual(len(pending),111)
        self.assertEqual(len({(r['identidad'],r['afirmacion']) for r in pending}),111)
        self.assertEqual({(r['identidad'],r['afirmacion']) for r in pending},
          {(r['recordId'],c['topic']) for r in rows for c in r['claims'] if c['status']=='PENDIENTE_CONTRASTE_DOCUMENTAL'})

    def test_browser_keeps_keyless_unconfirmed(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright() as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(5000)
                errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                page.click('[data-tab="transponders"]')
                for id,value in [('year','2023'),('family','S'),('model','S1000RR'),('platform','K67 11')]:page.select_option('#'+id,value)
                page.locator('#bmwSystemDeclaration button').filter(has_text='Keyless').click()
                self.assertTrue(page.locator('#s1000rrEvidence').is_visible())
                self.assertIn('Hipótesis Keyless no acreditada',page.locator('#s1000rrEvidence').inner_text())
                self.assertFalse(page.locator('#f800Evidence').is_visible())
                self.assertEqual(page.locator('#gallery img').count(),0)
                self.assertEqual(page.evaluate('auditRuleFor(sourceRows().find(r=>r.year===2023&&r.model==="S1000RR"&&r.system==="Keyless (Principal)")).control'),'VINCULO_AUDITORIA_PENDIENTE')
                page.locator('#bmwSystemDeclaration button').filter(has_text='Mecánica').click()
                self.assertIn('antena anular en la cerradura',page.locator('#s1000rrEvidence').inner_text())
                self.assertNotIn('Hipótesis Keyless no acreditada',page.locator('#s1000rrEvidence').inner_text())
                self.assertEqual(errors,[])
                browser.close()
        finally:
            server.shutdown();server.server_close()
