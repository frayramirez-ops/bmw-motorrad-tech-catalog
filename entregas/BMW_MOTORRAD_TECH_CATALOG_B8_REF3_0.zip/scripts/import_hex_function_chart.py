"""Import factual HEX diagnostic profile rows from an already downloaded manufacturer page."""
from html.parser import HTMLParser
from pathlib import Path
import argparse
import hashlib
import json
import re

class Chart(HTMLParser):
 def __init__(self):super().__init__();self.row=None;self.cell=None;self.rows=[]
 def handle_starttag(self,t,a):
  a=dict(a)
  if t=='tr':self.row=[]
  if t in ('td','th') and self.row is not None:self.cell={'tag':t,'text':[],'ids':[],'links':[],'images':[]}
  if self.cell is not None:
   if t=='a':
    if a.get('id'):self.cell['ids'].append(a['id'])
    if a.get('href'):self.cell['links'].append(a['href'])
   if t=='img':self.cell['images'].append(a)
 def handle_data(self,s):
  if self.cell is not None:self.cell['text'].append(s)
 def handle_endtag(self,t):
  if t in ('td','th') and self.cell is not None:
   self.cell['text']=' '.join(' '.join(self.cell['text']).replace('\xad','').split());self.row.append(self.cell);self.cell=None
  if t=='tr' and self.row is not None:self.rows.append(self.row);self.row=None

def import_profiles(html):
    parser=Chart();parser.feed(html);profiles=[];active=None
    for row in parser.rows:
        if not row:continue
        anchors=[x for x in row[0]['ids'] if re.match(r'^(X001|K001|K024|K1X|3P)_',x)]
        if anchors:
            active={'id':anchors[0],'aliases':row[0]['ids'],'heading':row[0]['text'].replace('Diagnostic Port','').strip(),'controllers':[],'group':anchors[0].split('_')[0]};profiles.append(active)
        elif active and row[0]['tag']=='td':
            text=row[0]['text'];links=row[0]['links']
            if text and not text.startswith('Vehicle Functions'):
                active['controllers'].append({'description':text,'codes':[x for x in links if re.fullmatch(r'[A-Za-z0-9-]+',x)],'capabilities':[c['text'] for c in row[1:]]})
    if len(profiles)<100 or len({p['id'] for p in profiles})!=len(profiles):raise ValueError('Incomplete or duplicate source profiles')
    return profiles


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--html',required=True,type=Path);parser.add_argument('--check-data',required=True,type=Path);args=parser.parse_args()
    raw=args.html.read_bytes();expected=json.loads(args.check_data.read_text())
    if hashlib.sha256(raw).hexdigest()!=expected['source']['sha256']:raise ValueError('Manufacturer snapshot hash differs')
    profiles=import_profiles(raw.decode())
    if profiles!=expected['profiles']:raise ValueError('Normalized source data does not match downloaded table')
    print(str(len(profiles))+' perfiles y hash de fuente verificados.')

if __name__=='__main__':main()
