"""Bind published HEX diagnostic profiles to B8 identities without assigning installed hardware."""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import unicodedata

ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'BMW_Motorrad_B8_REGENERADO'
ALIASES={
 'F800GS798CC':'F800GS','F800GS895CC':'F800GS','F900GSADVENTURE':'F900GSA',
 'R1300GSADVENTURE':'R1300GSA','K1600B':'K1600BAGGER',
 'F650GSMONOCILINDRICA':'F650GS','F650GSBICILINDRICA798CC':'F650GS800CC2CYL',
 'K1200GTK41':'K1200GT','K1200GTK44':'K1200GT',
}

def normalize(value):
    value=unicodedata.normalize('NFD',value).replace('\xad','')
    return re.sub('[^A-Z0-9]','',value.upper())

def platforms(value):
    return set(re.findall(r'\b(?:K[A-Z]?\d{1,3}|R\d{2}|259[A-Z]?)\b',value.upper()))

def parse_profile(profile):
    result=dict(profile)
    heading=profile['heading'];start=heading.rfind('(');end=heading.rfind(')')
    if start<0 or end<start:raise ValueError('Unparseable heading: '+heading)
    model=heading[:start].strip();period=heading[end+1:].strip()
    model=re.sub(r'\s*(?:\(non-CAN\)|2 spark)\s*',' ',model,flags=re.I).strip()
    model=re.sub(r'\s+LC$','',model,flags=re.I)
    years=[int(v) for v in re.findall(r'(?:19|20)\d{2}',period)]
    if not years:raise ValueError('Missing profile period: '+heading)
    result.update(modelKey=normalize(model),platforms=sorted(platforms(heading[start+1:end])),period=period,
                  startYear=years[0],endYear=(years[-1] if len(years)>1 else None if '+' in period else years[0]),
                  monthBoundary=bool(re.search('[A-Za-z]',period)))
    return result

def record_profiles(row,source_by_id,profiles):
    identity=row['identity']
    if row['status']=='HIPOTESIS_NO_ACREDITADA':return [],'HIPOTESIS_NO_ACREDITADA'
    key=normalize(identity['model']);key=ALIASES.get(key,key)
    candidates=[p for p in profiles if p['modelKey']==key and p['startYear']<=identity['year'] and (p['endYear'] is None or identity['year']<=p['endYear'])]
    if not candidates:return [],'SIN_COINCIDENCIA_DE_MODELO_Y_PERIODO'
    original_platforms=platforms(identity['platform'])
    if original_platforms:
        candidates=[p for p in candidates if original_platforms & set(p['platforms'])]
        authority='PLATAFORMA_B8_Y_PERIODO'
        if not candidates:return [],'PLATAFORMA_NO_COINCIDE'
    else:
        nominal={tuple(p['platforms']) for p in candidates}
        if len(nominal)!=1:return [],'PLATAFORMA_NOMINAL_AMBIGUA'
        authority='REFERENCIA_NOMINAL_MODELO_PERIODO_NO_VIN'
    # Use the manual's type code to distinguish competing published profiles,
    # without interpreting it as a VIN or changing the immutable B8 platform.
    types=set()
    for ref in row['references']:
        source=source_by_id.get(ref['sourceId'],{})
        if source.get('status')!='CONTENIDO_CONSULTADO':continue
        match=re.search(r'/[A-Z]_([0-9A-Z]{4})_',source.get('url',''))
        if match:types.add(match[1])
    narrowed=[p for p in candidates if types & set(p['aliases'])]
    if len(candidates)>1 and narrowed:
        candidates=narrowed;authority+='; TIPO_DOCUMENTAL_DEL_MANUAL'
    return candidates,authority

def profile_values(profiles,groups,system):
    fields={};engine=[];access=[]
    for p in profiles:
        engine_rows=[c for c in p['controllers'] if c['description'].startswith('Engine Controller ')]
        access_rows=[c for c in p['controllers'] if re.search(r'Keyless|Immobilizer',c['description'],re.I)]
        if system=='Mecánica':access_rows=[c for c in access_rows if 'Immobilizer' in c['description']]
        elif re.search(r'VERIFICAR|CONFIRMAR',system,re.I):access_rows=[]
        engine.append((p,[c['description'].removeprefix('Engine Controller ') for c in engine_rows]))
        access.append((p,[c['description'] for c in access_rows]))
    def summarize(values,label):
        present=[(p,items) for p,items in values if items]
        if not present:return None
        distinct={tuple(items) for _,items in present}
        if len(present)==len(values) and len(distinct)==1:
            return label+': '+', '.join(present[0][1])+'. La tabla agrupa '+ '; '.join(p['heading'] for p,_ in present)+'. Son nombres de la tabla de soporte HEX, no identifican la ECU física, variante o número de parte de una unidad.'
        return 'Alternativas publicadas; no seleccionar una por el año solo: '+'; '.join(p['heading']+' → '+', '.join(items) for p,items in present)+'. Contrastar tipo/fecha y equipamiento; no identifica pieza instalada.'
    engine_value=summarize(engine,'Perfil de diagnóstico del motor listado')
    access_value=summarize(access,'Perfil de acceso/inmovilizador listado')
    if engine_value:fields['perfil_motor']=engine_value
    if access_value:fields['perfil_acceso']=access_value+' La etiqueta «Immobilizer / Keyless Ride» no demuestra que la moto equipe Keyless ni identifica el semiconductor.'
    families=sorted({p['group'] for p in profiles})
    fields['arquitectura_diagnostico']='; '.join(group+': '+groups[group]['bus'] for group in families)+' Esta clasificación no determina por sí sola contactos, adaptador ni funciones de programación de llaves.'
    fields['software_diagnostico']='; '.join(dict.fromkeys(groups[g]['software'] for g in families))+'. Referencia de diagnóstico, no garantía de funciones para todo equipamiento.'
    if families==['3P']:fields['formato_documental']='HEX clasifica estos perfiles en «3-pin models»: diagnóstico legado de tres pines. No equiparar el código histórico C10 a este formato ni asumir un adaptador OBD-II.'
    fields['plataforma_documental']='; '.join(dict.fromkeys(p['heading'] for p in profiles))+'. Alcance publicado por HEX; no modifica la identidad ni certifica el año-modelo de una unidad.'
    return fields

def outputs():
    source_path=ROOT/'docs/hex-function-chart-data.json';source=json.loads(source_path.read_text())
    if source['source']['statusLabel']!='CONTENIDO_CONSULTADO':raise ValueError('Unverified chart')
    profiles=[parse_profile(p) for p in source['profiles']]
    if len({p['id'] for p in profiles})!=len(profiles):raise ValueError('Duplicate chart profile')
    bindings=[]
    for path in sorted((ROOT/'docs').glob('*-reconciliation.json')):
        review=json.loads(path.read_text());source_by_id={s['id']:s for s in review['sources']}
        for row in review['records']:
            matched,authority=record_profiles(row,source_by_id,profiles)
            bindings.append({'recordId':row['recordId'],'section':row['section'],'identity':row['identity'],
                'profileIds':[p['id'] for p in matched],'matchAuthority':authority,
                'monthBoundary':any(p['monthBoundary'] for p in matched),'fields':profile_values(matched,source['groups'],row['identity']['system']) if matched else {},
                'scope':'Referencias de diagnóstico del fabricante de la herramienta. No identifican chip, fabricante o pieza instalada ni confirman un sistema Keyless hipotético.'})
    bindings.sort(key=lambda r:r['recordId'])
    if len(bindings)!=815 or len({r['recordId'] for r in bindings})!=815:raise ValueError('Incomplete B8 bindings')
    matched=[r for r in bindings if r['profileIds']]
    summary={'records':len(bindings),'recordsWithDiagnosticProfiles':len(matched),
        'selectableRecordsWithDiagnosticProfiles':sum(r['identity']['system']!='Keyless (Emergencia)' for r in matched),
        'recordsWithEngineProfile':sum('perfil_motor' in r['fields'] for r in matched),
        'recordsWithAccessProfile':sum('perfil_acceso' in r['fields'] for r in matched),
        'recordsWithoutProfile':len(bindings)-len(matched)}
    report={'schema':1,'source':source['source'],'sourceInputSha256':hashlib.sha256(source_path.read_bytes()).hexdigest(),
        'summary':summary,'groups':source['groups'],'profiles':profiles,'records':bindings}
    payload=json.dumps(report,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
    return {ROOT/'docs/diagnostic-profile-bindings.json':json.dumps(report,ensure_ascii=False,indent=2)+'\n',
        APP/'diagnostic-profile-data.js':'/* Generated diagnostic references; not installed hardware or programming approval. */\nwindow.BMW_DIAGNOSTIC_PROFILES='+payload+';\n'},summary

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check',action='store_true');args=parser.parse_args()
    files,summary=outputs();stale=[]
    for path,text in files.items():
        if path.exists() and path.read_bytes()==text.encode():continue
        if args.check:stale.append(str(path.relative_to(ROOT)))
        else:path.write_bytes(text.encode())
    if stale:parser.exit(1,'Perfiles obsoletos: '+', '.join(stale)+'\n')
    print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
