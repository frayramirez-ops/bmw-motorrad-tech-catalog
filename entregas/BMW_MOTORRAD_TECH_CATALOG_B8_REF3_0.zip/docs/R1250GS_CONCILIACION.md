# R1250GS y Adventure — primer bloque de la familia R

> **Estado de datos B8-REF2.0:** 44 fichas, 209 afirmaciones, 102 con respaldo limitado y 107 pendientes. El cuerpo de este informe conserva el recorrido histórico y sus cifras de cada etapa; para el bloque y los campos vigentes consultar `ACTUALIZACION_TRANSVERSAL_REF2.md`, `r1250gs-reconciliation.json` y `FICHAS_REFERENCIA_B8.csv`.

## Alcance

44 fichas B8: 33 transponders y 11 diagnóstico. GS estándar contiene cinco años (2019–2023); Adventure seis (2019–2024). No se añade una GS estándar 2024 por analogía ni se acredita cobertura mundial por mercado.

La conciliación se registra en `r1250gs-reconciliation.json`, con una copia idéntica en el HTML y panel contextual propio. Cada fila conserva identidad y hash B8, resultados equivalentes del ZIP y variantes relacionadas sin fusionarlas. Los nombres largos de sistema del ZIP no se convierten automáticamente en equivalencias de las filas de B8.

209 afirmaciones inventariadas: **102 con respaldo limitado (48,8 %)** —88 de edición y 14 de homologación— y **107 pendientes**. Son afirmaciones de este bloque, no porcentajes de producción o de finalización del proyecto. Ninguna certifica un VIN.

## Documentos consultados

Nueve PDF oficiales (los ocho iniciales y el manual propio en español de Adventure 01.2019) y un índice oficial de modelos/periodos. Las observaciones usan página PDF para evitar deducir numeración impresa donde no se verificó.

| Modelo / edición impresa | EWS mecánico | Emergencia Keyless | Acceso diagnóstico | Homologación TMS37145 |
|---|---:|---:|---:|---:|
| GS 01.2019, 2.ª | 65 | 69 | 202 | No contrastada |
| Adventure 01.2019, 2.ª | 65 | 69 | 202 | No contrastada |
| GS 06.2020, 1.ª | 67 | 70 | 211 | 281 |
| Adventure 06.2020, 1.ª | 67 | 70 | 212 | 277 |
| GS 03.2021, 2.ª | 69 | 72 | 215 | 285 |
| Adventure 03.2021, 2.ª | 69 | 72 | 215 | 281 |
| GS 04.2022, 3.ª | 71 | 75 | 227 | 304 |
| Adventure 04/2023, 4.ª | 89 | 93 | 220 | 291 |

Los documentos 06.2020 tienen material adicional multilingüe después del colofón; la fecha de edición se comprobó en el texto del documento, no por su nombre. B8 puede usar una edición anterior al año de la ficha: se conserva como referencia de edición, no certificación de todos los MY.

## Hallazgos y límites

- Las ediciones de ambos modelos describen llave mecánica/EWS y modalidades Keyless. Esa coexistencia documental no acredita que todas las opciones se comercializaran en México, USA o ROW, ni que una unidad las equipe.
- En Mecánica se describe antena anular en la cerradura de encendido.
- Para emergencia Keyless, el manual indica contacto de la llave o mando sin pila con la cubierta de la rueda trasera a la altura de la antena. No se traslada la ubicación bajo asiento documentada en otras familias. La llave de emergencia es una modalidad del Keyless, no una tercera arquitectura instalada.
- El apéndice técnico posterior cita TMS37145/DST80 y TMS3705. No se extiende al semiconductor del mando Keyless ni acredita el módulo instalado en un VIN. Las 22 afirmaciones de chip y 22 de módulo de las filas Keyless permanecen pendientes; no se asigna HUF/8A por el nombre del sistema.
- El acceso diagnóstico se describe retirando cubierta de batería y liberando gancho/seguros del soporte. No se certifica forma/contactos C16 ni ubicación exacta de una unidad sin evidencia suficiente.
- El ZIP desarrolla alternativas mecánicas condicionadas al equipamiento/VIN. No se interpreta que Mecánica sea imposible en todos los mercados, ni universal en México.
- GS y Adventure se vinculan exclusivamente a sus documentos propios. No se trasladan las ubicaciones ni fechas entre modelos por semejanza.

`R1250GS_AFIRMACIONES.csv` contiene las 209 afirmaciones; `R1250GS_PENDIENTES.csv` las 107 aún sin evidencia aplicable suficiente. Los códigos F permanecen sin equivalencia demostrada.

## Aplicación y validación

Se reutiliza el panel documental manteniendo cada identidad/sección. `catalogData`, CSV original y reglas de liberación permanecen intactos. La cobertura global suma las 44 fichas conciliadas sin denominarlas aprobadas.

Las dos pruebas nuevas comprueban hashes y fuentes por modelo, 209 afirmaciones y 49 observaciones, conservación de pendientes Keyless/mercado/conector/ubicación y las 33 consultas seleccionables. Once entradas históricas de emergencia se conservan en el registro pero no se ofrecen como sistemas independientes. La prueba móvil cubre un estado de 375 px, no toda la interfaz ni todas las imágenes.

No se publicó ni desplegó este bloque.

## Actualización de referencia B8-REF1.1 — 6 de noviembre de 2026

Se corrige un pendiente excesivo: las once afirmaciones de ubicación de GS/Adventure pasan a documentadas en su edición propia. Las ocho obras originales dicen explícitamente «vista general del lado derecho» y sitúan el enchufe detrás del revestimiento lateral. Se conserva el estado anterior por identidad en `referenceUpdate11.claimChanges`. Esta ubicación documental no certifica contactos ni adaptador.

La Adventure 2020 K51 11 incorpora una ficha visible con datos concretos y enlaces por página del manual español: Keyless Ride opcional, pila CR2032, alcance aproximado de 1 m, antena de emergencia en el guardabarros trasero y mando HUF5750 citado en el certificado. Las alternativas de giro y diagnóstico tienen su propio contenido; no se muestra una pila Keyless como dato de una llave mecánica.

El índice OEM distingue K51 11/0J51 (desde 03/2019) de K51 MU2/0M11 (desde 08/2020, obra 06.2020). Se evita elegir manual solo por el «2020» del nombre. Esto no adjudica año-modelo, mercado mexicano ni equipamiento a una unidad.

Siguen pendientes semiconductor, referencia del módulo, contactos y mercado donde no existe evidencia aplicable. HUF5750 es un mando del certificado; no se convierte en módulo X_SLZ, chip 8A/AES128 ni lectura por VIN. Véase `ACTUALIZACION_R1250GSA_2020.md`.
