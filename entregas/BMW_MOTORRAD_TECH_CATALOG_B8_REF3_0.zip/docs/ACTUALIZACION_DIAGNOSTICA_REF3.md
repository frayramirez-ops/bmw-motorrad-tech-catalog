# B8-REF3.0 — arquitectura y perfiles de diagnóstico por lotes

Se añade una fuente estructurada del fabricante de herramienta HEX para avanzar por grupos completos. No se convierte su tabla de soporte en una identificación de hardware instalado. La entrega mantiene el modelo de referencia y sus límites de evidencia.

## Resultado

- 159 perfiles de la tabla pública normalizados con su SHA-256; 789 fichas coinciden por modelo, plataforma y periodo, incluidas 680 selecciones visibles. Las otras 26 no se completan por similitud ni por extender los años de una tabla.
- 789 fichas incorporan el perfil de motor, la clasificación publicada de redes/puerto y el software de diagnóstico indicado. 412 incorporan una referencia de acceso/inmovilizador compatible con el contexto seleccionado; un perfil exclusivamente Keyless no se añade a una selección mecánica.
- Al combinar estos datos con REF2, 799 entradas tienen alguna referencia documental (689 seleccionables) y 16 no disponen de datos suficientes. Estas cifras incluyen registros históricos de emergencia; no son modelos distintos ni certificaciones por VIN.
- Tres fichas de diagnóstico de R1100R, R1100RS y R1100RT 2001 pasan a formato de referencia de tres pines según la categoría explícita «3-pin models». No se extiende a R1100S o R1150. El código C10 de B8 permanece como identidad histórica; el resultado principal explica que no acredita el formato real.
- La matriz CSV existente incluye los campos nuevos. La consulta principal de diagnóstico incorpora arquitectura y perfil de motor, además del resumen documental por ficha.

## Qué significa un perfil HEX

Nombres como XBMSO1, XSLZ, XSLZ03, XSLZ4 y XEWS4 son denominaciones de la tabla de diagnóstico. No bastan para identificar fabricante, PN, semiconductor, frecuencia o configuración de una unidad. Las filas pueden agrupar varios años y equipamientos; por ejemplo, la tabla de F800GS K72 agrupa 2007–2018. No se asigna una ECU física a cada año a partir de esa fila amplia.

La etiqueta genérica «Immobilizer / Keyless Ride» no confirma la opción Keyless. Las ocho hipótesis S1000RR siguen sin acreditar y quedan fuera del cruce automático. Los 1000 contenidos de afirmaciones de chip/módulo existentes en REF2 (500 de cada tema) permanecen idénticos; la huella se comprueba en las pruebas. La nueva fuente no se utiliza para cerrar esos componentes pendientes.

## Cruce y excepciones

Se normalizan alias explícitos: F800GS 798/895 se distinguen por K72/K80; K1200GT K41/K44 conserva plataformas; la etiqueta LC de R1200GS se cruza con K50/K51 y no se confunde con K25 en años de transición. Los intervalos con mes o solapamientos se conservan y solo se acotan por el tipo documental cuando ese tipo figura en las anclas del fabricante.

Si B8 no identifica plataforma, solo se ofrece una referencia nominal cuando el modelo/periodo remite a una plataforma no ambigua; no cambia la plataforma original ni se presenta como lectura de la unidad. Un intervalo cerrado no se extiende: R1250GS Adventure 2024 conserva su documentación OEM de REF2, pero no recibe por copia el perfil que HEX titula 2019–2023.

## Fuente y reproducción

Fuente: https://www.hexgs911.com/function-chart/ — consultada el 7 de noviembre de 2026. El HTML completo se conserva como evidencia externa, sin cargar sus scripts ni redistribuir la página. El catálogo incluye la tabla factual normalizada, su huella y enlaces al modelo correspondiente.

`hex-function-chart-data.json` es la fuente normalizada; `diagnostic-profile-bindings.json` conserva cada vínculo y la causa de exclusión. El importador permite cotejar tabla y hash contra la captura. Ejecutar, en orden: `build_diagnostic_profiles.py`, `build_model_references.py`, `build_coverage.py`; usar `--check` en los tres para detectar salidas obsoletas.

Los resultados de ejecución están en `VALIDACION_BLOQUE_3.json` y `VALIDACION_ENTREGA_BLOQUE_3.json`. La arquitectura de comunicación no determina por sí sola formato/contactos, adaptador o programación de llaves. Fuera de las tres categorías explícitas de formato, los contactos y componentes sin evidencia conservan su estado pendiente.
