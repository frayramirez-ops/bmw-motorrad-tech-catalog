# R nineT y variantes — revisión por modelo y edición

> **Estado de datos B8-REF2.0:** 70 fichas, 315 afirmaciones, 170 con respaldo limitado y 145 pendientes. El cuerpo de este informe conserva el recorrido histórico y sus cifras de cada etapa; para el bloque y los campos vigentes consultar `ACTUALIZACION_TRANSVERSAL_REF2.md`, `ninet-reconciliation.json` y `FICHAS_REFERENCIA_B8.csv`.

## Alcance

70 fichas B8: 35 transponders y 35 diagnóstico, todas seleccionables. Incluye R nineT (20), Pure (14), Scrambler (14), Urban G/S (14), Racer (seis) y /5 (dos). R 12 nineT pertenece a otro modelo y permanece fuera de este bloque. No se agregan años o variantes para completar un padrón de producción.

`ninet-reconciliation.json` conserva identidad, hash y resultado histórico de cada ficha. Hay una copia idéntica embebida en B8 y un panel contextual. Los CSV `NINET_AFIRMACIONES.csv` y `NINET_PENDIENTES.csv` contienen 315 afirmaciones y las 179 pendientes, respectivamente. No se compararon resultados del ZIP: listas vacías no acreditan ausencia histórica.

136 afirmaciones tienen respaldo limitado: 99 de edición, 34 de homologación y tres de especialista. Ninguna certifica un VIN. Las dos fichas /5 conservan sus nueve afirmaciones pendientes hasta resolver la plataforma. Tener revisión detallada no significa aprobación.

## Fuentes y observaciones

39 fuentes: 34 PDF oficiales, índice oficial y guía HEX consultados, más tres enlaces históricos de repuestos/ManualsLib sin verificar. Son 100 observaciones con alcance y hash; las de PDF conservan página PDF y dejan la impresa en null. El índice se obtuvo de `https://manuals.bmw-motorrad.com/manuals/BA-Extern/IN/BA-INTERNET-COM/01/Nav.xml`; cada fuente primaria conserva sus entradas por archivo/periodo/plataforma. Los periodos no certifican el año-modelo ni un mercado.

| Modelo en portada | Edición según colofón | EWS, PDF | Acceso diagnóstico, PDF | Homologación EWS4, PDF |
|---|---|---:|---|---|
| R nineT | 07.2013, 1st edition, 01 | 33 | No usado | No usado |
| R nineT | 08.2014, 2nd edition, 01 | 33 | No usado | No usado |
| R nineT | 08.2015, 3rd edition, 01 | 33 | No usado | No usado |
| R nineT | 02.2019, 6th edition, 01 | 41 | 123 | 184 |
| R nineT | 04.2018, 5th edition, 01 | 41 | 123 | No usado |
| R nineT | 07.2017, 4th edition, 01 | 37 | 119 | No usado |
| R nineT /5 | 03.2019, 1st edition, 01 | 41 | 111 | 162 |
| R nineT Pure | 04.2018, 3rd edition, 01 | 41 | 119,120 | No usado |
| R nineT Pure | 07.2017, 2nd edition, 01 | 37 | 111 | No usado |
| R nineT Pure | 10.2016, 1st edition, 01 | 37 | 105 | No usado |
| R nineT Racer | 04.2018, 3rd edition, 01 | 41 | 120 | No usado |
| R nineT Racer | 07.2017, 2nd edition, 01 | 37 | 114 | No usado |
| R nineT Racer | 09.2016, 1st edition, 01 | 37 | 110 | No usado |
| R nineT Scrambler | 02.2019, 5th edition, 01 | 41 | 117,118 | 170 |
| R nineT Scrambler | 04.2018, 4th edition, 01 | 41 | 117,118 | No usado |
| R nineT Scrambler | 07.2017, 3rd edition, 01 | 37 | 111 | No usado |
| R nineT Scrambler | 10.2016, 2nd edition, 01 | 37 | 105,106 | No usado |
| R nineT Urban G/S | 02.2019, 4th edition, 01 | 41 | 118,119 | 170 |
| R nineT Urban G/S | 04.2018, 3rd edition, 01 | 41 | 116,117 | No usado |
| R nineT Urban G/S | 07.2017, 2nd edition, 01 | 37 | 110 | No usado |
| R nineT Urban G/S | 12.2016, 1st edition, 01 | 37 | 106 | No usado |
| R nineT | 01.2022, 3rd edition, 01 | 45 | 139 | 202 |
| R nineT | 04.2021, 2nd edition, 01 | 45 | 138,139 | 195 |
| R nineT | 06.2020, 1st edition, 01 | 45 | 141,142 | 201 |
| R nineT Pure | 01.2022, 3rd edition, 01 | 45 | 132,133 | 194 |
| R nineT Pure | 04.2021, 2nd edition, 01 | 45 | 130,131 | 189 |
| R nineT Pure | 06.2020, 1st edition, 01 | 45 | 134 | 193 |
| R nineT Scrambler | 01.2022, 3rd edition, 01 | 45 | 132,133 | 188 |
| R nineT Scrambler | 04.2021, 2nd edition, 01 | 45 | 130,131 | 179 |
| R nineT Scrambler | 06.2020, 1st edition, 01 | 45 | 133,134 | 185 |
| R nineT Urban G/S | 01.2022, 3rd edition, 01 | 45 | 132,133 | 188 |
| R nineT Urban G/S | 04.2021, 2nd edition, 01 | 45 | 130,131 | 179 |
| R nineT Urban G/S | 06.2020, 1st edition, 01 | 45 | 133,134 | 183 |
| R nineT Pure | 02.2019, 4th edition, 01 | 41 | 119,120 | 178 |

«No usado» indica ausencia de evidencia utilizada en este bloque, sin afirmar que la función no exista. Se comprobó el contenido de portada y colofón: el archivo Racer denominado 1016 tiene edición impresa 09.2016. La fecha no se obtiene únicamente del nombre del archivo.

## Hallazgos

- B8 reutiliza el manual Pure 04.2021 para otras variantes y para varios años anteriores. Se conservan esas citas como históricas, con conflicto de modelo/fecha donde corresponde. Las afirmaciones actuales se vinculan a manuales propios de nineT, Pure, Racer, Scrambler y Urban G/S.
- El archivo `R_0J11_RM_0319_01.pdf` dice **R nineT /5** en portada. No se usa como manual genérico de Pure: la Pure 2020 se revisa con `R_0J11_RM_0219_01.pdf`. El índice BMW enlaza /5 desde Pure/K22, mientras B8 asigna K21. Se mantiene la identidad B8 sin corregirla por analogía y todas las afirmaciones de /5 siguen pendientes.
- La nineT 2014 citaba un manual atribuido a 2015. La revisión actual recupera manual BMW 07.2013 propio, sin trasladar hacia atrás la edición posterior.
- Los pasajes EWS describen antena anular en la cerradura y llave mecánica. No identifican automáticamente generación EWS4, semiconductor, módulo o equipamiento individual. La etiqueta EWS4 heredada no se certifica por leer EWS genérico.
- En ediciones propias posteriores, el apéndice nombra EWS4/BECOM, TMS37145/Type DST80 y TMS3705 Transponder Base Station IC. Es respaldo limitado de homologación para 17 contextos de transponder (34 afirmaciones de chip/módulo), sin identificar llave ni módulo instalados, número de parte, mercado o compatibilidad de programación. No se extrapola a las ediciones anteriores sin ese contraste.
- El apéndice Pure 04.2021 contiene también certificados Keyless HUF5750/HUF8465. Su inclusión no prueba que la motocicleta consultada equipe Keyless: no se agregan filas ni compatibilidades a partir de esos certificados.
- Los procedimientos de acceso varían: nineT/Pure indican retirar asientos trasero y delantero; Racer indica cubierta de colín y asiento delantero; Scrambler/Urban G/S indican asiento. Se conserva modelo y edición, sin trasladar un desmontaje a todas las variantes.
- Para diagnóstico nineT 2014–2016 se usa solo la referencia limitada de HEX: retirar asiento; puerto en el tubo superior derecho del subchasis bajo la parte delantera del asiento. Su fila «2014+» no identifica contactos ni confirma todos los MY/mercados, y no se extiende a /5 por semejanza.
- Las 35 afirmaciones de conector y 35 de ubicación individual permanecen pendientes. No se transforma la etiqueta «PUERTO POR CONFIRMAR» en C10/C16 por iconos, fotografías o coincidencia de año.

## Validación y límites

Dos pruebas verifican modelos/ediciones, hashes de ficha y observaciones, CSV, límites de homologación, las dos filas /5 y las 70 consultas en Chromium por HTTP local. Incluyen separación de paneles, cambio a una RT y un estado móvil de 375 px. La regresión completa se registra en `VALIDACION_RC4.json`.

La fuente JSON original, el inventario CSV y las reglas de restricción se conservan. No se publicaron ni desplegaron cambios. Los PDF consultados quedan fuera del paquete de aplicación; se distribuyen referencias, observaciones y hashes. La descarga por este chat sigue sin vía comprobada.
