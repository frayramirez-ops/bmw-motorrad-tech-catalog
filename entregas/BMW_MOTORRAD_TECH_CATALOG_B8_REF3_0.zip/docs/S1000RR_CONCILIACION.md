# S1000RR — primer bloque documental

> **Estado de datos B8-REF2.0:** 42 fichas, 193 afirmaciones, 82 con respaldo limitado y 111 pendientes. El cuerpo de este informe conserva el recorrido histórico y sus cifras de cada etapa; para el bloque y los campos vigentes consultar `ACTUALIZACION_TRANSVERSAL_REF2.md`, `s1000rr-reconciliation.json` y `FICHAS_REFERENCIA_B8.csv`.

Se conserva F800GS en 98/210 afirmaciones con respaldo limitado y 112 pendientes. No se dispone de unidad para las verificaciones individuales; no se rellenan datos supuestos. Se abre S1000RR para continuar con trabajo documental independiente.

## Alcance

42 fichas originales B8: 25 IMMO (17 Mecánica y ocho Keyless históricas) y 17 diagnóstico. El registro `s1000rr-reconciliation.json` conserva identidad, hash de ficha B8, diferencias del ZIP, referencias y hallazgos. Su copia incorporada al HTML permite consulta local sin descargar JSON ni documentos externos.

Las 193 afirmaciones inventariadas se separan en 29 con respaldo limitado (19 de edición y diez de homologación) y 164 pendientes. Es una revisión inicial: no equivale a cobertura certificada ni se combina con el porcentaje F800GS como progreso global.

## Documentos consultados

| Edición impresa | EWS/antena, PDF/impresa | Acceso diagnóstico | Apéndice técnico |
|---|---|---|---|
| 07.2010, 4.ª | 39/37 | No contrastado | No contrastado |
| 04.2021, 3.ª | 65/59 | 227/221 | 283/277 |
| 04/2023, 2.ª | 69/63 | 236/230 | 293/287 |
| 07.2024, 1.ª | 87/81 | 229/223 | 292/286 |

Cuatro PDF oficiales recuperados con hash. Solo se aplican observaciones a las fichas cuyo diagnóstico ya cita esos documentos; no se extienden a años anteriores por similitud. La edición del manual no se equipara al año-modelo del selector.

Los textos describen EWS con antena anular en la cerradura de encendido. Las secciones de diagnóstico modernas indican acceso por asiento trasero o cubierta del colín según configuración. La información de homologación cita TMS37145/DST80/TMS3705, sin identificar cada unidad ni demostrar aplicaciones de programación.

## Conflicto Keyless

El ZIP incluye cuatro filas en `HIPOTESIS_KEYLESS_RETIRADAS.csv`, una por año 2023–2026. B8 conserva ocho filas de principal/emergencia para esos años. Se registran como hipótesis no acreditadas y se explica el conflicto dentro de la ficha; no se borran ni fusionan los datos originales.

El manual 04.2021 contiene certificados Keyless HUF en el apéndice. Eso no prueba equipamiento Keyless en S1000RR. Los manuales posteriores revisados describen EWS con llave; la ausencia de una mención Keyless en la extracción tampoco demuestra imposibilidad en todos los mercados. No extrapolar S1000R o S1000XR a RR.

Las atribuciones EWS4/DST80 del ZIP a K46 2013–2018 proceden de una referencia especialista aún sin contrastar; no se consideran confirmadas por un certificado de 2021. Los códigos F siguen sin equivalencia demostrada.

## Implementación y límites

El panel documental se comparte con F800GS, manteniendo registros y fuentes independientes por identidad y sección. Ningún hallazgo cambia `catalogData`, el CSV original o las reglas de liberación. La aplicación mantiene todas las referencias técnicas restringidas mientras no se reconstruya el vínculo auditado.

Pruebas: integridad de 42 identidades/193 afirmaciones, diez observaciones con hashes, ocho hipótesis Keyless pendientes y recorrido real de Keyless a Mecánica sin contaminación entre paneles ni liberación de galería técnica. Ejecutar `python3 -m unittest discover -s tests -v`.

## Actualización: los ocho manuales restantes

Se consultaron las secciones relevantes de las 12 ediciones oficiales que ya citaba diagnóstico B8. Las cifras de esa etapa fueron **56/193 afirmaciones con respaldo limitado (29,0 %)**: 42 de edición y 14 de homologación; **137 pendientes**. Hay 23 observaciones con localizadores y hashes. Esto sustituye el estado inicial de cuatro fuentes/diez observaciones y 29 afirmaciones documentadas; no implica certificación por VIN.

| Edición adicional comprobada | EWS, página PDF/impresa | Otra observación |
|---|---|---|
| 09.2011, 1.ª | 37/35 | Sin identificación de chip en el localizador revisado |
| 08.2012, 2.ª | 37/35 | No acredita DST80 por VIN |
| 07.2015, 4.ª | 39/37 | B8 la cita para 2014: conflicto cronológico sin resolver |
| 09.2014, 1.ª | 43/41 | No acredita componente individual |
| 12.2015, 3.ª | 43/41 | No acredita componente individual |
| 06.2016, 1.ª | 43/41 | Diagnóstico PDF 191/impresa 189 |
| 09.2018, 1.ª | 63/61 | Diagnóstico PDF 208–209/impresas 206–207 |
| 05.2020, 2.ª | 63/57 | Diagnóstico PDF 222/impresa 216; apéndice técnico PDF 277 sin número impreso identificado |

El documento denominado `S_0524_RM_0811...` indica 09.2011 en su colofón: se registra la fecha impresa, no la del nombre del archivo. No se cambia el modelo-año de una ficha por ese motivo.

La ficha 2014 no recibe respaldo de sistema/antena por la edición posterior 07.2015; permanece pendiente y muestra el conflicto. Las observaciones de EWS de los otros años no identifican automáticamente EWS3/EWS4, fabricante, MCU ni semiconductor.

K46 2013–2018 conserva pendientes de chip/módulo: la mención EWS no acredita la atribución especialista EWS4/DST80 del ZIP. La homologación posterior se vincula solo a la edición que la contiene y a las fichas que la citan, sin trasladarla retrospectivamente.

Hay una discrepancia de localización que no se resuelve por suposición: el manual 05.2020 titula la vista general `UNDER THE RIDER'S SEAT`, mientras su procedimiento de diagnóstico indica asiento de pasajero/cubierta del colín según equipamiento. Se conserva como observación para 2020–2021 y no se da por contrastada la ubicación exacta.

Se entregan `S1000RR_AFIRMACIONES.csv` (193 filas) y `S1000RR_PENDIENTES.csv` (137). Las ocho hipótesis Keyless siguen pendientes. `catalogData`, CSV B8 y reglas de liberación permanecen intactos; no se publica ni despliega.

## Seguimiento de acceso RC14 — estado vigente

Siete diagnósticos 2010–2016 reciben referencia especialista HEX GS-911 para acceso retirando asiento trasero, con puerto al frente del compartimento bajo asiento. Son **63/193 afirmaciones con respaldo limitado** (42 de edición, 14 de homologación y siete de especialista) y **130 pendientes**. El registro contiene 12 PDF, una fuente web y 24 observaciones. El CSV vigente de pendientes tiene 130 filas.

La cita OEM 07.2015 para 2014 conserva su conflicto; la referencia de acceso es independiente y no valida esa edición ni el resto de la ficha. No se acreditan contactos, adaptadores, chips ni equipamiento Keyless mediante esta guía. Las ocho hipótesis siguen pendientes. La instantánea web RC14 se guarda separada de las anteriores; se conserva el estado previo de cada afirmación en `followUp.changes`. Véase `SEGUIMIENTO_ACCESOS_RC14.md` y `VALIDACION_RC14.json`.

## Revisión temporal RC16 — estado vigente

El índice BMW asigna el manual 07.2015 al tipo 0524 / K46 11 desde 08/2013. Se contrasta con PDF 39 y el pasaje anterior 08.2012, PDF 37. La ficha mecánica 2014 recibe respaldo limitado para sistema y antena, conservando diferencia de publicación, incertidumbre individual y todos los pendientes de chip/módulo/mercado. Hay 65 afirmaciones con respaldo limitado y 128 pendientes, con 14 fuentes y 25 observaciones. Las ocho hipótesis Keyless y el seguimiento de acceso RC14 no cambian. Véase `TEMPORALIDAD_MANUALES_RC16.md` y `VALIDACION_RC16.json`.
