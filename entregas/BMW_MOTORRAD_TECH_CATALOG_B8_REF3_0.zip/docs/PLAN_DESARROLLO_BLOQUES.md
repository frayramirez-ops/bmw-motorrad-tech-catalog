# Desarrollo por bloques grandes

Preferencia del usuario: revisar patrones completos y entregar avances transversales, en vez de una versión por ficha señalada al azar. Los modelos de ejemplo orientan la prioridad; no limitan la revisión al caso individual. Las entregas agrupan un tema y comprobaciones de las siete familias, con matriz de datos antes/después y descarga verificada.

| Bloque | Trabajo | Criterio de entrega |
|---|---|---|
| 1. Datos de referencia y ubicaciones | B8-REF2.0: resúmenes de las siete familias, ubicación por manual/guía, pilas y mandos por edición, matriz de campos. | Fichas, CSV y evidencia sincronizados; conservación de las excepciones; regresión de todas las selecciones. |
| 2. Componentes de inmovilizador | Contrastar en conjunto chip, mando y módulo en generaciones comerciales: F798/F895, F750/F850, R1200/R1250/R1300 y bloques K/C/S. Distinguir identificación del mando, homologación del chip y referencia del módulo. | Cada dato tiene componente, fuente, aplicabilidad y nivel de certeza; no queda asignado solo por nombre Keyless, año o fabricante. Mantener separado lo que es referencia de modelo y lo que exige identificar una pieza instalada. |
| 3. Conectores e interfaces | Revisar formato/contactos y transiciones CT/C16C como bloque, aprovechando las ubicaciones ya documentadas. | Evidencia aplicable por modelo/subgeneración y compatibilidad de interfaz; no usar una regla universal por año ni fotos genéricas. |
| 4. Mercado y cobertura | Reconstruir alcance de mercado y equipamiento documental; recuperar diccionario F y revisiones para aclarar trazabilidad histórica. | Padrón y opciones con fuente y periodo; referencias editoriales separadas de certificación por VIN. La ausencia del diccionario no detiene la incorporación de nuevas fuentes identificadas. |

Cada entrega debe indicar cuántas fichas cambiaron realmente, qué campos se completaron y qué sigue sin fuente. Conservar B8 y estados anteriores. Las mejoras de interfaz no cuentan como validación de hardware. Publicación de paquetes autorizada en la rama de entrega, conservando main; despliegue web no solicitado.
