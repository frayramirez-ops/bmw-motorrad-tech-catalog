# Últimas fichas F — F900GS/Adventure, F900R y F450GS

> **Estado de datos B8-REF2.0:** 28 fichas, 132 afirmaciones, 65 con respaldo limitado y 67 pendientes. El cuerpo de este informe conserva el recorrido histórico y sus cifras de cada etapa; para el bloque y los campos vigentes consultar `ACTUALIZACION_TRANSVERSAL_REF2.md`, `f-final-reconciliation.json` y `FICHAS_REFERENCIA_B8.csv`.

## Alcance

28 fichas B8: 24 F900GS/Adventure (2024–2026), dos F900R 2026 y dos F450GS 2026. Hay 20 filas transponders y ocho diagnóstico. Se conservan seis emergencias Keyless fuera del selector independiente; 22 consultas son seleccionables. No se agregan variantes ni se normalizan campos pendientes.

`f-final-reconciliation.json` conserva identidad/hash y una copia idéntica en HTML con panel contextual. Son 132 afirmaciones: **57 con respaldo limitado** (44 de edición, 12 de homologación y una opción documentada) y **75 pendientes**. Los CSV `F_FINAL_AFIRMACIONES.csv` y `F_FINAL_PENDIENTES.csv` mantienen todas y las pendientes.

No se compararon resultados del ZIP: listas vacías no demuestran ausencia histórica. Los códigos F siguen sin diccionario verificado.

## Documentos consultados

Nueve PDF oficiales, índice BMW y listado BMW México consultados, más un enlace histórico de portal comercial sin verificar por dominio fuera de la política de red actual. Son 12 fuentes y 46 observaciones con alcance/hash; página impresa null cuando no se comprobó.

| Modelo | Edición impresa | Plataforma de índice | Giro llave, PDF | EWS, PDF | Respaldo Keyless, PDF | Acceso diagnóstico, PDF | Homologación, PDF |
|---|---|---|---:|---|---|---|---|
| F900GS | 03.2024, 2nd edition | K81 11 | 84 | 89 | 87 | 198 | 272 |
| F900GS | March 2025, 3rd edition | K81 11 | 84 | 88 | 87 | 202 | 278 |
| F900GS | 07/2023, 1st edition | K81 11 | 84 | 89 | 87 | 204 | 273 |
| F900GS Adventure | 03.2024, 2nd edition | K82 11 | 84 | 89 | 87 | 201,202 | 276 |
| F900GS Adventure | April 2025, 3rd edition | K82 11 | 84 | 89 | 87 | 204,205 | 282 |
| F900GS Adventure | 07/2023, 1st edition | K82 11 | 84 | 89 | 87 | 205,206 | 277 |
| F900R | March 2025, 2nd edition | K83 MUE | 86 | 91 | 89 | 201,202 | 280 |
| F 450 GS | 03.2026, 3rd edition | KD1 | 74 | — | — | 166,167 | — |
| F 450 GS | 10.2025, 2nd edition | KD1 | 74 | — | — | 164 | — |

«—» indica contenido no utilizado, sin probar ausencia de función. El índice oficial enlaza F450GS KD1 y F900R K83 MUE; se conserva la plataforma B8 «POR VERIFICAR» porque el documento no identifica una unidad. La segunda edición F450GS se usa como referencia primaria y la tercera como contraste de edición; no se selecciona una por el año genérico de la ficha.

## Hallazgos

- Las F900GS y Adventure conservan documentos propios por año/plataforma. Los manuales separan giro de llave mecánica y Keyless opcional; no se determina equipamiento ni mercado por esa coexistencia.
- El respaldo Keyless se sitúa bajo el asiento. EWS genérico y lector de respaldo no identifican chip, módulo RF ni unidad. Las 24 afirmaciones de chip/módulo Keyless de GS/Adventure siguen pendientes.
- Los seis apéndices GS/Adventure identifican «Model name: EWS 4», BECOM, TMS37145/Type DST80 y TMS3705 Transponder Base Station IC. Las 12 afirmaciones mecánicas de chip/módulo solo reciben respaldo de homologación en edición, sin número de pieza, identificación por VIN ni compatibilidad de programación.
- F900R 2026 tenía únicamente cita comercial general. Se recuperó manual propio K83 MUE, con llave mecánica y Keyless Ride OE (PDF 86–87). La afirmación de sistema tiene estado de opción documentada; la ficha mantiene «CONFIRMAR SISTEMA». Antena, chip y módulo siguen pendientes porque no se seleccionó variante. Sus observaciones de antena pueden estar presentes sin ser suficientes para resolver el estado.
- F450GS ya tiene manuales propios enlazados por BMW. Los pasajes revisados describen llave y cerradura, sin resolver presencia o ausencia de inmovilizador/transponder. Las cinco afirmaciones de su fila transponder siguen pendientes. No se certifica ausencia porque no aparezca EWS en los pasajes utilizados.
- El acceso diagnóstico F450GS requiere **asiento trasero/pasajero**, según PDF 164 de la edición 10.2025 y PDF 166–167 de 03.2026. No se le traslada el desmontaje de otras familias. F900 usa asiento y seguros laterales de soporte. Los ocho conectores y ocho ubicaciones individuales siguen pendientes; no se deduce C16 por ilustración o por el nombre de la interfaz.
- El listado comercial BMW México no identifica sistema ni puerto de F900R por año o VIN. El portal comercial heredado F450GS tampoco certifica compatibilidad por incluir modelo 2026.
- Nombre de archivo y colofón difieren: GS/Adventure 0823 indican 07/2023; 0724 indican 03.2024; GS 0725 indica March 2025 y Adventure April 2025. F450GS 1125 indica 10.2025 y 0626 indica 03.2026. Se registran los colofones sin uniformar fechas entre modelos.

## Validación y límites

Dos pruebas comprueban identidad/hash, fuente por modelo/edición, opciones no seleccionadas F900R, pendiente de inmovilizador F450GS, homologación restringida a Mecánica, CSV, 22 consultas, separación de paneles y un estado móvil. La cobertura comprueba F 182/182 con desglose y R 279/279; eso no certifica ambas familias. Regresión vigente: `VALIDACION_RC8.json`.

Se mantienen pendientes previos F800GS, identificación por unidad y fuentes históricas. No se publicó ni desplegó. Los datos originales y las restricciones de programación se conservan. Los PDF de consulta quedan fuera del paquete: se guardan enlaces, observaciones y hashes. La descarga del paquete por este chat sigue pendiente de una vía comprobada.
