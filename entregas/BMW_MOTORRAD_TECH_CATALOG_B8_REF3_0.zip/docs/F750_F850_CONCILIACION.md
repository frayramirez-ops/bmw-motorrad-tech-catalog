# F750GS, F850GS y F850GS Adventure — revisión por edición

> **Estado de datos B8-REF2.0:** 68 fichas, 323 afirmaciones, 166 con respaldo limitado y 157 pendientes. El cuerpo de este informe conserva el recorrido histórico y sus cifras de cada etapa; para el bloque y los campos vigentes consultar `ACTUALIZACION_TRANSVERSAL_REF2.md`, `f750-f850-reconciliation.json` y `FICHAS_REFERENCIA_B8.csv`.

## Alcance

68 fichas B8: F750GS 24 y F850GS 24 (2018–2023); Adventure 20 (2019–2023). Hay 51 filas transponders y 17 diagnóstico. Las 17 emergencias Keyless se conservan en el registro histórico, fuera del selector independiente; se prueban 51 consultas seleccionables. No se agregan años ni variantes para completar un padrón de producción.

`f750-f850-reconciliation.json` contiene identidad/hash, fuentes, observaciones y afirmaciones; hay copia idéntica en el HTML y un panel contextual. No se compararon resultados del ZIP en este bloque: listas vacías no acreditan ausencia histórica. Los códigos F heredados siguen sin diccionario verificado.

323 afirmaciones: **149 con respaldo limitado** (119 de edición y 30 de homologación) y **174 pendientes**. Nada certifica VIN ni compatibilidad de programación. `F750_F850_AFIRMACIONES.csv` contiene todas; `F750_F850_PENDIENTES.csv` conserva las pendientes.

## Documentos consultados

Once PDF oficiales más índice BMW, con 57 observaciones. Cada manual conserva sus entradas de índice por archivo/modelo/periodo y hash de recuperación. Se comprobó modelo en portada, edición en colofón y contenido de los pasajes. Página PDF conservada; impresa null cuando no se verificó.

| Modelo | Edición impresa | Giro de llave y EWS, PDF | Emergencia Keyless, PDF | Acceso diagnóstico, PDF | Homologación EWS4, PDF |
|---|---|---|---:|---|---|
| F750GS | 05.2020, 4th edition, 01 | 84, 89 | 87 | 230 | 295 |
| F750GS | 04.2022, 6th edition, 01 | 88, 93 | 91 | 239,240 | 310 |
| F750GS | 08.2019, 3rd edition, 01 | 86, 91 | 89 | 223 | 286 |
| F750GS | 11.2017, 1st edition, 01 | 80, 81 | 85 | 220,221 | No utilizado |
| F850GS | 04.2020, 4th edition, 01 | 62, 67 | 65 | 199 | 263 |
| F850GS | 04.2022, 6th edition, 01 | 68, 73 | 71 | 210 | 280 |
| F850GS | 08.2019, 3rd edition, 01 | 86, 91 | 89 | 228 | 294 |
| F850GS | 11.2017, 1st edition, 01 | 81, 82 | 86 | 227 | No utilizado |
| F850GS Adventure | 05.2020, 4th edition, 01 | 62, 67 | 65 | 199 | 261 |
| F850GS Adventure | 04.2022, 6th edition, 01 | 68, 73 | 71 | 211,212 | 280 |
| F850GS Adventure | 08.2019, 3rd edition, 01 | 88, 93 | 91 | 231,232 | 292 |

«No utilizado» no demuestra ausencia de función. El índice oficial es `https://manuals.bmw-motorrad.com/manuals/BA-Extern/IN/BA-INTERNET-COM/01/Nav.xml`; sus periodos delimitan manuales, sin certificar todos los MY o mercados. Se conservan los enlaces B8 por identidad exacta de modelo/año/plataforma, sin sustituir silenciosamente el dato original por otra edición.

## Hallazgos y límites

- Las ediciones describen giro de llave mecánica y, por separado, Keyless como equipamiento opcional. La coexistencia documental no acredita oferta en todos los mercados ni configuración instalada. No se identifica el sistema de una unidad solo por año o plataforma.
- La lectura EWS se describe mediante antena anular en cerradura de contacto. En ediciones posteriores el texto menciona ignition lock / R/C ignition lock. No se interpreta esa descripción como identificación automática de una versión de hardware.
- El respaldo Keyless requiere retirar asiento e introducir la llave de emergencia o mando plegado sin pila en el lector anular bajo el asiento. No se traslada la posición de cubierta de rueda trasera ni la de cuadro de instrumentos de otras familias. La emergencia pertenece a Keyless, sin convertirse en tercera arquitectura instalada.
- Nueve documentos contienen el apéndice EWS4/BECOM, TMS37145/Type DST80 y TMS3705 Transponder Base Station IC. Las 30 afirmaciones de chip/módulo de Mecánica 2019–2023 reciben solo estado de homologación, sin número de pieza ni identificación por VIN. No se acredita pieza instalada o programación.
- Los pasajes utilizados de las ediciones 11.2017 no identifican ese semiconductor para Mecánica 2018. Sus cuatro afirmaciones de chip/módulo permanecen pendientes; no se transfiere hacia atrás el apéndice de ediciones posteriores.
- Las 68 afirmaciones de chip/módulo Keyless permanecen pendientes. HUF, 8A o AES128 no se confirman por el nombre Keyless ni por encontrar un certificado en el apéndice. Se distingue transponder pasivo de mando, receptor RF y módulo de autorización.
- El procedimiento diagnóstico indica asiento y seguros laterales del soporte. Las 17 afirmaciones de conector y 17 de ubicación individual siguen pendientes. La etiqueta C16 heredada no queda certificada por una figura o por la descripción de acceso.
- Las 68 afirmaciones de mercado/equipamiento siguen pendientes. No se supone configuración México ni se extrapola un VIN al año entero.
- Hay diferencias entre nombre de archivo y colofón: los tres archivos 0622 indican 04.2022; el GS 0520 indica 04.2020, mientras F750GS/Adventure 0520 indican 05.2020. Se registran las fechas impresas, sin uniformarlas por nombre.

## Validación

Dos pruebas verifican portada/modelo registrado, identidad/hash, fuente de diagnóstico por año/plataforma, copia embebida, páginas y hashes de observaciones, CSV y límites Keyless/Mecánica. Recorren las 51 consultas seleccionables en Chromium por HTTP local, verifican ocultación de paneles ajenos y restricciones técnicas, cambio a otro modelo y un estado móvil de 375 px. La regresión completa y verificación de integridad quedan en `VALIDACION_RC6.json`.

La cobertura de F pasa de 46 a 114 filas con desglose; otras 68 siguen sin él. El bloque F800GS mantiene sus 112 pendientes individuales. La cobertura global no es porcentaje de finalización.

No se publicó ni desplegó. Los datos originales y las restricciones de programación se conservan. Los PDF consultados quedan fuera del paquete; se incluyen enlaces, hashes y observaciones. La descarga por este chat continúa sin vía comprobada.
