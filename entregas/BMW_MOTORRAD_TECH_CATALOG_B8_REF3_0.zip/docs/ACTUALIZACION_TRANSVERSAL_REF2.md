# B8-REF2.0 — actualización transversal de datos

Se atiende la petición de avanzar por bloques grandes. La revisión comprende las siete familias y los catorce registros; no se limita a Adventure 2020 ni aplica datos de ese modelo a otras motocicletas.

## Resultado del bloque

- 815 registros preservados; 757 tienen resumen de datos documentados y enlaces por página/sección. De las 701 selecciones de la interfaz, 647 tienen ese resumen. Las 58 entradas sin datos técnicos suficientemente respaldados siguen explícitas; 54 son seleccionables y cuatro son emergencias históricas.
- 309 de 315 fichas de diagnóstico tienen ubicación documentada en manual o guía especialista. Se corrigen 278 pendientes excesivos: 164 con vistas generales de manuales propios y 114 con la guía HEX ya vinculada al modelo/periodo. Los seis casos con acceso no respaldado siguen pendientes.
- 222 registros Keyless incorporan pila y alcance de su propia edición: 218 citan CR2032 y cuatro citan CR1632 (R1250RT 2021–2022, dos modalidades por año). Incluyen entradas históricas de emergencia, no 222 motocicletas o modelos distintos. El alcance citado es aproximadamente 1 m.
- 122 registros cuentan con una referencia de mando en la homologación de su manual. Esta referencia no se convierte en identificación del módulo o semiconductor instalado.
- Una matriz CSV de 815 filas permite revisar campos disponibles y pendientes por identidad. Es accesible desde la aplicación y se genera junto con las fichas y exportaciones.

| Familia | Fichas B8 | Con resumen documental | Diagnósticos con ubicación respaldada |
|---|---:|---:|---:|
| C | 87 | 87 | 35 |
| F | 182 | 172 | 65 |
| G | 18 | 9 | 9 |
| K | 128 | 120 | 43 |
| M | 6 | 3 | 3 |
| R | 279 | 259 | 112 |
| S | 115 | 107 | 42 |

Las cifras se verifican en `model-reference-inventory.json`; los campos vacíos del CSV no significan que el componente no exista. Los 757 resúmenes incluyen 110 emergencias históricas que no se muestran como tercer sistema independiente.

## Evidencia y criterio de actualización

Se contrastaron por hash y pasajes 152 PDF existentes: 130 aportan vistas generales para el bloque de ubicación y 88 aportan pasajes Keyless, con solapamiento entre ambos conjuntos. De ese conjunto, 148 PDF aportan las 349 nuevas observaciones cuyos extractos se volvieron a contrastar página por página en `VERIFICACION_FUENTES_BLOQUE_2.json`. No se afirma haber releído todas las páginas de esos documentos. La guía HEX se reconsultó el 6 de noviembre de 2026; el contenido de las ubicaciones se contrasta con las capturas conservadas. Los PDF de BMW no se redistribuyen; se guardan vínculos, hashes, páginas y breves extractos de evidencia.

Una afirmación de ubicación no necesita permanecer sin datos porque no se ha inspeccionado un VIN cuando el manual o una guía aplicable describe esa posición del modelo. Se marca como referencia de edición o de especialista, conservando el alcance y sin deducir contactos/adaptador. Los estados previos y las identidades modificadas quedan en `bulkReferenceUpdate.locationChanges` de cada registro. Se preservan las observaciones originales y se identifican las añadidas. La posición revisada también alimenta el resultado principal de diagnóstico; el resultado B8 anterior queda en un apartado histórico de auditoría y se excluye de la impresión de consulta.

Las pilas se extraen del apartado del mando Keyless Ride, no del mando de cierre centralizado ni del DWA. R1250RT permite comprobar esa diferencia: una misma obra puede citar CR1632 para Keyless y CR2032 para otro mando. Los datos no se rellenan por año, familia ni por parecerse el nombre del modelo. Las ocho hipótesis Keyless S1000RR no reciben datos de otros sistemas.

## Integridad y límites

`catalogData`, los originales B8, las identidades y la asociación de reglas de programación no cambian. Las contradicciones C400GT, los formatos CT/C16C y las variantes no nombradas conservan sus límites. Los seis accesos sin respaldo (incluidas variantes /5 y K1600GTL 2015/2016) no se completan por analogía.

Las 3760 afirmaciones originales quedan en 1595 con respaldo limitado y 2165 pendientes. El cambio del bloque es de 278 ubicaciones; las nuevas referencias de pila/alcance/mando son campos adicionales, no se suman artificialmente al denominador de afirmaciones originales. Mercado/equipamiento, chip, módulo y contactos continúan pendientes donde no hay evidencia específica. Una referencia documental no certifica una unidad ni desbloquea programación.

## Reproducción y validación

Ejecutar `scripts/build_model_references.py` y después `scripts/build_coverage.py`; sus opciones `--check` detectan salidas obsoletas. El primer generador rechaza fuentes no consultadas, referencias ajenas a la ficha, datos Keyless en un sistema diferente y componentes pendientes presentados como datos curados.

La regresión comprueba las 701 selecciones y los campos del resumen contra la matriz de referencia, además de las funciones existentes. La prueba de bloque verifica las 278 transiciones, hashes/vínculos, todos los campos, las excepciones de pila y la conservación de pendientes. Los resultados ejecutados y sus límites están en `VALIDACION_BLOQUE_2.json`; la verificación extraída está en `VALIDACION_ENTREGA_BLOQUE_2.json`. Los informes anteriores conservan su estado histórico.

La revisión final prioriza los resúmenes documentales antes de las explicaciones heredadas. La primera página de RT 2021 conserva la restricción de programación y muestra CR1632, alcance y mando de referencia. La posición revisada también se verifica en los 315 resultados principales de diagnóstico.
