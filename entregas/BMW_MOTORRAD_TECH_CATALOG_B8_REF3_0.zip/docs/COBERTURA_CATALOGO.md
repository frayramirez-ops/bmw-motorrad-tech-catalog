# Cobertura de conciliación y padrón de fichas B8

## Denominadores y alcance

La nueva vista `ESTADO_CATALOGO.html`, enlazada desde el catálogo, muestra las 815 fichas originales de B8 (500 transponders, 315 diagnóstico). Una ficha se identifica por sección, año, familia, modelo, plataforma y sistema. No se deduplican como si fueran motocicletas diferentes o equivalentes sin comprobarlas.

Las 815 fichas tienen conciliación detallada en catorce registros de revisión; ninguna queda sin desglose. Tener conciliación significa que existe un desglose trazable, sin aprobar automáticamente sus datos. Las 815 se distribuyen en:

- 757 con alguna afirmación de respaldo limitado.
- 50 conciliadas sin respaldo contrastado suficiente.
- Ocho hipótesis Keyless no acreditadas.

En los bloques conciliados hay 3760 afirmaciones inventariadas: 1598 con respaldo limitado y 2162 pendientes. Cada transponder tiene cinco afirmaciones y cada diagnóstico cuatro. El generador conserva null/blancos para cualquier ficha futura sin revisión; no equivale a «cero pendientes». En esta versión todas las fichas tienen conteos conocidos.

El cociente 815/815 (100 %) expresa únicamente la proporción de fichas con conciliación detallada. No es un porcentaje de desarrollo, validez técnica ni certificación por VIN. El denominador de un padrón BMW por mercado y objetivo 2003–2027 sigue sin establecerse. B8 contiene años 2000–2026; no se inventan filas de 2027 para completar el objetivo.

## Distribución por familia

| Familia | Fichas B8 | Con conciliación detallada | Sin conciliación detallada |
|---|---:|---:|---:|
| C | 87 | 87 | 0 |
| F | 182 | 182 | 0 |
| G | 18 | 18 | 0 |
| K | 128 | 128 | 0 |
| M | 6 | 6 | 0 |
| R | 279 | 279 | 0 |
| S | 115 | 115 | 0 |
| Total | 815 | 815 | 0 |

Esta tabla mide filas y secciones recibidas; los alias y sistemas alternativos no se convierten en producción confirmada. Todas las familias tienen registro: F (182), R (279), K (128), C (87), S (115), G (18) y M (seis). Los catorce bloques mantienen sus limitaciones técnicas. El cierre 815/815 no elimina las ocho hipótesis ni las 50 fichas revisadas sin respaldo suficiente.

## Funciones de consulta

La página permite buscar por modelo/plataforma, filtrar familia, año y estado de conciliación, y recorrer resultados en páginas de 40 filas. Muestra cero coincidencias sin sustituir modelos y descarga el padrón CSV completo. La tabla tiene desplazamiento propio en móvil, sin extender el ancho de la página. No solicita documentos remotos ni cambia datos del usuario. Cada ficha con afirmaciones pendientes enlaza a su consulta exacta, y existe un acceso al inventario completo de pendientes. Véase `PENDIENTES_CONSULTA.md`.

`PADRON_CATALOGO_B8.csv` exporta las 815 identidades con estado de conciliación y conteos conocidos. Es un inventario derivado de B8 y sus registros de revisión, no una base maestra OEM ni una recomendación de compatibilidad.

## Actualización reproducible

Fuentes: JSON `catalogData` del HTML y los registros `f800-reconciliation.json`, `s1000rr-reconciliation.json`, `r1250gs-reconciliation.json`, `r1200gs-reconciliation.json`, `r1250rt-r1300gs-reconciliation.json`, `ninet-reconciliation.json`, `r-final-reconciliation.json` `f750-f850-reconciliation.json` `f650-f700-reconciliation.json` `f-final-reconciliation.json` `k-reconciliation.json` `c-reconciliation.json` `s-final-reconciliation.json` y `gm-reconciliation.json`.

```sh
python3 scripts/build_coverage.py
python3 scripts/build_coverage.py --check
```

El generador actualiza `docs/coverage-data.json`, `BMW_Motorrad_B8_REGENERADO/ESTADO_CATALOGO.html`, `BMW_Motorrad_B8_REGENERADO/PADRON_CATALOGO_B8.csv` `docs/PENDIENTES_TECNICOS_B8.csv`, su copia idéntica en la aplicación y `BMW_Motorrad_B8_REGENERADO/PENDIENTES_TECNICOS.html`. Este último reúne las 2162 afirmaciones pendientes con identidad, registro de origen, observaciones, límite y acción requerida; no elimina contradicciones ni libera resultados. No modifica `catalogData`, el CSV original ni las reglas de liberación. Guarda hashes de las entradas y rechaza identidades duplicadas, revisiones de fichas inexistentes o con hash obsoleto y estados de afirmación desconocidos. `--check` detecta archivos derivados desactualizados sin escribirlos.

## Validación

Tres pruebas de cobertura comprueban reproducibilidad, todas las identidades, el padrón y las 2162 filas del CSV de pendientes, rechazo de revisiones incoherentes y recorridos reales de navegador: enlace desde B8, paginación, filtros combinados, alias GSA, hipótesis, estado vacío, descarga y retorno al catálogo. Se comprueba anchura móvil de 375 px. No se certifica cobertura de producción ni se cambia la restricción técnica de las fichas.

La vista forma parte de la distribución ZIP autorizada en GitHub; no hay despliegue web. La limitación de file:// del navegador administrado sigue documentada en `BIBLIOTECA_VISUAL.md`; se usa el servidor HTTP local.
