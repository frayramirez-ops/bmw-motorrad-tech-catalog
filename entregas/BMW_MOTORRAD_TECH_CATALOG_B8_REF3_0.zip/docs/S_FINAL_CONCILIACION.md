# Conciliación S1000R / S1000XR — RC11

> **Estado de datos B8-REF2.0:** 73 fichas, 340 afirmaciones, 158 con respaldo limitado y 182 pendientes. El cuerpo de este informe conserva el recorrido histórico y sus cifras de cada etapa; para el bloque y los campos vigentes consultar `ACTUALIZACION_TRANSVERSAL_REF2.md`, `s-final-reconciliation.json` y `FICHAS_REFERENCIA_B8.csv`.

73 fichas B8: 48 transponders y 25 diagnóstico. Son 60 selecciones de interfaz y 13 emergencias Keyless conservadas como histórico. No sustituye las 42 fichas de `s1000rr-reconciliation.json` ni libera sus ocho hipótesis Keyless. Se preservan datos, resultados y hashes originales.

## Resultado y alcance

340 afirmaciones: 108 documentadas en edición, 20 referencias de homologación EWS4, cinco de especialista y 207 pendientes. Hay 21 fuentes consultadas: 19 PDF propios, índice BMW LANGUAGE 01 (01.10.2026) y guía HEX; 66 observaciones. Registro: `s-final-reconciliation.json`; exportaciones: `S_FINAL_AFIRMACIONES.csv` y `S_FINAL_PENDIENTES.csv`.

- Modelos R y XR se contrastan por separado. Los manuales describen Keyless Ride OE junto a llave mecánica en las ediciones aplicables: no se elige equipamiento de una unidad por año.
- Respaldo R: panel detrás del asiento del conductor sobre antena 2. Respaldo XR: junto al depósito sobre antena 2. No se intercambian ubicaciones entre modelos ni se deduce posición del lector mecánico a partir de Keyless.
- Los pasajes EWS mecánicos de R 2021–2026 y XR 2022–2023 solo precisan antena anular, sin posición. Esas ocho afirmaciones de antena conservan estado pendiente y observaciones. En XR 2020–2021 la edición 05.2020 sí menciona ignition lock; no se atribuye esa frase a ediciones posteriores.
- Diez fichas mecánicas recientes disponen de homologación que enumera EWS4, BECOM Electronics, TMS37145/Type DST80 y TMS3705. Sus 20 afirmaciones de chip/módulo son referencias de edición, sin identificar llave/componente instalado. Ningún certificado se aplica al chip AES128/HUF de un mando Keyless: sus 52 afirmaciones siguen pendientes.
- Diagnóstico: 20 accesos OEM. En R, asiento trasero/pasajero o tapa de colín según paquete de acompañante; en XR, retirar asiento según edición. Cinco accesos antiguos usan HEX por su propia fila/modelo. El rótulo 2015+ de imágenes de adaptador no se usa para acreditar contactos.
- Los cuatro CT se conservan: R 2015/2016 y XR 2015/2016. Las 25 fichas mantienen conector y ubicación individual pendientes; acceso descrito no certifica formato, contactos ni adaptador.
- Archivo XR 0317: colofón 09.2016, “3.1rd edition”, conservado literalmente. Las fechas se leen de la obra, sin convertir nombre de archivo o índice de periodos en certificación por año/mercado.

Las URL, hashes de descarga y entradas del índice por plataforma/mercado están en el registro. Los hashes de los 19 PDF y dos documentos web se contrastaron con los archivos locales. No se compararon resultados del ZIP en este bloque ni se reconstruyó el diccionario F. No se incorporan los PDF remotos al paquete ni se presume permiso de redistribución.

## Páginas de contraste

Son números de página PDF; no equivalen necesariamente a la numeración impresa. La columna EWS mecánica no se interpreta como ubicación confirmada si el propio pasaje no la precisa.

| Modelo | Edición | EWS mecánica PDF | Capítulo Keyless PDF | Respaldo PDF | Acceso PDF | Homologación PDF |
|---|---|---:|---:|---:|---:|---:|
| S1000R | 02.2025, 2nd edition | 92 | 89 | 91 | 226 | 288 |
| S1000R | 03.2017, 1.1st edition | 43 | — | — | 166 | — |
| S1000R | 04.2018, 2nd edition | 47 | — | — | 170 | — |
| S1000R | 04.2021, 2nd edition | 73 | 69 | 71 | 231 | 290 |
| S1000R | 04/2023, 4th edition | 74 | 71 | 73 | 236 | 295 |
| S1000R | 08.2014, 2nd edition | 36 | — | — | — | — |
| S1000R | 08.2015, 3rd edition | 43 | — | — | — | — |
| S1000R | 08.2024, 1st edition | 92 | 89 | 91 | 226 | 288 |
| S1000R | 09.2013, 1st edition | 43 | — | — | — | — |
| S1000R | 10.2020, 1st edition | 72 | 69 | 71 | 227 | 281 |
| S1000XR | 03.2024, 2nd edition | — | 90 | 92 | 200 | 270 |
| S1000XR | 04.2018, 4th edition | 45 | — | — | 170 | — |
| S1000XR | 04.2021, 3rd edition | 71 | 72 | 75 | 204 | 270 |
| S1000XR | 04.2022, 4th edition | 73 | 74 | 77 | 208 | 276 |
| S1000XR | 04.2025, 3rd edition | — | 90 | 92 | 202 | 273 |
| S1000XR | 05.2020, 2nd edition | 69 | 70 | 73 | 202 | 265 |
| S1000XR | 08.2015, 2nd edition | 41 | — | — | — | — |
| S1000XR | 08/2023, 1st edition | — | 90 | 93 | 202 | 268 |
| S1000XR | 09.2016, 3.1rd edition | 41 | — | — | 164 | — |

## Validación

`test_s_final.py` comprueba identidad/hash original, equivalencia del JSON embebido, procedencia de observaciones, límites por componente, los ocho pendientes de antena, cuatro CT, alcance de homologación y conteos CSV. Chromium recorre las 60 selecciones, exclusión de otros paneles, retorno al panel S1000RR y anchura móvil. La suite global conserva las 701 selecciones existentes y restricciones técnicas. Resultados: `VALIDACION_RC11.json`.
