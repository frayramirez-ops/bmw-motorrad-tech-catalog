/* HEX support profiles are diagnostic references, never an identification of installed hardware. */
const diagnosticProfileData = window.BMW_DIAGNOSTIC_PROFILES;
const diagnosticProfileRecords = new Map(diagnosticProfileData.records.map(r => [r.recordId,r]));
const diagnosticProfileDefinitions = new Map(diagnosticProfileData.profiles.map(r => [r.id,r]));
const diagnosticProfileLabels = {
 perfil_motor:'Perfil HEX para diagnóstico del motor',
 perfil_acceso:'Perfil HEX de acceso / inmovilizador',
 arquitectura_diagnostico:'Arquitectura de diagnóstico publicada',
 software_diagnostico:'Aplicación de diagnóstico indicada',
 plataforma_documental:'Modelo y periodo de la tabla',
 formato_documental:'Formato de referencia publicado',
};
function diagnosticProfileFor(recordId) {
 const value = diagnosticProfileRecords.get(recordId);
 return value && value.profileIds.length ? value : null;
}
function appendDiagnosticProfile(panel,review) {
 'use strict';
 const record = diagnosticProfileFor(review.recordId);
 if (!record) return;
 function node(tag,text) {const n=document.createElement(tag);n.textContent=text;return n;}
 const section=node('section','');section.dataset.diagnosticProfile='true';
 section.append(node('h4','Perfiles del fabricante de la herramienta de diagnóstico'));
 section.append(node('p','Referencia HEX por modelo, plataforma y periodo. Estos nombres de la tabla de soporte no identifican pieza instalada, semiconductor ni equipamiento Keyless de una unidad.'));
 const list=document.createElement('dl');
 for (const [field,text] of Object.entries(record.fields)) {
  list.append(node('dt',diagnosticProfileLabels[field] || field));
  const value=node('dd',text);value.dataset.referenceFields=field;list.append(value);
 }
 section.append(list);
 for (const id of record.profileIds) {
  const definition=diagnosticProfileDefinitions.get(id);if(!definition)continue;
  let url;try{url=new URL(diagnosticProfileData.source.url);}catch(_){continue;}
  if(url.protocol!=='https:')continue;url.hash=id;
  const link=node('a','HEX Function Chart · '+definition.heading);link.href=url.href;
  link.target='_blank';link.rel='noopener noreferrer';const p=node('p','');p.append(link);section.append(p);
 }
 const before=panel.querySelector('[data-documented-claims]') || [...panel.children].find(n=>n.tagName==='H4');
 if(before)panel.insertBefore(section,before);else panel.append(section);
}
