# REF3.1 — guía de conexión HEX y preparación de componentes

La guía «Consultar conectores e interfaces HEX» se abre desde la cabecera del catálogo. Distingue el acoplamiento y el adaptador condicionado al puerto identificado y la versión de herramienta. No cambia el formato atribuido a ninguna ficha, las afirmaciones técnicas, las identidades ni las reglas de programación.

## Información contrastada

Se consultaron dos páginas del fabricante HEX el 7 de noviembre de 2026:

- https://www.hexgs911.com/connecting-to-your-bike/ — secciones de conexión de diez/dieciséis pines y adaptadores.
- https://www.hexgs911.com/faq/my-new-bike-has-a-square-obd-connector-not-a-round-one/ — compatibilidad de las interfaces wifi, USB Generation 2 y restricción de la amarilla antigua.

Las cinco referencias normalizadas, citas y huellas de las capturas están en `hex-connector-reference.json`. Las capturas completas se conservan fuera de la distribución; la guía no carga scripts, fotos ni páginas remotas. El contenido útil está disponible sin Internet y puede imprimirse. Los enlaces permiten consultar el origen cuando hay conexión.

## Selección de conexión

Hay veinte combinaciones entre cuatro estados de puerto y cinco estados de herramienta. Tres describen acoplamiento directo por el formato declarado, tres requieren adaptador, una conserva el rechazo explícito de compatibilidad eléctrica y trece no permiten resolver una conexión con los datos disponibles.

La GS-911wifi de diez pines puede utilizar el adaptador hacia el puerto OBD-II de dieciséis pines que documenta HEX. La GS-911wifi OBD-II y la GS-911usb Generation 2 OBD-II pueden usar el adaptador Female OBD hacia el puerto redondo de diez pines. Estas indicaciones no se trasladan a cualquier herramienta que comparta una carcasa o conector.

**La interfaz GS-911 amarilla antigua no funciona con el adaptador hacia OBD-II, por incompatibilidad eléctrica según HEX.** Un adaptador mecánico no resuelve esa restricción. Para el formato legado de tres pines y las demás combinaciones sin evidencia, la guía mantiene el resultado sin acreditar.

La selección comienza sin identificar puerto ni interfaz. La guía no selecciona un puerto por año, nombre del modelo, perfil de bus o código histórico C10/C16. La coincidencia física no garantiza protocolo, soporte de ECUs, funciones o programación de llaves. No se facilita un pinout ni se prescribe modificar cableado.

## Preparación del siguiente bloque de datos

Se incorpora la cola reproducible de `COMPONENTES_BLOQUE_4.md`: 192 lotes, 500 identidades y 1000 afirmaciones. Las 862 pendientes y 138 referencias limitadas de homologación conservan exactamente su estado. La cola sirve para contrastar fuentes por grupos, no para certificar componentes. El acceso a TMPro/OBDSTAR continúa pendiente de aplicar la configuración del entorno.

La guía es una ampliación de recursos, no un cierre de pendientes de hardware. La cobertura de referencia, los 789 perfiles de diagnóstico y las 3760 afirmaciones mantienen los mismos números que REF3.0.

## Validación

`tests/test_connector_guide.py` comprueba las veinte combinaciones, el rechazo de la amarilla antigua, las dos direcciones de adaptador, reinicio a puerto desconocido, impresión de la restricción, anchura móvil, fuentes y ausencia de solicitudes remotas/errores JavaScript. `tests/test_component_batches.py` verifica la conservación de las 1000 afirmaciones y separación de los lotes. La regresión completa y la entrega extraída se registran en `VALIDACION_REF3_1.json` y `VALIDACION_ENTREGA_REF3_1.json`.
