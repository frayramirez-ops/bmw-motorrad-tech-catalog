"""Verify a relocated release with remote browser requests blocked and sample PDF output."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import platform
import re
import subprocess
import sys
import tempfile
import urllib.parse
import urllib.request
import zipfile

from package_release import verify


SAMPLES = [
    ('F800GS (798 cc)', 2008, 'Mecánica'),
    ('R1250GS', 2023, 'Keyless (Principal)'),
    ('R1250GS Adventure', 2020, 'Keyless (Principal)'),
    ('C400GT', 2024, 'Keyless (Principal)'),
    ('G650GS', 2015, 'Mecánica'),
    ('K1600GTL', 2016, 'Keyless (Principal)'),
    ('M1000RR', 2026, 'CONFIRMAR SISTEMA'),
    ('S1000RR', 2023, 'Keyless (Principal)'),
    ('F850GS', 2020, 'Keyless (Principal)'),
    ('R1250RT', 2021, 'Keyless (Principal)'),
    ('S1000R', 2024, 'Keyless (Principal)'),
    ('R 1100 R', 2001, 'SISTEMA NO VERIFICADO'),
]
FIELDS = ['year', 'family', 'model', 'platform', 'system']


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify_delivery(archive_path, output_dir):
    from playwright.sync_api import sync_playwright

    archive_path = Path(archive_path).resolve()
    output_dir = Path(output_dir).resolve()
    require(not output_dir.exists(), 'El destino ya existe; usa otro para conservar la validación anterior.')
    manifest = verify(archive_path)
    output_dir.mkdir(parents=True)
    report = {
        'schema': 1, 'version': manifest['version']['version'],
        'archiveSha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
        'platform': platform.system(), 'relocatedPackage': True,
        'browserRemoteRequestsBlocked': True, 'technicalCertification': False,
        'scope': 'HTTP local en Linux; no prueba Windows/macOS, file://, impresora física ni aplicabilidad por VIN.',
        'applicationFilesSha256': {}, 'printSamples': [],
    }
    with tempfile.TemporaryDirectory(prefix='bmw cierre ') as folder:
        extracted = Path(folder) / 'Entrega local á'
        with zipfile.ZipFile(archive_path) as archive:
            archive.extractall(extracted)
        app = extracted / 'BMW_Motorrad_B8_REGENERADO'
        raw = re.search(r'<script id="catalogData"[^>]*>(.*?)</script>', (app/'index.html').read_text(), re.S)[1]
        catalog = json.loads(raw)
        coverage = json.loads((extracted/'docs/coverage-data.json').read_text())
        diagnostic_profiles={r['recordId']:r for r in json.loads((extracted/'docs/diagnostic-profile-bindings.json').read_text())['records']}
        process = subprocess.Popen(
            [sys.executable, str(extracted/'scripts/serve_catalog.py'), '--port', '0', '--no-browser'],
            cwd=folder, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
        )
        try:
            line = process.stdout.readline()
            match = re.search(r'http://127\.0\.0\.1:\d+/', line)
            require(match is not None, 'El iniciador extraído no devolvió una dirección local: '+line)
            base = match[0]
            for path in sorted(app.rglob('*')):
                if not path.is_file():
                    continue
                relative = path.relative_to(app).as_posix()
                expected = hashlib.sha256(path.read_bytes()).hexdigest()
                with urllib.request.urlopen(base+urllib.parse.quote(relative, safe='/'), timeout=10) as response:
                    require(response.status == 200, 'HTTP local incorrecto: '+relative)
                    require(hashlib.sha256(response.read()).hexdigest() == expected, 'Recurso diferente al paquete: '+relative)
                report['applicationFilesSha256'][relative] = expected
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
                context = browser.new_context()
                blocked = set()

                def local_only(route):
                    if route.request.url.startswith(base):
                        route.continue_()
                    else:
                        blocked.add(route.request.url)
                        route.abort()

                context.route('**/*', local_only)
                page = context.new_page()
                errors = []
                page.on('pageerror', lambda error: errors.append(str(error)))
                page.goto(base, wait_until='networkidle')
                with page.expect_download() as event:
                    page.get_by_role('link', name='Descargar matriz de datos disponibles (CSV)').click()
                with open(event.value.path(), encoding='utf-8-sig', newline='') as handle:
                    matrix_rows = list(csv.DictReader(handle))
                require(len(matrix_rows) == 815, 'Matriz de datos disponibles incompleta')
                report['referenceMatrixRowsDownloaded'] = len(matrix_rows)
                for model, year, system in SAMPLES:
                    transponder = next(r for r in catalog['transponders'] if r['model'] == model and r['year'] == year and r['system'] == system)
                    diagnostic = next(r for r in catalog['diagnostico'] if all(r[k] == transponder[k] for k in FIELDS[:4]))
                    for section, record in [('transponders', transponder), ('diagnostico', diagnostic)]:
                        page.emulate_media(media='screen')
                        page.evaluate('''item=>{
                          setTab(item.section,{reset:true});const r=item.record;
                          for(let i=0;i<4;i++){$(ids[i]).value=String(r[ids[i]]);cascade(i+1);}
                          const declaration=document.getElementById('bmwSystemDeclaration');
                          if(item.section==='transponders'&&!declaration.hidden){
                            const label=/keyless/i.test(r.system)?'Keyless':/mecánica|ews/i.test(r.system)?'Mecánica':null;
                            const b=[...declaration.querySelectorAll('button')].find(b=>b.textContent===label);if(b)b.click();
                          }
                          $('system').value=r.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));
                        }''', {'section': section, 'record': record})
                        require(not page.locator('#v603Panel').is_visible(), 'El resumen histórico duplicado está visible')
                        require(page.locator('#resultTitle').inner_text() == f'BMW {model} · {year}', 'Identidad de impresión incorrecta')
                        record_id=section+':'+json.dumps([str(record[k])for k in FIELDS],ensure_ascii=False,separators=(',',':'))
                        expected_profile=diagnostic_profiles[record_id]
                        profile_panel=page.locator('#result [data-diagnostic-profile]')
                        require(profile_panel.count()==(1 if expected_profile['profileIds'] else 0),'Perfil de diagnóstico ajeno o ausente: '+record_id)
                        if expected_profile['profileIds']:
                            require(profile_panel.is_visible(),'Perfil publicado oculto: '+record_id)
                            for field,value in expected_profile['fields'].items():
                                require(profile_panel.locator('[data-reference-fields="'+field+'"]').inner_text()==value,'Valor de perfil incorrecto: '+field)
                        if model=='R 1100 R' and section=='diagnostico':
                            require('tres pines' in page.locator('#details').inner_text(),'Falta la corrección de formato legado R1100')
                            require(page.locator('#gallery img').count()==0,'Se asoció una imagen C10 heredada al formato de tres pines')
                            report['threePinFormatAndImageExclusionVerified']=True
                        if model == 'R1250RT' and year == 2021 and section == 'transponders':
                            battery = page.locator('#rTouringEvidence [data-reference-fields~="pila_mando"]').inner_text()
                            require('CR1632' in battery and 'CR2032' not in battery, 'La RT heredó una pila Keyless incorrecta')
                            report['rtCr1632ExceptionVerified'] = True
                        if model == 'R1250GS Adventure' and year == 2020:
                            reference = page.locator('#r1250Evidence [data-reference-facts]')
                            require(reference.is_visible(), 'Falta la ficha actualizada de Adventure 2020')
                            require('lateral derecho' in reference.inner_text(), 'Falta ubicación documentada de diagnóstico')
                            if section == 'transponders':
                                require('CR2032' in reference.inner_text() and 'HUF5750' in reference.inner_text(), 'Faltan datos de mando de Adventure 2020')
                        if section == 'transponders':
                            require('Chip y programación no validados' in page.locator('#status').inner_text(), 'La muestra perdió su restricción técnica')
                            require(page.locator('#gallery img').count() == 0, 'La muestra liberó una imagen técnica')
                        page.emulate_media(media='print')
                        name = f'{record["family"]}_{section}_{year}.pdf'
                        pdf = output_dir / name
                        page.pdf(path=str(pdf), format='A4', print_background=True)
                        text = subprocess.check_output(['pdftotext', str(pdf), '-']).decode()
                        compact = ' '.join(text.split())
                        require('Auditoría de registros no confirmados' not in compact, 'Se imprimió el aviso global de auditoría: '+name)
                        require('Resultado heredado:' not in compact, 'Se imprimió el histórico B8 como dato de consulta: '+name)
                        require(model in compact and str(year) in compact, 'Falta identidad en PDF: '+name)
                        if section == 'transponders':
                            require('Chip y programación no validados' in compact, 'Falta restricción impresa: '+name)
                            first_page=' '.join(subprocess.check_output(['pdftotext','-f','1','-l','1',str(pdf),'-']).decode().split())
                            require('Chip y programación no validados' in first_page, 'La restricción no aparece en la primera página: '+name)
                            if model == 'R1250RT' and year == 2021:
                                require('CR1632' in first_page, 'La primera página oculta el dato útil de pila RT: '+name)
                            require(record['result'] not in compact or record['result'].startswith('SIN '), 'Resultado histórico restringido visible en PDF: '+name)
                        info = subprocess.check_output(['pdfinfo', str(pdf)]).decode()
                        pages = int(re.search(r'^Pages:\s+(\d+)', info, re.M)[1])
                        report['printSamples'].append({
                            'section': section, 'identity': {k: record[k] for k in FIELDS},
                            'pdf': name, 'pages': pages,
                            'sha256': hashlib.sha256(pdf.read_bytes()).hexdigest(),
                            'identityTextVerified': True, 'technicalRestrictionVerified': True if section == 'transponders' else None,
                        })
                page.emulate_media(media='screen')
                page.get_by_role('link', name='Consultar cobertura documental del catálogo').click()
                page.wait_for_load_state('networkidle')
                require(str(coverage['summary']['records'])+' fichas' in page.locator('#coverageCount').inner_text(), 'La cobertura extraída no funciona')
                page.get_by_role('link', name='Consultar pendientes técnicos y evidencia necesaria').click()
                page.wait_for_load_state('networkidle')
                require(str(coverage['summary']['claimsPending'])+' afirmaciones' in page.locator('#pendingCount').inner_text(), 'Los pendientes extraídos no funcionan')
                page.get_by_role('link', name='Volver al catálogo').click()
                page.wait_for_load_state('networkidle')
                page.get_by_role('link', name='Consultar conectores e interfaces HEX').click()
                page.wait_for_load_state('networkidle')
                require(page.locator('#connectionResult').get_attribute('data-state')=='unresolved','La guía dedujo un puerto sin identificarlo')
                page.select_option('#vehiclePort','obd16')
                page.select_option('#hexDevice','yellow')
                require(page.locator('#connectionResult').get_attribute('data-state')=='incompatible','La guía extraída no conserva el rechazo de la interfaz amarilla antigua')
                page.select_option('#vehiclePort','round10')
                page.select_option('#hexDevice','usb2obd')
                require('Female OBD' in page.locator('#connectionResult').inner_text(),'La guía extraída perdió el sentido del adaptador')
                report['connectorGuideLegacyRejectionAndDirectionVerified']=True
                page.goto(base+'GALERIA_FOTOGRAFICA_OEM.html', wait_until='networkidle')
                require(page.locator('#galleryGrid .card').count() == 24, 'La biblioteca extraída no está completa')
                for image in page.locator('#galleryGrid img').all():
                    image.scroll_into_view_if_needed()
                    image.evaluate('(image)=>{image.loading="eager"}')
                page.wait_for_function("[...document.querySelectorAll('#galleryGrid img')].every(i=>i.complete&&i.naturalWidth>0)")
                report['galleryImagesVerified'] = page.locator('#galleryGrid img').count()
                require(not errors, 'Errores JavaScript en entrega extraída: '+str(errors))
                report['javascriptErrors'] = errors
                report['blockedRemoteRequestCount'] = len(blocked)
                report['auxiliaryPagesVerified'] = ['coverage', 'pending', 'gallery']
                context.close()
                browser.close()
        finally:
            process.terminate()
            process.communicate(timeout=5)
    report['status'] = 'VERIFICADO_EN_LINUX_LOCAL'
    report['applicationFilesVerified'] = len(report['applicationFilesSha256'])
    (output_dir/'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', required=True, type=Path)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    report = verify_delivery(args.archive, args.output_dir)
    print(f'{report["version"]}: {report["applicationFilesVerified"]} archivos HTTP verificados, {len(report["printSamples"])} PDF de muestra; sin errores JavaScript.')


if __name__ == '__main__':
    main()
