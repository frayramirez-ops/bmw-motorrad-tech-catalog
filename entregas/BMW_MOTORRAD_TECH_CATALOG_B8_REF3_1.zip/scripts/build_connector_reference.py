"""Publish the reviewed factual connector reference as local script data."""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def generated_content():
    data = json.loads((ROOT / 'docs/hex-connector-reference.json').read_text())
    sources = {s['id']: s for s in data['sources']}
    if len(sources) != len(data['sources']):
        raise ValueError('Fuentes duplicadas')
    for source in sources.values():
        if source['status'] != 'CONTENIDO_CONSULTADO' or len(source['sha256']) != 64:
            raise ValueError('Falta evidencia consultada')
        if not source['url'].startswith('https://www.hexgs911.com/'):
            raise ValueError('Origen inesperado')
    for fact in data['facts']:
        if fact['sourceId'] not in sources or not fact['quote'] or not fact['finding']:
            raise ValueError('Afirmación sin referencia')
    return 'window.BMW_CONNECTOR_REFERENCE=' + json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c') + ';\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    path = ROOT / 'BMW_Motorrad_B8_REGENERADO/connector-reference-data.js'
    content = generated_content()
    if args.check:
        if path.read_text() != content:
            raise ValueError('Referencia de conexión obsoleta')
    else:
        path.write_text(content)
    print('Referencia de conexión HEX sincronizada.')


if __name__ == '__main__':
    main()
