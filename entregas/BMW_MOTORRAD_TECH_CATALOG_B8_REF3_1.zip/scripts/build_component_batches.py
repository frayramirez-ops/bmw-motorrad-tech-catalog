"""Prepare evidence-review batches without changing claims or application data."""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import io
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PENDING = 'PENDIENTE_CONTRASTE_DOCUMENTAL'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def generated_files():
    docs = ROOT / 'docs'
    coverage = json.loads((docs / 'coverage-data.json').read_text())
    profile_bytes = (docs / 'diagnostic-profile-bindings.json').read_bytes()
    profiles = {r['recordId']: r for r in json.loads(profile_bytes)['records']}
    inputs = {'diagnostic-profile-bindings.json': digest(profile_bytes)}
    contexts = defaultdict(list)
    seen = set()
    for filename, expected in coverage['inputs']['reviewSha256'].items():
        data = (docs / filename).read_bytes()
        if digest(data) != expected:
            raise ValueError('Cobertura obsoleta: ' + filename)
        inputs[filename] = expected
        review = json.loads(data)
        sources = {s['id']: s for s in review['sources']}
        for row in review['records']:
            if row['section'] != 'transponders':
                continue
            if row['recordId'] in seen:
                raise ValueError('Identidad duplicada: ' + row['recordId'])
            seen.add(row['recordId'])
            ident = row['identity']
            profile_ids = tuple(profiles[row['recordId']]['profileIds'])
            # Exact identity fields, including emergency/primary, remain separate.
            key = tuple(str(ident[k]) for k in ['family', 'model', 'platform', 'system'])
            key += (profile_ids, row['status'] == 'HIPOTESIS_NO_ACREDITADA')
            claims = [c for c in row['claims'] if c['topic'] in {'chip', 'modulo'}]
            if {c['topic'] for c in claims} != {'chip', 'modulo'} or len(claims) != 2:
                raise ValueError('Falta desglose chip/módulo: ' + row['recordId'])
            contexts[key].append({
                'recordId': row['recordId'], 'identity': ident, 'review': filename,
                'recordStatus': row['status'],
                'unverifiedB8Result': row.get('b8Result', ''),
                'claims': [{
                    'topic': c['topic'], 'status': c['status'],
                    'finding': c.get('finding', ''), 'limitation': c.get('limitation', ''),
                    'nextAction': c.get('nextAction', ''),
                    'sources': [{'id': sid, 'url': sources[sid]['url'],
                                 'status': sources[sid]['status']}
                                for sid in c.get('sourceIds', [])],
                    'observations': c.get('observations', []),
                } for c in claims],
            })
    groups = []
    for key, records in sorted(contexts.items()):
        ordered = sorted(records, key=lambda r: int(r['identity']['year']))
        # A missing year is an applicability gap, not a continuous interval.
        runs = []
        for row in ordered:
            if not runs or int(row['identity']['year']) != int(runs[-1][-1]['identity']['year']) + 1:
                runs.append([])
            runs[-1].append(row)
        for run in runs:
            years = [int(r['identity']['year']) for r in run]
            identity = [*key[:4], list(key[4]), key[5], years]
            group_id = 'COMP-' + digest(json.dumps(identity, ensure_ascii=False).encode())[:16]
            counts = Counter(c['status'] for r in run for c in r['claims'])
            groups.append({
                'id': group_id, 'family': key[0], 'model': key[1], 'platform': key[2],
                'system': key[3], 'years': years, 'diagnosticProfileLeads': list(key[4]),
                'hypothesisExcludedFromApplicability': key[5],
                'claimStatusCounts': dict(sorted(counts.items())), 'records': run,
            })
    groups.sort(key=lambda g: (g['hypothesisExcludedFromApplicability'],
                              -g['claimStatusCounts'].get(PENDING, 0),
                              -len(g['records']), g['id']))
    for rank, group in enumerate(groups, 1):
        group['reviewOrder'] = rank
    claims = [c for g in groups for r in g['records'] for c in r['claims']]
    summary = {
        'records': len(seen), 'claims': len(claims), 'batches': len(groups),
        'pendingClaims': sum(c['status'] == PENDING for c in claims),
        'limitedReferenceClaims': sum(c['status'] != PENDING for c in claims),
        'hypothesisRecordsExcluded': sum(len(g['records']) for g in groups if g['hypothesisExcludedFromApplicability']),
        'families': sorted({g['family'] for g in groups}),
    }
    payload = {
        'schema': 1, 'scope': 'Cola de investigación; no identifica piezas ni modifica estados técnicos.',
        'grouping': 'Modelo/plataforma/sistema exactos, años consecutivos y perfiles diagnósticos iguales. El grupo organiza lectura; no acredita equivalencia de hardware.',
        'priority': 'Hipótesis al final; primero mayor número de afirmaciones pendientes. No mide ventas ni prevalencia.',
        'unverifiedB8ResultWarning': 'Texto histórico sin validar: términos de búsqueda, nunca compatibilidad aprobada.',
        'inputsSha256': inputs, 'summary': summary, 'batches': groups,
    }
    output = io.StringIO(newline='')
    writer = csv.writer(output)
    writer.writerow(['lote', 'orden_revision', 'identidad', 'anio', 'familia', 'modelo',
                     'plataforma', 'sistema', 'hipotesis_no_aplicable', 'afirmacion',
                     'estado_actual', 'hallazgo', 'fuentes', 'observaciones',
                     'limite', 'siguiente_accion', 'texto_B8_NO_VALIDADO'])
    for group in groups:
        for row in group['records']:
            ident = row['identity']
            for claim in row['claims']:
                writer.writerow([
                    group['id'], group['reviewOrder'], row['recordId'],
                    *[ident[k] for k in ['year', 'family', 'model', 'platform', 'system']],
                    group['hypothesisExcludedFromApplicability'], claim['topic'], claim['status'],
                    claim['finding'], ';'.join(s['url'] for s in claim['sources']),
                    ';'.join(claim['observations']), claim['limitation'], claim['nextAction'],
                    row['unverifiedB8Result'],
                ])
    return {
        docs / 'component-review-batches.json': json.dumps(payload, ensure_ascii=False, indent=2) + '\n',
        docs / 'COMPONENTES_LOTES_REVISION.csv': '\ufeff' + output.getvalue(),
    }, summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    outputs, summary = generated_files()
    for path, content in outputs.items():
        if args.check:
            if not path.exists() or path.read_bytes() != content.encode():
                raise ValueError('Salida obsoleta: ' + str(path))
        else:
            path.write_bytes(content.encode())
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    main()
