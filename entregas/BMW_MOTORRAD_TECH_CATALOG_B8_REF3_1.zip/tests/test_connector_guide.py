import functools
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'BMW_Motorrad_B8_REGENERADO'


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *_):
        pass


class ConnectorGuideTests(unittest.TestCase):
    def test_local_reference_has_consulted_sources_and_no_model_assignments(self):
        result = subprocess.run([sys.executable, str(ROOT / 'scripts/build_connector_reference.py'), '--check'], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        data = json.loads((ROOT / 'docs/hex-connector-reference.json').read_text())
        self.assertEqual(len(data['sources']), 2)
        self.assertEqual(len(data['facts']), 5)
        self.assertNotIn('models', data)
        facts = {f['id']: f for f in data['facts']}
        self.assertIn('electrically compatible', facts['yellow-incompatible']['quote'])
        self.assertIn('Generation 2', facts['obd-to-round']['finding'])
        for script in ['connector-guide.js', 'connector-reference-data.js']:
            result = subprocess.run(['node', '--check', str(APP / script)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_all_connection_choices_legacy_rejection_offline_and_print(self):
        server = ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(QuietHandler, directory=str(APP)))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with sync_playwright() as playwright:
                browser = playwright.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
                context = browser.new_context(viewport={'width': 375, 'height': 812})
                blocked = []
                base = f'http://127.0.0.1:{server.server_port}/'
                def route(request):
                    if request.request.url.startswith(base):
                        request.continue_()
                    else:
                        blocked.append(request.request.url)
                        request.abort()
                context.route('**/*', route)
                page = context.new_page()
                errors = []
                page.on('pageerror', lambda error: errors.append(str(error)))
                page.goto(base, wait_until='networkidle')
                page.get_by_role('link', name='Consultar conectores e interfaces HEX').click()
                result = page.locator('#connectionResult')
                self.assertEqual(page.locator('#vehiclePort').input_value(), 'unknown')
                self.assertEqual(result.get_attribute('data-state'), 'unresolved')
                self.assertEqual(page.locator('#connectionFacts article').count(), 5)
                states = []
                for port in ['unknown', 'round10', 'obd16', 'legacy3']:
                    page.select_option('#vehiclePort', port)
                    for device in ['unknown', 'wifi10', 'wifi16', 'usb2obd', 'yellow']:
                        page.select_option('#hexDevice', device)
                        state = result.get_attribute('data-state')
                        states.append(state)
                        if port in ['unknown', 'legacy3'] or device == 'unknown':
                            self.assertEqual(state, 'unresolved', (port, device))
                        if port == 'obd16' and device == 'yellow':
                            self.assertEqual(state, 'incompatible')
                            self.assertIn('incompatibilidad eléctrica', result.inner_text())
                        if port == 'round10' and device in ['wifi16', 'usb2obd']:
                            self.assertIn('Female OBD', result.inner_text())
                        if port == 'obd16' and device == 'wifi10':
                            self.assertIn('Male', result.inner_text())
                self.assertEqual({s: states.count(s) for s in set(states)}, {'direct': 3, 'adapter': 3, 'incompatible': 1, 'unresolved': 13})
                self.assertTrue(page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
                page.select_option('#vehiclePort', 'obd16')
                page.select_option('#hexDevice', 'yellow')
                with tempfile.TemporaryDirectory() as folder:
                    pdf = Path(folder) / 'conexion.pdf'
                    page.pdf(path=str(pdf), format='A4', print_background=True)
                    text = subprocess.check_output(['pdftotext', str(pdf), '-']).decode()
                    self.assertIn('incompatibilidad eléctrica', text)
                    self.assertIn('GS-911 amarilla antigua', text)
                page.select_option('#vehiclePort', 'unknown')
                self.assertEqual(result.get_attribute('data-state'), 'unresolved')
                self.assertEqual(blocked, [])
                self.assertEqual(errors, [])
                browser.close()
        finally:
            server.shutdown()
            server.server_close()
            thread.join()


if __name__ == '__main__':
    unittest.main()
