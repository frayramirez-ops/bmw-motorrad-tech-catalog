(function(){
 'use strict';
 const data=window.BMW_CONNECTOR_REFERENCE;
 const port=document.getElementById('vehiclePort');
 const device=document.getElementById('hexDevice');
 const result=document.getElementById('connectionResult');
 function decision(p,d){
  if(!['round10','obd16','legacy3'].includes(p)||!['wifi10','wifi16','usb2obd','yellow'].includes(d))return {state:'unresolved',title:'Falta identificar el puerto o la interfaz',text:'Selecciona ambos a partir del puerto real y de la identificación de la herramienta. Esta guía no los deduce del año ni del modelo.',sources:[]};
  if(p==='obd16'&&d==='yellow')return {state:'incompatible',title:'Adaptador no compatible con la interfaz amarilla antigua',text:'HEX advierte que el adaptador para el puerto OBD-II no funciona con la GS-911 amarilla antigua por incompatibilidad eléctrica. Un cambio de conector no resuelve esa incompatibilidad.',sources:['HEX-CONN-2']};
  if(p==='legacy3'||d==='yellow')return {state:'unresolved',title:'Combinación sin acreditar en esta guía',text:'Las fuentes de conexión consultadas no bastan para seleccionar un adaptador y confirmar esta combinación. Consulta el soporte específico del fabricante; no se aplica la regla de 10/16 pines al formato de tres pines.',sources:['HEX-CONN-1','HEX-CONN-2']};
  if((p==='round10'&&d==='wifi10')||(p==='obd16'&&['wifi16','usb2obd'].includes(d)))return {state:'direct',title:'Conexión física directa según los formatos seleccionados',text:'Los formatos declarados coinciden. Esto describe el acoplamiento, no garantiza soporte electrónico, funciones, programación ni compatibilidad con un modelo o una unidad.',sources:['HEX-CONN-1','HEX-CONN-2']};
  if(p==='round10')return {state:'adapter',title:'Adaptador HEX Female OBD hacia puerto redondo de 10 pines',text:'HEX documenta el Female OBD Adaptor para conectar GS-911wifi OBD-II o GS-911usb Generation 2 OBD-II a puertos de diez pines. Comprueba ambos extremos, la versión de la herramienta y el soporte del modelo antes de conectarlo.',sources:['HEX-CONN-1','HEX-CONN-2']};
  return {state:'adapter',title:'Adaptador HEX Male hacia puerto OBD-II de 16 pines',text:'HEX documenta un adaptador para GS-911wifi de diez pines hacia motos con puerto OBD-II de dieciséis pines. Esta referencia no incluye la interfaz amarilla antigua. Comprueba ambos extremos y el soporte del modelo.',sources:['HEX-CONN-1','HEX-CONN-2']};
 }
 function sourceLink(id){
  const s=data.sources.find(x=>x.id===id);const a=document.createElement('a');
  a.href=s.url;a.target='_blank';a.rel='noopener noreferrer';a.textContent=id;return a;
 }
 function render(){
  const answer=decision(port.value,device.value);result.replaceChildren();result.dataset.state=answer.state;
  const title=document.createElement('h3');title.textContent=answer.title;
  const text=document.createElement('p');text.textContent=answer.text;result.append(title,text);
  if(answer.sources.length){const refs=document.createElement('p');refs.append('Fuente: ');answer.sources.forEach((id,i)=>{if(i)refs.append(' · ');refs.append(sourceLink(id));});result.append(refs);}
 }
 for(const fact of data.facts){const item=document.createElement('article');const p=document.createElement('p');p.textContent=fact.finding;item.append(p,sourceLink(fact.sourceId));document.getElementById('connectionFacts').append(item);}
 for(const s of data.sources){const li=document.createElement('li');li.append(sourceLink(s.id),' · '+s.sections.join(' / ')+' · Consultada: '+s.consultedOn);document.getElementById('connectionSources').append(li);}
 port.addEventListener('change',render);device.addEventListener('change',render);
 document.getElementById('printGuide').addEventListener('click',()=>window.print());render();
})();
