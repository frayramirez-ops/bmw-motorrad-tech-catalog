"""Final R review must retain unknown historical immobilizers and separate modern access paths."""
import csv
import functools
import hashlib
import json
import re
import threading
import unittest
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from test_recovery import APP,ROOT,QuietHandler

PENDING='PENDIENTE_CONTRASTE_DOCUMENTAL'

class RFinalTests(unittest.TestCase):
    def test_old_unknowns_and_modern_provenance(self):
        review=json.loads((ROOT/'docs/r-final-reconciliation.json').read_text())
        html=(APP/'index.html').read_text()
        self.assertEqual(review,json.loads(re.search(r'<script id="rFinalEvidenceData"[^>]*>(.*?)</script>',html,re.S)[1]))
        db=json.loads(re.search(r'<script id="catalogData"[^>]*>(.*?)</script>',html,re.S)[1])
        sources={s['id']:s for s in review['sources']};observations={o['id']:o for o in review['observations']}
        self.assertEqual((len(review['records']),len(sources),(len(observations)-len(review['bulkReferenceUpdate']['additionalObservationIds']))),(46,25,46))
        self.assertEqual(sum(s.get('retrieval',{}).get('type')=='.pdf'for s in sources.values()),15)
        self.assertEqual(sum(s['status']=='CITADA_SIN_VERIFICAR'for s in sources.values()),6)
        pending=0;limited=0;specialist=0;old_trans=0;conflicts=0
        for row in review['records']:
            ident=row['identity'];original=next(r for r in db[row['section']]if all(r[k]==v for k,v in ident.items()))
            self.assertEqual(row['b8RecordSha256'],hashlib.sha256(json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            refs=[x['sourceId']for x in row['references']];self.assertEqual(len(refs),len(set(refs)))
            modern=ident['year']>=2024
            if modern:
                primary=sources[row['references'][0]['sourceId']]
                self.assertIn(ident['model'],primary['models']);self.assertLessEqual(primary['editionYear'],ident['year'])
                self.assertTrue(primary['discovery']['indexEntries'])
            if any('CONFLICTO_CRONOLOGICO'in f for f in row['findings']):conflicts+=1
            if not modern and row['section']=='transponders':
                old_trans+=1;self.assertTrue(all(c['status']==PENDING for c in row['claims']))
            if ident['model']in['R 1100 S Light','R 1200 C Montana','R 1200 C Phoenix']:
                self.assertTrue(all(c['status']==PENDING for c in row['claims']))
            for c in row['claims']:
                if c['topic']in['chip','modulo','conector','mercado_equipamiento']:self.assertEqual(c['status'],PENDING)
                if c['status']==PENDING:pending+=1
                else:
                    limited+=1;self.assertTrue(c['observations'])
                    if c['status']=='REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE':
                        specialist+=1;self.assertFalse(modern);self.assertIn(c['topic'],['acceso','ubicacion'])
                    else:self.assertEqual(c['sourceIds'],[primary['id']])
                for oid in c['observations']:
                    o=observations[oid];self.assertIn(o['sourceId'],c['sourceIds'])
                    self.assertEqual(o['documentSha256'],sources[o['sourceId']]['retrieval']['sha256'])
            if ident['model']=='R 18 Roctane':
                market=next(c for c in row['claims']if c['topic']=='mercado_equipamiento')
                self.assertEqual(market['status'],PENDING);self.assertTrue(market['observations'])
        self.assertEqual((pending,limited,specialist,old_trans,conflicts),(151,56,24,15,6))
        for name,count in [('R_FINAL_AFIRMACIONES.csv',207),('R_FINAL_PENDIENTES.csv',151)]:
            with(ROOT/'docs'/name).open(encoding='utf-8-sig',newline='')as f:self.assertEqual(len(list(csv.DictReader(f))),count)

    def test_browser_all_records_and_edition_labels(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(QuietHandler,directory=str(APP)))
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            with sync_playwright()as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
                page=browser.new_page();page.set_default_timeout(6000);errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
                review=json.loads((ROOT/'docs/r-final-reconciliation.json').read_text());sources={s['id']:s for s in review['sources']}
                select='''row=>{
                    setTab(row.section,{reset:true});
                    for(let i=0;i<4;i++){$(ids[i]).value=String(row.identity[ids[i]]);cascade(i+1);}
                    const declaration=document.getElementById('bmwSystemDeclaration');
                    const name=/keyless/i.test(row.identity.system)?'Keyless':/mecánica|ews/i.test(row.identity.system)?'Mecánica':null;
                    if(row.section==='transponders'&&!declaration.hidden&&name){
                      const b=[...declaration.querySelectorAll('button')].find(b=>b.textContent===name);if(b)b.click();
                    }
                    $('system').value=row.identity.system;$('system').dispatchEvent(new Event('change',{bubbles:true}));
                }'''
                for row in review['records']:
                    with self.subTest(record=row['recordId']):
                        page.evaluate(select,row)
                        panel=page.locator('#rFinalEvidence');self.assertTrue(panel.is_visible())
                        self.assertEqual(panel.get_attribute('data-record-id'),row['recordId'])
                        for other in ['f800Evidence','s1000rrEvidence','r1250Evidence','r1200Evidence','rTouringEvidence','ninetEvidence']:
                            self.assertFalse(page.locator('#'+other).is_visible())
                        text=panel.inner_text();links=panel.locator('a').all_text_contents()
                        self.assertTrue(any(sources[row['references'][0]['sourceId']]['documentEdition']in label for label in links))
                        if row['identity']['year']>=2024 and row['section']=='diagnostico':
                            model=row['identity']['model']
                            expected='carenado izquierdo'if model.startswith('R 18')else'cubierta del conector'if model.startswith('R 12 ')else'asiento del conductor'
                            self.assertIn(expected,text)
                        if row['section']=='transponders':
                            self.assertIn('Chip y programación no validados',page.locator('#status').inner_text());self.assertEqual(page.locator('#gallery img').count(),0)
                page.set_viewport_size({'width':375,'height':812});self.assertFalse(page.evaluate('document.documentElement.scrollWidth>innerWidth'))
                old=json.loads((ROOT/'docs/ninet-reconciliation.json').read_text())['records'][0]
                page.evaluate(select,old)
                self.assertTrue(page.locator('#ninetEvidence').is_visible());self.assertFalse(page.locator('#rFinalEvidence').is_visible())
                self.assertEqual(errors,[]);browser.close()
        finally:server.shutdown();server.server_close()
