"""Build record-specific reference facts and their availability matrix from reviewed evidence."""
import argparse
import collections
import copy
import csv
import hashlib
import io
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'BMW_Motorrad_B8_REGENERADO'
REGISTRIES = {
    'f800-reconciliation.json': 'f800EvidenceData',
    's1000rr-reconciliation.json': 's1000EvidenceData',
    'r1250gs-reconciliation.json': 'r1250EvidenceData',
    'r1200gs-reconciliation.json': 'r1200EvidenceData',
    'r1250rt-r1300gs-reconciliation.json': 'rTouringEvidenceData',
    'ninet-reconciliation.json': 'ninetEvidenceData',
    'r-final-reconciliation.json': 'rFinalEvidenceData',
    'f750-f850-reconciliation.json': 'f750f850EvidenceData',
    'f650-f700-reconciliation.json': 'f650f700EvidenceData',
    'f-final-reconciliation.json': 'fFinalEvidenceData',
    'k-reconciliation.json': 'kEvidenceData',
    'c-reconciliation.json': 'cEvidenceData',
    's-final-reconciliation.json': 'sFinalEvidenceData',
    'gm-reconciliation.json': 'gmEvidenceData',
}
PENDING = 'PENDIENTE_CONTRASTE_DOCUMENTAL'
DOCUMENTED = {
    'DOCUMENTADO_EN_EDICION_APLICABILIDAD_PENDIENTE',
    'REFERENCIA_ESPECIALISTA_APLICABILIDAD_PENDIENTE',
    'OPCION_DOCUMENTADA_APLICABILIDAD_PENDIENTE',
    'HOMOLOGACION_DOCUMENTADA_UNIDAD_PENDIENTE',
}
LABELS = {
    'sistema': 'Sistema', 'antena': 'Antena / lectura de llave',
    'chip': 'Chip citado en la fuente', 'modulo': 'Componente citado en la fuente',
    'ubicacion': 'Ubicación del diagnóstico', 'acceso': 'Acceso al diagnóstico',
    'conector': 'Conector', 'mercado_equipamiento': 'Mercado y equipamiento',
    'pila_mando': 'Pila del mando Keyless Ride', 'alcance_mando': 'Alcance del mando',
    'mando_homologacion': 'Mando citado en homologación',
}


def reference_for(row, observations, sources):
    """Only use facts linked to this record; never complete a field from year/family alone."""
    facts = []
    covered = set()
    allowed_sources = {r['sourceId'] for r in row['references']}
    allowed_sources.update(s for c in row['claims'] for s in c.get('sourceIds', []))
    claims = {c['topic']: c for c in row['claims']}
    for curated in row.get('curatedReferenceFacts', []):
        fields = set(curated['fields'])
        if fields & {'pila_mando', 'alcance_mando', 'mando_homologacion'} and 'Keyless' not in row['identity']['system']:
            raise ValueError('Keyless fact cannot complete another selected system: ' + row['recordId'])
        for field in fields & {'chip', 'modulo', 'conector', 'mercado_equipamiento'}:
            if field not in claims or claims[field]['status'] not in DOCUMENTED:
                raise ValueError('Curated fact cannot release a pending component claim: ' + field)
        if fields & covered:
            continue
        fact = copy.deepcopy(curated)
        validate_fact(fact, observations, sources)
        if any(observations[o]['sourceId'] not in allowed_sources for o in fact['observations']):
            raise ValueError('Reference source is not linked to this exact record: ' + row['recordId'])
        facts.append(fact)
        covered.update(fields)
    grouped = {}
    for claim in row['claims']:
        if claim['status'] == PENDING or claim['topic'] in covered:
            continue
        if claim['status'] not in DOCUMENTED:
            raise ValueError('Unknown claim status: ' + claim['status'])
        if not claim.get('finding') or not claim.get('observations'):
            raise ValueError('Documented claim lacks a concrete finding or observation: ' + row['recordId'])
        key = (claim['finding'], tuple(claim['observations']), claim['status'])
        fact = grouped.setdefault(key, {
            'label': '', 'value': claim['finding'], 'fields': [],
            'observations': claim['observations'], 'quality': claim['status'],
        })
        fact['fields'].append(claim['topic'])
    for fact in grouped.values():
        fact['label'] = ' / '.join(LABELS[f] for f in fact['fields'])
        validate_fact(fact, observations, sources)
        facts.append(fact)
    if not facts:
        return None
    identity = row['identity']
    scope = row.get('referenceScope') or (
        f"{identity['model']} · {identity['year']} · {identity['platform']} · {identity['system']}. "
        'Datos de las fuentes vinculadas a esta ficha; consultar edición y variante. '
        'No certifican equipamiento individual ni componentes sin evidencia.'
    )
    return {'reviewedOn': '2026-11-06', 'scope': scope, 'facts': facts}


def validate_fact(fact, observations, sources):
    if not fact.get('value') or not fact.get('fields') or not fact.get('observations'):
        raise ValueError('Reference fact is missing its value, field or source observation')
    for oid in fact['observations']:
        observation = observations[oid]
        source = sources[observation['sourceId']]
        if source['status'] != 'CONTENIDO_CONSULTADO':
            raise ValueError('Unverified source cannot generate a reference fact: ' + oid)
        if observation['documentSha256'] != source['retrieval']['sha256']:
            raise ValueError('Observation/source hash mismatch: ' + oid)
        if not observation.get('pdfPage') and not observation.get('section'):
            raise ValueError('Observation lacks a page or section: ' + oid)


def outputs():
    changed = {}
    html = (APP / 'index.html').read_text()
    inventory = []
    inputs = []
    claims_by_identity = {}
    for filename, data_id in REGISTRIES.items():
        path = ROOT / 'docs' / filename
        review = json.loads(path.read_text())
        source_input = copy.deepcopy(review)
        for row in source_input['records']:
            row.pop('referenceFacts', None)
        inputs.append({'path': filename, 'sha256': hashlib.sha256(json.dumps(
            source_input, ensure_ascii=False, sort_keys=True, separators=(',', ':')
        ).encode()).hexdigest()})
        observations = {o['id']: o for o in review['observations']}
        sources = {s['id']: s for s in review['sources']}
        for row in review['records']:
            for claim in row['claims']:
                claims_by_identity[(row['recordId'], claim['topic'])] = claim
            reference = reference_for(row, observations, sources)
            if reference:
                row['referenceFacts'] = reference
            else:
                row.pop('referenceFacts', None)
            values = {}
            for fact in reference['facts'] if reference else []:
                for field in fact['fields']:
                    values[field] = fact['value']
            inventory.append({
                'recordId': row['recordId'], 'registry': filename,
                'section': row['section'], 'identity': row['identity'],
                'selectable': row['identity']['system'] != 'Keyless (Emergencia)',
                'hasReference': bool(reference), 'fields': values,
                'pendingTopics': [c['topic'] for c in row['claims'] if c['status'] == PENDING],
            })
        changed[path] = json.dumps(review, ensure_ascii=False, indent=2) + '\n'
        payload = json.dumps(review, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')
        pattern = rf'(<script id="{data_id}"[^>]*>).*?(</script>)'
        html, count = re.subn(pattern, lambda m: m[1] + payload + m[2], html, flags=re.S)
        if count != 1:
            raise ValueError('Missing/duplicate embedded registry: ' + data_id)
    if len({r['recordId'] for r in inventory}) != len(inventory):
        raise ValueError('Duplicate reference identity')
    summary = {
        'records': len(inventory),
        'recordsWithReference': sum(r['hasReference'] for r in inventory),
        'recordsWithoutDocumentedFacts': sum(not r['hasReference'] for r in inventory),
        'selectableRecordsWithReference': sum(r['hasReference'] and r['selectable'] for r in inventory),
        'recordsWithKeyBattery': sum('pila_mando' in r['fields'] for r in inventory),
        'recordsWithKeyRange': sum('alcance_mando' in r['fields'] for r in inventory),
        'recordsWithFobHomologation': sum('mando_homologacion' in r['fields'] for r in inventory),
        'diagnosticRecordsWithLocation': sum(r['section'] == 'diagnostico' and 'ubicacion' in r['fields'] for r in inventory),
    }
    families = []
    for family in sorted({r['identity']['family'] for r in inventory}):
        rows = [r for r in inventory if r['identity']['family'] == family]
        families.append({'family': family, 'records': len(rows),
                         'recordsWithReference': sum(r['hasReference'] for r in rows),
                         'diagnosticLocations': sum(r['section'] == 'diagnostico' and 'ubicacion' in r['fields'] for r in rows)})
    report = {'schema': 1, 'scope': 'Datos documentados por ficha; no certificación de componentes o unidad.',
              'inputs': inputs, 'summary': summary, 'families': families, 'records': inventory}
    changed[ROOT / 'docs/model-reference-inventory.json'] = json.dumps(report, ensure_ascii=False, indent=2) + '\n'
    buffer = io.StringIO(newline='')
    fields = ['identidad', 'seccion', 'anio', 'familia', 'modelo', 'plataforma', 'sistema',
              'tiene_datos_documentados', 'campos_pendientes', 'sistema_documentado', 'antena',
              'pila_mando', 'alcance_mando', 'mando_homologacion', 'chip_citado', 'componente_citado',
              'ubicacion_diagnostico', 'acceso_diagnostico']
    writer = csv.writer(buffer); writer.writerow(fields)
    for row in inventory:
        i = row['identity']; values = row['fields']
        writer.writerow([row['recordId'], row['section'], i['year'], i['family'], i['model'], i['platform'], i['system'],
                         'SI' if row['hasReference'] else 'NO', ';'.join(row['pendingTopics']),
                         *[values.get(f, '') for f in ('sistema', 'antena', 'pila_mando', 'alcance_mando',
                           'mando_homologacion', 'chip', 'modulo', 'ubicacion', 'acceso')]])
    csv_text = '\ufeff' + buffer.getvalue()
    changed[ROOT / 'docs/FICHAS_REFERENCIA_B8.csv'] = csv_text
    changed[APP / 'FICHAS_REFERENCIA_B8.csv'] = csv_text
    # Keep the existing per-block claim exports aligned with their source registry.
    # Their full exports preserve historical/context columns; pending exports are
    # derived from all claims so a reopened assertion is not silently omitted.
    for path in sorted((ROOT / 'docs').glob('*_AFIRMACIONES.csv')):
        with path.open(encoding='utf-8-sig', newline='') as handle:
            reader = csv.DictReader(handle)
            columns = reader.fieldnames
            rows = list(reader)
        for item in rows:
            identity = item.get('identidad', item.get('record_id'))
            claim = claims_by_identity[(identity, item['afirmacion'])]
            for column, value in {
                'estado': claim['status'], 'fuentes': ';'.join(claim.get('sourceIds', [])),
                'observaciones': ';'.join(claim.get('observations', [])),
                'limite': claim['limitation'], 'limitacion': claim['limitation'],
                'siguiente_accion': claim.get('nextAction', ''),
            }.items():
                if column in columns:
                    item[column] = value
        pending_name = path.name.replace('_AFIRMACIONES.csv', '_PENDIENTES.csv')
        if path.name == 'F800_AFIRMACIONES.csv':
            pending_name = 'F800_PENDIENTES_RESOLUCION.csv'
        for target, selected_rows in (
            (path, rows),
            (path.with_name(pending_name), [r for r in rows if r['estado'] == PENDING]),
        ):
            buffer = io.StringIO(newline='')
            writer = csv.DictWriter(buffer, fieldnames=columns)
            writer.writeheader(); writer.writerows(selected_rows)
            changed[target] = '\ufeff' + buffer.getvalue()
    changed[APP / 'index.html'] = html
    return changed, summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    expected, summary = outputs()
    stale = []
    for path, text in expected.items():
        if path.exists() and path.read_bytes() == text.encode():
            continue
        if args.check:
            stale.append(str(path.relative_to(ROOT)))
        else:
            path.write_bytes(text.encode())
    if stale:
        parser.exit(1, 'Referencias obsoletas: ' + ', '.join(stale) + '\n')
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    main()
